import hashlib,json,os,pathlib,shutil,subprocess,tempfile,time,xml.etree.ElementTree as ET
owner=pathlib.Path('/home/administrator/projects/hexalith/projects/references/Hexalith.Conversations')
base=pathlib.Path('/dev/shm/story64-owner-label')
out=base/'final-verification';out.mkdir()
artifacts=base/'artifacts'
env=os.environ.copy();env['TMPDIR']=str(base/'tmp')
records=[]
def snapshot():
    names=subprocess.check_output(['git','diff','--name-only','HEAD','-z'],cwd=owner).split(b'\0')+subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=owner).split(b'\0')
    return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=owner,text=True).strip(),'files':{raw.decode():hashlib.sha256((owner/raw.decode()).read_bytes()).hexdigest() for raw in sorted(set(names)) if raw and not raw.decode().startswith('.story64-') and (owner/raw.decode()).is_file()}}
start=snapshot();(out/'source-start.json').write_text(json.dumps(start,indent=2)+'\n')
def run(name,args):
    before=snapshot();print('Running '+name,flush=True)
    begun=time.time()
    with (out/(name+'.log')).open('w') as log:
        result=subprocess.run(args,cwd=owner,env=env,stdout=log,stderr=subprocess.STDOUT)
    rec={'id':name,'working_directory':str(owner),'argv':args,'environment_overrides':{'TMPDIR':env['TMPDIR']},'exit_code':result.returncode,'elapsed_seconds':round(time.time()-begun,3),'source_before':before,'source_after':snapshot()}
    records.append(rec);(out/'command-records.json').write_text(json.dumps(records,indent=2)+'\n')
    print(name+' exit '+str(result.returncode),flush=True)
    if result.returncode:
        print((out/(name+'.log')).read_text()[-7000:],flush=True)
        raise RuntimeError(name+' failed')
    return result
scratch=None
try:
    for kind in ['Contracts.Tests','Tests','Server.Tests']:
        project='Hexalith.Conversations.'+kind if kind!='Tests' else 'Hexalith.Conversations.Tests'
        name={'Contracts.Tests':'contracts-build','Tests':'core-build','Server.Tests':'server-build'}[kind]
        run(name,['dotnet','build',f'tests/{project}/{project}.csproj','--configuration','Debug','--artifacts-path',str(artifacts),'-p:UseHexalithProjectReferences=true','-p:NuGetAudit=false','-m:1','-v:minimal'])
    scratch=pathlib.Path(tempfile.mkdtemp(prefix='.story64-final-validation-',dir=owner))
    setup=[]
    for kind,project in [('contracts','Hexalith.Conversations.Contracts.Tests'),('core','Hexalith.Conversations.Tests'),('server','Hexalith.Conversations.Server.Tests')]:
        dest=scratch/kind/'bin/Debug/net10.0'
        shutil.copytree(artifacts/'bin'/project/'debug',dest)
        setup.append({'source':str(artifacts/'bin'/project/'debug'),'destination':str(dest),'assembly_sha256':hashlib.sha256((dest/(project+'.dll')).read_bytes()).hexdigest()})
    (out/'scratch-setup.json').write_text(json.dumps(setup,indent=2)+'\n')
    contracts=str(scratch/'contracts/bin/Debug/net10.0/Hexalith.Conversations.Contracts.Tests.dll')
    selectors=['*ConversationResolution*','*ContractSerializationTest','*ConversationPublicationContractTest','*ContractValidationTest','*CallerMetadataContractsTest','*SchemaVersionCompatibilityTest','*ContractCompatibilityMetadataTest','*ForbiddenPublicSurfaceTest','*ContractsAssemblyBoundaryTest']
    args=['dotnet',contracts]
    for selector in selectors:args+=['-class',selector]
    run('contracts-behavior',args+['-result-xml',str(out/'contracts-behavior.xml')])
    run('contracts-metadata',['dotnet',contracts,'-method','*ContractsProjectShouldDeclareAdopterPackageMetadata','-method','*ClientProjectShouldDeclareAlignedAdopterPackageMetadataAndSupportedClientSurface','-result-xml',str(out/'contracts-metadata.xml')])
    run('core-full',['dotnet',str(scratch/'core/bin/Debug/net10.0/Hexalith.Conversations.Tests.dll'),'-result-xml',str(out/'core-full.xml')])
    run('server-full',['dotnet',str(scratch/'server/bin/Debug/net10.0/Hexalith.Conversations.Server.Tests.dll'),'-result-xml',str(out/'server-full.xml')])
finally:
    if scratch is not None and scratch.parent==owner and scratch.name.startswith('.story64-final-validation-'):
        shutil.rmtree(scratch)
        (out/'cleanup.json').write_text(json.dumps({'removed':str(scratch),'scope':'invocation-owned validation scratch only'})+'\n')
    end=snapshot();(out/'source-end.json').write_text(json.dumps(end,indent=2)+'\n')
    print('Source unchanged during validation: '+str(start==end),flush=True)
for path in sorted(out.glob('*.xml')):
    assembly=ET.parse(path).getroot().find('assembly')
    print(path.name,json.dumps({key:assembly.get(key) for key in ['total','passed','failed','skipped']}),flush=True)
