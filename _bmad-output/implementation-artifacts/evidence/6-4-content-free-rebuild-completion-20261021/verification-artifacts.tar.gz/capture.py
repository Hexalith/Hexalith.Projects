import sys,pathlib,json,subprocess,hashlib,difflib,importlib.util
ROOT=pathlib.Path('/home/administrator/projects/hexalith/projects');OUT=pathlib.Path('/tmp/hexalith-content-free-rebuild-20261021-root')
BASE=json.loads((OUT/'baseline.json').read_text())
target=OUT/(sys.argv[1] if len(sys.argv)>1 else 'review-snapshot');target.mkdir(parents=True,exist_ok=True)
manifest={}; incremental=[];cumulative=[]
for name in ['EventStore','Conversations']:
 repo=ROOT/'references'/('Hexalith.'+name);info=BASE[name];head=info['head']
 def git(*args):return subprocess.run(['git',*args],cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 paths=set(git('diff','--name-only',head).stdout.decode().splitlines())|set(git('ls-files','--others','--exclude-standard').stdout.decode().splitlines())|set(info['dirty_sha256'])
 for rel in sorted(paths):
  if not rel.startswith(('src/','tests/','docs/')) or any(x in pathlib.Path(rel).parts for x in ['bin','obj','references','.agents','.claude']):continue
  current=(repo/rel).read_bytes() if (repo/rel).is_file() else b''
  commit=git('show',head+':'+rel);canonical=commit.stdout if commit.returncode==0 else b''
  original=OUT/'baseline'/name/'files'/rel
  before=original.read_bytes() if original.is_file() else canonical
  if current==before:continue
  key=name+'/'+rel;dest=target/'files'/key;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(current)
  manifest[key]={'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':hashlib.sha256(current).hexdigest()}
  incremental.extend(difflib.unified_diff(before.decode(errors='replace').splitlines(keepends=True),current.decode(errors='replace').splitlines(keepends=True),fromfile='a/'+key,tofile='b/'+key))
  cumulative.extend(difflib.unified_diff(canonical.decode(errors='replace').splitlines(keepends=True),current.decode(errors='replace').splitlines(keepends=True),fromfile='a/'+key,tofile='b/'+key))
(target/'incremental.patch').write_text(''.join(incremental));(target/'cumulative.patch').write_text(''.join(cumulative));(target/'changed-files.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'target':str(target),'files':list(manifest),'patch_bytes':(target/'incremental.patch').stat().st_size},indent=2))
