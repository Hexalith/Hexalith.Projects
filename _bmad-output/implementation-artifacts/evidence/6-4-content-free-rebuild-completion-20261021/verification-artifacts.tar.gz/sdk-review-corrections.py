from pathlib import Path
r=Path('/home/administrator/projects/hexalith/projects/references/Hexalith.EventStore')
p=r/'tests/Hexalith.EventStore.Client.Tests/Projections/DaprReadModelBatchTests.ContentFreeCompletion.cs';s=p.read_text();s=s.replace('    [InlineData("unknown-rich-field")]','    [InlineData("unknown-rich-field")]\n    [InlineData("unknown-nested-rich-field")]');s=s.replace('''            if (change == "unknown-rich-field") proof["messages"] = "forbidden";''','''            if (change == "unknown-rich-field") proof["messages"] = "forbidden";
            if (change == "unknown-nested-rich-field") proof["owners"]![0]!["messages"] = "forbidden";''');old='''        var current = CompletionBatch();
        string oldReaderKey = (current.Scope with { ProjectionType = current.OwnerSelections![0].ReceiptProjectionName! }).ComputeMarkerKey();
        oldReaderKey.ShouldNotBe(current.Scope.ComputeMarkerKey());
        client.ByteStoreContains(oldReaderKey).ShouldBeFalse();
        // The old validator only supports literal rebuild; the new alias has no rich marker in its scope.
        ReadModelOwnerSelectionMetadata.ReceiptContains(new ReadModelBatchMarker
            { OwnerSelections = old.OwnerSelections }, current.OwnerSelections![0]).ShouldBeFalse();''';new='''        using var optedInBackend = new RecordingDaprClient();
        var optedInStore = CreateStore(optedInBackend);
        var current = CompletionBatch();
        (await optedInStore.ExecuteAsync(current)).IsSuccess.ShouldBeTrue();
        var actual = (await optedInStore.GetCompactedAsync<JsonDocument>(Store, "tenant-1:counter:agg-1:detail")).Value!;
        var selected = ReadModelOwnerSelectionMetadata.Read(System.Text.Encoding.UTF8.GetBytes(actual.RootElement.GetRawText())).ShouldNotBeNull();
        optedInBackend.ByteStoreContains(ReadModelBatchKeys.CompletionKey(current.Scope.ComputeScopeHash())).ShouldBeTrue();
        optedInBackend.ByteStoreContains(current.Scope.ComputeMarkerKey()).ShouldBeTrue();
        // Execute the old lookup algorithm with the actual newly persisted discriminator. It hashes a
        // different scope, reads only that missing key and has no fallback to the real rebuild marker.
        var oldScope = new ReadModelBatchScope(Store, selected.TenantId, selected.Domain, selected.AggregateId,
            selected.ReceiptProjectionName!, selected.BatchId);
        string oldReaderKey = oldScope.ComputeMarkerKey();
        oldReaderKey.ShouldNotBe(current.Scope.ComputeMarkerKey());
        int reads = 0, writes = optedInBackend.TrySaveByteOperations.Count;
        optedInBackend.BeforeReadByteState = key => { key.ShouldBe(oldReaderKey); reads++; };
        var missing = await new DaprReadModelBatchStateAccessor(optedInBackend, Store).ReadAsync(oldReaderKey, default);
        missing.Exists.ShouldBeFalse();
        reads.ShouldBe(1);
        optedInBackend.TrySaveByteOperations.Count.ShouldBe(writes);''';assert old in s;s=s.replace(old,new);p.write_text(s)
