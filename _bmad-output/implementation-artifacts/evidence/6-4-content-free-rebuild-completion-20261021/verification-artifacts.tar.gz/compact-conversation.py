from pathlib import Path
r=Path('/home/administrator/projects/hexalith/projects/references/Hexalith.Conversations')
p=r/'src/Hexalith.Conversations.Server/Projections/ConversationProjectionReadStore.cs';s=p.read_text();start=s.index('    public async ValueTask<ConversationResolutionMetadataReadModel?> ReadResolutionMetadataAsync(');body=s.index('    {',start);nextmeth=s.index('    /// <inheritdoc/>',body);old=s[start:nextmeth];new=old.replace('ReadResolutionMetadataAsync(', 'ReadResolutionMetadataCoreAsync(',1).replace('.GetAsync<','.GetCompactedAsync<');wrapper='''    public async ValueTask<ConversationResolutionMetadataReadModel?> ReadResolutionMetadataAsync(
        TenantId tenantId, ConversationId conversationId, CancellationToken cancellationToken = default)
    {
        try
        {
            return await ReadResolutionMetadataCoreAsync(tenantId, conversationId, cancellationToken).ConfigureAwait(false);
        }
        catch (Exception exception) when (exception is InvalidOperationException or NotSupportedException)
        {
            throw new ConversationProjectionConsistencyException();
        }
    }

''';s=s[:start]+wrapper+'    private '+new[len('    public '):]+s[nextmeth:];p.write_text(s)
p=r/'src/Hexalith.Conversations.Server/Queries/ConversationResolutionNativeEvidence.cs';s=p.read_text().replace('''        var selected = await store.GetAsync<ConversationResolutionNativeSelection>(ConversationProjectionReadModelKeys.StateStoreName,
            ConversationProjectionReadModelKeys.ResolutionSelectionKey(metadata.TenantId, metadata.ConversationId), cancellationToken).ConfigureAwait(false);''','''        ReadModelEntry<ConversationResolutionNativeSelection> selected;
        try
        {
            selected = await store.GetCompactedAsync<ConversationResolutionNativeSelection>(ConversationProjectionReadModelKeys.StateStoreName,
                ConversationProjectionReadModelKeys.ResolutionSelectionKey(metadata.TenantId, metadata.ConversationId), cancellationToken).ConfigureAwait(false);
        }
        catch (Exception exception) when (exception is InvalidOperationException or NotSupportedException)
        {
            return null;
        }''');p.write_text(s)
p=r/'tests/Hexalith.Conversations.Server.Tests/ResolutionMetadata/ResolutionGuardedStore.cs';s=p.read_text();needle='''    public async Task<ReadModelEntry<T>> GetAsync<T>(string storeName, string key, CancellationToken cancellationToken = default) where T : class
    {''';replacement='''    public Task<ReadModelEntry<T>> GetAsync<T>(string storeName, string key, CancellationToken cancellationToken = default) where T : class
        => ReadAsync<T>(storeName, key, false, cancellationToken);

    public Task<ReadModelEntry<T>> GetCompactedAsync<T>(string storeName, string key, CancellationToken cancellationToken = default) where T : class
        => ReadAsync<T>(storeName, key, true, cancellationToken);

    private async Task<ReadModelEntry<T>> ReadAsync<T>(string storeName, string key, bool compacted, CancellationToken cancellationToken) where T : class
    {''';assert needle in s;s=s.replace(needle,replacement).replace('''        var result = await inner.GetAsync<T>(storeName, key, cancellationToken);''','''        var result = compacted ? await inner.GetCompactedAsync<T>(storeName, key, cancellationToken)
            : await inner.GetAsync<T>(storeName, key, cancellationToken);''');p.write_text(s)
p=r/'tests/Hexalith.Conversations.Server.Tests/ResolutionMetadata/ResolutionRawReadStore.cs';s=p.read_text();needle='''    public async Task<ReadModelEntry<T>> GetAsync<T>(string storeName, string key, CancellationToken cancellationToken = default) where T : class
    {''';replacement='''    public Task<ReadModelEntry<T>> GetAsync<T>(string storeName, string key, CancellationToken cancellationToken = default) where T : class
        => ReadAsync<T>(storeName, key, false, cancellationToken);

    public Task<ReadModelEntry<T>> GetCompactedAsync<T>(string storeName, string key, CancellationToken cancellationToken = default) where T : class
        => ReadAsync<T>(storeName, key, true, cancellationToken);

    private async Task<ReadModelEntry<T>> ReadAsync<T>(string storeName, string key, bool compacted, CancellationToken cancellationToken) where T : class
    {''';assert needle in s;s=s.replace(needle,replacement).replace('''        Task resolution = (Task)protocol.GetMethod("ResolveVisibleAsync", BindingFlags.Public | BindingFlags.Static)!
            .Invoke(null, [Observer, key, cancellationToken, null])!;''','''        Task resolution;
        try
        {
            resolution = (Task)protocol.GetMethod(compacted ? "ReadCompactedAsync" : "ResolveVisibleAsync",
                BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static)!
                .Invoke(null, [Observer, key, cancellationToken, null])!;
            await resolution;
        }
        catch (TargetInvocationException exception) when (exception.InnerException is InvalidOperationException)
        {
            throw exception.InnerException;
        }''').replace('''        await resolution;
        object entry''','''        object entry''');p.write_text(s)
