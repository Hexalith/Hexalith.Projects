using Hexalith.EventStore.Client.Projections;
using Hexalith.EventStore.Contracts.Projections;
using Hexalith.EventStore.Server.Events;

using Shouldly;

namespace Hexalith.EventStore.Server.Tests.Projections;

public partial class NamedProjectionDispatchCoordinatorTests
{
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task ContentFreeRebuild_ActualGuardReplayFinalizationRecoveryAndCurrentInspectionPreserveTheOriginalCompletion(bool interrupt)
    {
        using var fixture = await GuardedTailProductionHarness.CreateAsync(3, 1, 2, handlerSemantics: "full-replay-v1");
        foreach (var handler in fixture.Handlers) handler.ContentFreeRebuildCompletion = true;
        await fixture.UseProductionOwnersAsync();
        string[] routes = fixture.Catalog.OrdinaryProjectionTypes.ToArray();
        if (interrupt) fixture.InterruptBeforePendingRoute = routes[1];
        var delivered = await fixture.DeliverAsync(256);
        if (interrupt)
        {
            delivered.AlreadyCurrent.ShouldBeFalse();
            fixture.Work.ShouldNotBeNull();
            fixture.InterruptBeforePendingRoute = null;
            fixture.ReconstructGuardedDelivery();
            await fixture.RunGuardedRetryAsync();
        }
        else delivered.AlreadyCurrent.ShouldBeTrue();
        fixture.Work.ShouldBeNull();
        fixture.Rows.Values.ShouldAllBe(row => row.LastDeliveredSequence == 3 && row.ActiveReservation == null
            && row.IdleBindingPending == null
            && row.GuardEvidence!.OwnerProof.Selection.ReceiptProjectionName == ReadModelRebuildCompletion.ReceiptProjectionName);
        var original = SourceProofCodec.ToNative(fixture.Head);
        foreach (string route in routes)
        {
            var model = (await fixture.Models.GetAsync<GuardedTailModel>("models", fixture.Identity.ActorId + ":" + route)).Value!;
            model.NativeSourceProof.ShouldBe(original);
            fixture.Handlers.Single(handler => handler.ProjectionType == route).RebuildCalls.ShouldBe(1);
        }
        int writes = fixture.Backend.TrySaveByteOperations.Count, rowWrites = fixture.RowWrites;
        int forbidden = 0;
        fixture.Backend.BeforeReadByteState = key =>
        {
            if (key.StartsWith("hxrmb:v1:marker:", StringComparison.Ordinal)
                || key.StartsWith("projection:rebuild", StringComparison.Ordinal)
                || key.EndsWith("-index", StringComparison.Ordinal))
            { forbidden++; throw new Xunit.Sdk.XunitException("Current inspection attempted a rich read: " + key); }
        };
        fixture.Events.Length.ShouldBe(3);
        fixture.ReturnedSequences.Clear();
        var inspected = await fixture.Probe.InspectCurrentAsync(fixture.Identity, CancellationToken.None);
        inspected.AlreadyCurrent.ShouldBeTrue();
        inspected.ProvenSource.ShouldNotBeNull();
        SourceProofCodec.ToNative(inspected.ProvenSource).ShouldBe(original);
        inspected.CatalogFingerprint.ShouldBe(fixture.Catalog.CatalogFingerprint);
        inspected.ProvenOwners.Count.ShouldBe(routes.Length);
        foreach (ProjectionOwnerProof proof in inspected.ProvenOwners.Values)
        {
            proof.ShouldBe(fixture.Rows[proof.Selection.ProjectionName].GuardEvidence!.OwnerProof);
            proof.Selection.ReceiptProjectionName.ShouldBe(ReadModelRebuildCompletion.ReceiptProjectionName);
        }
        fixture.ReturnedSequences.ShouldBeEmpty();
        fixture.Backend.TrySaveByteOperations.Count.ShouldBe(writes);
        fixture.RowWrites.ShouldBe(rowWrites);
        forbidden.ShouldBe(0);
    }
}
