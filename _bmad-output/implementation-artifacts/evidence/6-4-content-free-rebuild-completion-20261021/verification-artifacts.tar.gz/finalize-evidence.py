from pathlib import Path
import json,hashlib,tarfile,subprocess,re,importlib.util,datetime
ROOT=Path('/home/administrator/projects/hexalith/projects')
OUT=Path('/tmp/hexalith-content-free-rebuild-20261021-root')
DEST=ROOT/'_bmad-output/implementation-artifacts/evidence/6-4-content-free-rebuild-completion-20261021'
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(p,obj):p.write_text(json.dumps(obj,indent=2)+'\n')
module=importlib.util.spec_from_file_location('verify',OUT/'verify.py');v=importlib.util.module_from_spec(module);module.loader.exec_module(v)
sources=v.sources();source_hash=sha(json.dumps(sources,sort_keys=True).encode())
assert source_hash==json.loads((DEST/'source-manifest.json').read_text())['final_source_sha256']
base=json.loads((OUT/'baseline.json').read_text())
assert all(sha((ROOT/k).read_bytes())==h for k,h in base['protected'].items())
parent=ROOT/'_bmad-output/implementation-artifacts/spec-6-4-prerequisite-current-authorized-resolution-evidence.md'
def frozen(b):return re.search(rb'<frozen-after-approval\b.*?</frozen-after-approval>',b,re.S).group(0)
assert frozen(parent.read_bytes())==frozen((OUT/'baseline/prerequisite-spec.md').read_bytes())
assert "status: 'in-progress'" in parent.read_text().split('---')[1]
subtask=ROOT/'_bmad-output/implementation-artifacts/spec-6-4-prerequisite-content-free-rebuild-completion.md'
assert "status: 'done'" in subtask.read_text().split('---')[1]
for name in ['closure-root-whitespace','closure-planning-authority','final-client-whitespace','final-conversation-whitespace']:
 r=json.loads((OUT/'independent'/(name+'.json')).read_text());assert r['exit_code']==0 and r['source_before_sha256']==source_hash and r['source_after_sha256']==source_hash
for row in json.loads((DEST/'coverage-map.json').read_text()):assert row['status']=='executed-pass' and all(t['result']=='Pass' for t in row['executed_cases'])
for p in [DEST/'README.md',DEST/'source-and-writer-boundaries.md',subtask]:
 for link in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  if '://' not in link and not link.startswith('#'):assert (p.parent/link.split('#')[0]).exists(),(p,link)
records=[]
for directory in ['implementation','independent']:
 for p in sorted((OUT/directory).glob('*.json')):
  r=json.loads(p.read_text())
  if isinstance(r,dict) and ('argv' in r or 'command' in r):records.append({'artifact':directory+'/'+p.name,'record':r})
dump(DEST/'command-records.json',records)
closure={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha256':source_hash,'protected_files_unchanged':True,'parent_frozen_unchanged':True,'parent_prerequisite_status':'in-progress','parent_story_status':'blocked','bounded_source_subtask_status':'done','review_claims_corrected':13,'tests_passed':1603,'failures':0,'skipped':0,'closure_document_and_planning_commands':'independent/closure-*.json and logs in archive','matrix_status':'all six scenarios bound to actual passing final XML names','local_links_and_json':'pass','raw_runtime_logs_excluded':True,'git_mutations_by_this_run':False,'document_sha256':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in [subtask,parent,DEST/'README.md']}}
dump(DEST/'closure.json',closure)
# Rebuild from the existing explicit whitelist plus reproducibility scripts and closure commands.
a=json.loads((DEST/'archive-manifest.json').read_text());names={e['path'] for e in a['entries']}
names.update(str(p.relative_to(OUT)) for p in (OUT/'independent').glob('closure-*'))
names.update(['assemble-evidence.py','finalize-evidence.py'])
assert not any(n in ['runtime-start.log','runtime-describe.log','runtime-stop.log'] for n in names)
manifest=[{'path':n,'bytes':(OUT/n).stat().st_size,'sha256':sha((OUT/n).read_bytes())} for n in sorted(names)]
with tarfile.open(DEST/'verification-artifacts.tar.gz','w:gz') as tar:
 for n in sorted(names):tar.add(OUT/n,arcname=n,recursive=False)
with tarfile.open(DEST/'verification-artifacts.tar.gz') as tar:
 for e in manifest:
  data=tar.extractfile(e['path']).read();assert len(data)==e['bytes'] and sha(data)==e['sha256']
dump(DEST/'archive-manifest.json',{'archive':'verification-artifacts.tar.gz','sha256':sha((DEST/'verification-artifacts.tar.gz').read_bytes()),'entries':manifest,'exclusions':'Raw runtime logs; bin/obj/cache; unlisted workspace files.','archive_round_trip_checksums':'pass'})
for p in DEST.glob('*.json'):json.loads(p.read_text())
print(json.dumps({'status':'PASS','final_source_unchanged':True,'protected_and_frozen_preserved':True,'archive_entries':len(manifest),'archive_checksums':'pass','matrix':'all executed pass','subtask':'done','parent_story':'blocked'},indent=2))
