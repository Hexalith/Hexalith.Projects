import sys,json,subprocess,hashlib,pathlib,time,datetime
ROOT=pathlib.Path('/home/administrator/projects/hexalith/projects')
OUT=pathlib.Path('/tmp/hexalith-content-free-rebuild-20261021-root')

def digest(data):return hashlib.sha256(data).hexdigest()
def sources():
    result={}
    for owner in ['EventStore','Conversations']:
        repo=ROOT/'references'/('Hexalith.'+owner)
        for top in ['src','tests']:
            for p in (repo/top).rglob('*'):
                rel=p.relative_to(repo)
                if any(part in ['bin','obj','node_modules','.git','references'] for part in rel.parts):continue
                if p.is_file() and p.suffix in ['.cs','.csproj','.props','.targets','.json']:
                    result[owner+'/'+str(rel)]=digest(p.read_bytes())
        for p in repo.iterdir():
            if p.is_file() and (p.suffix in ['.props','.targets','.json','.slnx'] or p.name in ['.editorconfig','.gitattributes']):
                result[owner+'/'+p.name]=digest(p.read_bytes())
    return result

def binaries(repo,argv):
    if len(argv)>1 and argv[0]=='dotnet' and argv[1].endswith('.dll'):
        path=pathlib.Path(argv[1]); path=path if path.is_absolute() else repo/path
        return {p.name:digest(p.read_bytes()) for p in sorted(path.parent.glob('*.dll'))}
    return {}

def run():
    label,owner=sys.argv[1:3];argv=sys.argv[3:];repo=ROOT if owner=='Projects' else ROOT/'references'/('Hexalith.'+owner)
    directory=OUT/'implementation';directory.mkdir(exist_ok=True)
    before=sources();bb=binaries(repo,argv);start=time.monotonic();utc=datetime.datetime.now(datetime.timezone.utc).isoformat()
    r=subprocess.run(argv,cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    after=sources();ba=binaries(repo,argv)
    (directory/(label+'.log')).write_bytes(r.stdout)
    rec={'label':label,'cwd':str(repo),'argv':argv,'start_utc':utc,'seconds':round(time.monotonic()-start,3),'exit_code':r.returncode,'source_before_sha256':digest(json.dumps(before,sort_keys=True).encode()),'source_after_sha256':digest(json.dumps(after,sort_keys=True).encode()),'source_unchanged':before==after,'binary_before':bb,'binary_after':ba,'binary_unchanged':bb==ba}
    (directory/(label+'.json')).write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps({k:v for k,v in rec.items() if k not in ['binary_before','binary_after']},indent=2));print(r.stdout.decode(errors='replace')[-3500:]);sys.exit(r.returncode)

if __name__=='__main__':run()
