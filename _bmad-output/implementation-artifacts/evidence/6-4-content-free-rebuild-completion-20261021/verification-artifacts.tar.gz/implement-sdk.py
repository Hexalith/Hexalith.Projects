from pathlib import Path
root=Path('/home/administrator/projects/hexalith/projects/references/Hexalith.EventStore')
def replace(path,old,new):
 p=root/path;s=p.read_text();assert old in s,path;p.write_text(s.replace(old,new))
(root/'src/Hexalith.EventStore.Client/Projections/ReadModelRebuildCompletion.cs').write_text('''namespace Hexalith.EventStore.Client.Projections;

/// <summary>Identifies newly prepared coordinated selections that require isolated SDK completion evidence.</summary>
public static class ReadModelRebuildCompletion
{
    /// <summary>
    /// The versioned content-free receipt discriminator. It is deliberately different from the rich
    /// rebuild scope: older readers derive a different marker key and cannot hydrate the rebuild marker.
    /// This discriminator must be present in the original fingerprint-bound model operations.
    /// </summary>
    public const string ReceiptProjectionName = "rebuild-completion-v1";
}
''')
(root/'src/Hexalith.EventStore.Client/Projections/ReadModelBatchCompletionProof.cs').write_text('''using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Serialization;

using Hexalith.EventStore.Contracts.Projections;

namespace Hexalith.EventStore.Client.Projections;

/// <summary>SDK-only immutable content-free completion evidence; never carries recovery operations or manifests.</summary>
/// <param name="Version">The completion proof protocol.</param>
/// <param name="ScopeHash">The original coordinated batch scope.</param>
/// <param name="BatchId">The original batch identity.</param>
/// <param name="Fingerprint">The original immutable manifest fingerprint.</param>
/// <param name="TerminalTimeUtc">The original durable receipt time.</param>
/// <param name="Owners">The exact coordinated selections.</param>
/// <param name="Digest">The canonical content integrity digest.</param>
[JsonUnmappedMemberHandling(JsonUnmappedMemberHandling.Disallow)]
internal sealed record ReadModelBatchCompletionProof(
    [property: JsonRequired] int Version,
    [property: JsonRequired] string ScopeHash,
    [property: JsonRequired] string BatchId,
    [property: JsonRequired] string Fingerprint,
    [property: JsonRequired] string TerminalTimeUtc,
    [property: JsonRequired] IReadOnlyList<ProjectionOwnerSelection> Owners,
    [property: JsonRequired] string Digest)
{
    /// <summary>Copies only terminal metadata from the actual SDK receipt.</summary>
    internal static ReadModelBatchCompletionProof From(ReadModelBatchMarker receipt)
    {
        var proof = new ReadModelBatchCompletionProof(1, receipt.ScopeHash, receipt.BatchId,
            receipt.Fingerprint, receipt.TerminalTimeUtc!, receipt.OwnerSelections!, string.Empty);
        return proof with { Digest = proof.ComputeDigest() };
    }

    /// <summary>Parses only the bounded exact completion format and detects altered fields.</summary>
    internal static ReadModelBatchCompletionProof? Read(ReadOnlyMemory<byte> bytes)
    {
        if (bytes.Length > ReadModelBatchMarker.MaxControlBytes) return null;
        using JsonDocument document = JsonDocument.Parse(bytes);
        if (document.RootElement.ValueKind != JsonValueKind.Object
            || ReadModelBatchMarker.HasDuplicateProperties(document.RootElement)) return null;
        ReadModelBatchCompletionProof? proof = document.RootElement.Deserialize<ReadModelBatchCompletionProof>(JsonSerializerOptions.Web);
        return proof is { Version: 1, Owners.Count: > 0 } && ReadModelBatchFingerprint.IsCanonical(proof.Fingerprint)
            && ReadModelBatchMarker.IsUtcTerminalTime(proof.TerminalTimeUtc)
            && proof.Digest == proof.ComputeDigest() ? proof : null;
    }

    /// <summary>Adapts the isolated proof to the existing exact owner/receipt validation.</summary>
    internal ReadModelBatchMarker ToReceipt() => new()
    {
        ScopeHash = ScopeHash, BatchId = BatchId, Fingerprint = Fingerprint,
        Status = ReadModelBatchMarkerStatus.Completed, TerminalTimeUtc = TerminalTimeUtc, OwnerSelections = Owners,
    };

    private string ComputeDigest() => Convert.ToHexStringLower(SHA256.HashData(
        ReadModelBatchCanonicalJson.Canonicalize(JsonSerializer.SerializeToUtf8Bytes(this with { Digest = string.Empty }, JsonSerializerOptions.Web)).Span));
}
''')
replace(Path('src/Hexalith.EventStore.Client/Projections/ReadModelBatchKeys.cs'),'    /// <summary>Builds the private immutable legacy compensation evidence key', '''    /// <summary>Builds the isolated namespace that can contain terminal metadata only.</summary>
    internal static string CompletionKey(string scopeHash) => "hxrmb:v1:completion:" + scopeHash;

    /// <summary>Builds the private immutable legacy compensation evidence key''')
replace(Path('src/Hexalith.EventStore.Client/Projections/ReadModelBatchMarker.cs'),'private static bool IsUtcTerminalTime','internal static bool IsUtcTerminalTime')
replace(Path('src/Hexalith.EventStore.Client/Projections/ReadModelBatchMarker.cs'),'private static bool HasDuplicateProperties','internal static bool HasDuplicateProperties')
replace(Path('src/Hexalith.EventStore.Client/Projections/ReadModelOwnerSelectionMetadata.cs'),'candidate.ReceiptProjectionName != batch.Scope.ProjectionType','!IsRebuildReceipt(candidate.ReceiptProjectionName)')
replace(Path('src/Hexalith.EventStore.Client/Projections/ReadModelOwnerSelectionMetadata.cs'),'selected.ReceiptProjectionName == "rebuild"','IsRebuildReceipt(selected.ReceiptProjectionName)')
replace(Path('src/Hexalith.EventStore.Client/Projections/ReadModelOwnerSelectionMetadata.cs'),'    /// <summary>Finds one exact selection', '''    /// <summary>Accepts only the existing rebuild receipt or the explicit content-free protocol.</summary>
    internal static bool IsRebuildReceipt(string? name)
        => name is "rebuild" or ReadModelRebuildCompletion.ReceiptProjectionName;

    /// <summary>Finds one exact selection''')
replace(Path('src/Hexalith.EventStore.Client/Projections/DaprReadModelStore.OwnerProof.cs'),'''            var scope = new ReadModelBatchScope(binding.StoreName, identity.TenantId, identity.Domain,
                identity.AggregateId, selection.ReceiptProjectionName ?? request.ProjectionName, selection.BatchId);
            reads++;
            RawStateEntry receiptRow = await accessor.ReadAsync(scope.ComputeMarkerKey(), cancellationToken).ConfigureAwait(false);''','''            bool completionOnly = selection.ReceiptProjectionName == ReadModelRebuildCompletion.ReceiptProjectionName;
            if (selection.ReceiptProjectionName is not null && !ReadModelOwnerSelectionMetadata.IsRebuildReceipt(selection.ReceiptProjectionName))
                return new(null, "delivery_reconciliation_required", reads, bytes);
            var scope = new ReadModelBatchScope(binding.StoreName, identity.TenantId, identity.Domain,
                identity.AggregateId, completionOnly ? "rebuild" : selection.ReceiptProjectionName ?? request.ProjectionName, selection.BatchId);
            reads++;
            // The completion discriminator never falls back to the potentially rich marker, even when
            // evidence is absent or corrupt. Old readers hash the discriminator as a different scope.
            RawStateEntry receiptRow = await accessor.ReadAsync(completionOnly
                ? ReadModelBatchKeys.CompletionKey(scope.ComputeScopeHash()) : scope.ComputeMarkerKey(), cancellationToken).ConfigureAwait(false);''')
replace(Path('src/Hexalith.EventStore.Client/Projections/DaprReadModelStore.OwnerProof.cs'),'''            ReadModelBatchMarker? receipt = ReadModelBatchMarker.ReadBoundedProof(receiptRow.Value);''','''            ReadModelBatchMarker? receipt = completionOnly
                ? ReadModelBatchCompletionProof.Read(receiptRow.Value)?.ToReceipt()
                : ReadModelBatchMarker.ReadBoundedProof(receiptRow.Value);''')
replace(Path('src/Hexalith.EventStore.Client/Projections/ReadModelBatchProtocol.cs'),'''        return _ownerSelection is null && _ownerSelections is null && !_batch.RetainManifestForRecovery
            || await ReclaimOriginalManifestAsync(_accessor, _scopeHash, _fingerprint, cancellationToken).ConfigureAwait(false);''','''        bool reclaimed = _ownerSelection is null && _ownerSelections is null && !_batch.RetainManifestForRecovery
            || await ReclaimOriginalManifestAsync(_accessor, _scopeHash, _fingerprint, cancellationToken).ConfigureAwait(false);
        return reclaimed && await PublishCompletionProofAsync(cancellationToken).ConfigureAwait(false);''')
(root/'src/Hexalith.EventStore.Client/Projections/ReadModelBatchProtocol.Completion.cs').write_text('''using System.Text.Json;

namespace Hexalith.EventStore.Client.Projections;

internal sealed partial class ReadModelBatchProtocol
{
    private async Task<bool> PublishCompletionProofAsync(CancellationToken cancellationToken)
    {
        // Enrollment is immutable manifest material. Old/direct rebuilds are never certified on retry.
        if (_ownerSelections is null || !_ownerSelections.Any(static owner =>
            owner.ReceiptProjectionName == ReadModelRebuildCompletion.ReceiptProjectionName)) return true;
        (ReadModelBatchMarker? receipt, _, _) = await ReadMarkerAsync(cancellationToken).ConfigureAwait(false);
        if (receipt is not { Status: ReadModelBatchMarkerStatus.Completed, Operations: null,
                OriginalManifest: null, OriginalManifestKey: null, RecoveryAnchor: null }
            || receipt.ScopeHash != _scopeHash || receipt.BatchId != _batch.Scope.BatchId
            || receipt.Fingerprint != _fingerprint || receipt.OwnerSelection is not null
            || receipt.OwnerSelections is null || !receipt.OwnerSelections.SequenceEqual(_ownerSelections)
            || !ReadModelBatchMarker.IsUtcTerminalTime(receipt.TerminalTimeUtc)) return false;
        var proof = ReadModelBatchCompletionProof.From(receipt);
        byte[] bytes = JsonSerializer.SerializeToUtf8Bytes(proof, JsonSerializerOptions.Web);
        if (bytes.Length > ReadModelBatchMarker.MaxControlBytes) return false;
        string key = ReadModelBatchKeys.CompletionKey(_scopeHash);
        RawStateEntry prior = await _accessor.ReadAsync(key, cancellationToken).ConfigureAwait(false);
        if (prior.Exists) return prior.Value.Span.SequenceEqual(bytes);
        // Publication follows the full physical end-state check for both store profiles. In particular,
        // a transaction receipt from a mis-qualified partial transaction cannot grant this proof.
        if (!await VerifyOperationKeysAsync(cancellationToken).ConfigureAwait(false)) return false;
        if (_injector is not null) await _injector.InjectAsync(ReadModelBatchPhase.BeforeCompletionProof, -1, cancellationToken).ConfigureAwait(false);
        _ = await _accessor.TryWriteAsync(key, bytes, string.Empty, cancellationToken).ConfigureAwait(false);
        RawStateEntry stored = await _accessor.ReadAsync(key, cancellationToken).ConfigureAwait(false);
        if (_injector is not null) await _injector.InjectAsync(ReadModelBatchPhase.AfterCompletionProof, -1, cancellationToken).ConfigureAwait(false);
        return stored.Exists && stored.Value.Span.SequenceEqual(bytes);
    }
}
''')
replace(Path('src/Hexalith.EventStore.Client/Projections/ReadModelBatchPhase.cs'),'''    RecoveryAnchorCompacted,
}''','''    RecoveryAnchorCompacted,
    /// <summary>After verified compaction and manifest reclamation, before isolated completion publication.</summary>
    BeforeCompletionProof,
    /// <summary>After isolated completion publication and exact read-back.</summary>
    AfterCompletionProof,
}''')
for path in ['src/Hexalith.EventStore.DomainService/DomainProjectionOwnerProof.cs','src/Hexalith.EventStore.DomainService/DomainProjectionGuardedReplay.cs']:
 p=root/path;s=p.read_text();s=s.replace('selection.ReceiptProjectionName != "rebuild"','!ReadModelOwnerSelectionMetadata.IsRebuildReceipt(selection.ReceiptProjectionName)').replace('owner.ReceiptProjectionName != "rebuild"','!ReadModelOwnerSelectionMetadata.IsRebuildReceipt(owner.ReceiptProjectionName)');p.write_text(s)
