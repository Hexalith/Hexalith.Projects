from pathlib import Path
r=Path('/home/administrator/projects/hexalith/projects/references/Hexalith.EventStore')
p=r/'src/Hexalith.EventStore.Client/Projections/ReadModelBatchEnvelope.cs';s=p.read_text();s=s.replace('''    /// <summary>Gets whether this envelope must refuse marker hydration until isolated physical completion.</summary>
    [JsonIgnore]
    internal bool RequiresIsolatedCompletion => EnvelopeVersion is 4 or 5;

''','').replace('version is not (1 or 2 or 4 or 5)','version is not (1 or 2)').replace('version is 2 or 5\n','version == 2\n').replace('envelope.EnvelopeVersion is not (1 or 2 or 4 or 5)','envelope.EnvelopeVersion is not (1 or 2)').replace('(envelope.EnvelopeVersion is 2 or 5) !=','(envelope.EnvelopeVersion == 2) !=').replace('envelope.EnvelopeVersion is 2 or 5 &&','envelope.EnvelopeVersion == 2 &&');p.write_text(s)
p=r/'src/Hexalith.EventStore.Client/Projections/ReadModelBatchProtocol.cs';s=p.read_text().replace('    private bool _completionOnlyVisibility;\n','');start=s.index('        // The discriminator requests safe visibility even when');end=s.index('        if (batch.RetainManifestForRecovery',start);s=s[:start]+s[end:];start=s.index('        if (envelope.RequiresIsolatedCompletion)');end=s.index('        RawStateEntry markerEntry = await accessor',start);s=s[:start]+s[end:];s=s.replace('EnvelopeVersion = CompletionEnvelopeVersion(operation),','EnvelopeVersion = operation.ExpiresAtUtc is null ? 1 : 2,').replace('            || candidate.EnvelopeVersion != CompletionEnvelopeVersion(_batch.Operations[ordinal])\n','');p.write_text(s)
p=r/'src/Hexalith.EventStore.Client/Projections/ReadModelBatchProtocol.Completion.cs';s=p.read_text();start=s.index('    private int CompletionEnvelopeVersion');end=s.index('    private async Task<bool> PublishCompletionProofAsync',start);s=s[:start]+'''    /// <summary>Reads a physically compacted value only, refusing every old/new envelope before marker access.</summary>
    internal static async Task<RawStateEntry> ReadCompactedAsync(IReadModelBatchStateAccessor accessor,
        string key, CancellationToken cancellationToken, TimeProvider? timeProvider = null)
    {
        RawStateEntry entry = await accessor.ReadAsync(key, cancellationToken).ConfigureAwait(false);
        if (entry.Exists && ReadModelBatchEnvelope.IsEnvelope(entry.Value.Span))
            throw new InvalidOperationException("The read-model generation is not physically complete.");
        return ReadModelBatchExpiringValue.Resolve(entry, timeProvider ?? TimeProvider.System);
    }

'''+s[end:];p.write_text(s)
p=r/'src/Hexalith.EventStore.Client/Projections/IReadModelStore.cs';s=p.read_text();needle='    /// <summary>\n    /// Saves a read-model value unconditionally';idx=s.index(needle);s=s[:idx]+'''    /// <summary>Reads only a physically compacted value, without reading any batch marker or manifest.</summary>
    /// <typeparam name="TValue">The isolated content-free read-model type.</typeparam>
    /// <param name="storeName">The DAPR state-store component.</param>
    /// <param name="key">The isolated read-model key.</param>
    /// <param name="cancellationToken">The caller cancellation token.</param>
    /// <returns>The compacted value or an absent entry.</returns>
    /// <exception cref="InvalidOperationException">The key contains an incomplete envelope.</exception>
    /// <exception cref="NotSupportedException">The store has not implemented this strict read capability.</exception>
    Task<ReadModelEntry<TValue>> GetCompactedAsync<TValue>(string storeName, string key,
        CancellationToken cancellationToken = default) where TValue : class
        => throw new NotSupportedException("Content-free compacted reads require explicit store support.");

'''+s[idx:];p.write_text(s)
(r/'src/Hexalith.EventStore.Client/Projections/DaprReadModelStore.Compacted.cs').write_text('''using System.Text.Json;

namespace Hexalith.EventStore.Client.Projections;

public sealed partial class DaprReadModelStore
{
    /// <inheritdoc/>
    public async Task<ReadModelEntry<TValue>> GetCompactedAsync<TValue>(string storeName, string key,
        CancellationToken cancellationToken = default) where TValue : class
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(storeName);
        ArgumentException.ThrowIfNullOrWhiteSpace(key);
        var accessor = new DaprReadModelBatchStateAccessor(_daprClient, storeName);
        RawStateEntry entry = await ReadModelBatchProtocol.ReadCompactedAsync(accessor, key,
            cancellationToken, _options.TimeProvider).ConfigureAwait(false);
        return entry.Exists
            ? new(JsonSerializer.Deserialize<TValue>(entry.Value.Span, _daprClient.JsonSerializerOptions), entry.ETag) { ExpiresAtUtc = entry.ExpiresAtUtc }
            : new(null, null) { ExpiresAtUtc = entry.ExpiresAtUtc };
    }
}
''')
p=r/'src/Hexalith.EventStore.Testing/Fakes/InMemoryReadModelStore.cs';s=p.read_text();idx=s.index('    /// <inheritdoc/>\n    public async Task<IReadOnlyList<ReadModelBulkEntry<TValue>>> GetManyAsync');s=s[:idx]+'''    /// <inheritdoc/>
    public async Task<ReadModelEntry<TValue>> GetCompactedAsync<TValue>(string storeName, string key,
        CancellationToken cancellationToken = default) where TValue : class
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(storeName);
        ArgumentException.ThrowIfNullOrWhiteSpace(key);
        var accessor = new InMemoryBatchAccessor(this, storeName);
        RawStateEntry entry = await ReadModelBatchProtocol.ReadCompactedAsync(accessor, key,
            cancellationToken, BatchOptions.TimeProvider).ConfigureAwait(false);
        return entry.Exists ? new(Deserialize<TValue>(entry.Value), entry.ETag) { ExpiresAtUtc = entry.ExpiresAtUtc }
            : new(null, null) { ExpiresAtUtc = entry.ExpiresAtUtc };
    }

'''+s[idx:];p.write_text(s)
p=r/'tests/Hexalith.EventStore.Client.Tests/Projections/DaprReadModelBatchTests.ContentFreeCompletion.cs';s=p.read_text();s=s.replace('''        _ = await store.GetAsync<JsonDocument>(Store, "tenant-1:counter:agg-1:detail");''','''        if (client.ByteStoreValue("tenant-1:counter:agg-1:detail") is { } selectedBytes && ReadModelBatchEnvelope.IsEnvelope(selectedBytes))
            await Should.ThrowAsync<InvalidOperationException>(() => store.GetCompactedAsync<JsonDocument>(Store, "tenant-1:counter:agg-1:detail"));
        else _ = await store.GetCompactedAsync<JsonDocument>(Store, "tenant-1:counter:agg-1:detail");''');p.write_text(s)
