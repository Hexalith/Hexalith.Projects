using System.Net;
using System.Net.Http.Json;
using System.Text.Json;

using Hexalith.EventStore.Client.Gateway;
using Hexalith.EventStore.Contracts.Projections;
using Hexalith.EventStore.Contracts.Queries;
using Hexalith.EventStore.Contracts.Streams;
using Hexalith.EventStore.ServiceDefaults.Authentication;

namespace Hexalith.Conversations.Server.Tests.ResolutionMetadata;

// The transport executes the actual enrolled SDK owner endpoint for every delegated read. Only the
// native gateway and authenticated HTTP boundary are fixture authorities, never seeded completion rows.
internal sealed class ResolutionRebuildDelegatedTransport(ResolutionEnrollmentFixture fixture,
    string catalog, string publicKey) : HttpMessageHandler, IHttpClientFactory, IWorkloadAssertionIssuer
{
    public bool CanBindResources => true;
    public int Calls { get; private set; }
    public string Catalog { get; set; } = catalog;
    public NativeSourceProof? SourceOverride { get; set; }
    public HttpClient CreateClient(string name) => new(this, disposeHandler: false);
    public ValueTask<string?> IssueAsync(WorkloadAssertionRequest request, CancellationToken cancellationToken = default)
        => ValueTask.FromResult<string?>("source-fixture-workload-assertion");

    protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
    {
        Calls++;
        var body = (await request.Content!.ReadFromJsonAsync<BoundOwnerQueryRequest>(cancellationToken))!;
        BoundOwnerQueryProof.Verify(body, request.Headers.GetValues(BoundOwnerQueryProof.HeaderName).Single(),
            "conversations", publicKey, fixture.Time.Now).ShouldBeTrue();
        body.PrincipalId.ShouldBe("actor");
        body.Query.QueryType.ShouldBe(InspectProjectionCurrentQuery.QueryType);
        body.Query.Tenant.ShouldBe(fixture.Input.TenantId);
        body.Query.AggregateId.ShouldBe(fixture.Input.AggregateId);
        var expected = body.Query.Payload!.Value.Deserialize<InspectProjectionCurrentQuery>(JsonSerializerOptions.Web)!;
        var owner = await fixture.OwnerAsync(Catalog);
        if (owner.Proof is null || owner.Proof.Selection != expected.Selection)
            return new(HttpStatusCode.ServiceUnavailable);
        var current = new ProjectionCurrentProof(SourceOverride ?? fixture.Gateway.Proof, owner.Proof, Catalog);
        return new(HttpStatusCode.OK) { Content = JsonContent.Create(new SubmitQueryResponse("correlation",
            JsonSerializer.SerializeToElement(current, JsonSerializerOptions.Web))) };
    }
}
