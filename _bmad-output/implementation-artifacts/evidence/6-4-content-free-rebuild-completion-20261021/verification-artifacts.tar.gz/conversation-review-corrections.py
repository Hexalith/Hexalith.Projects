from pathlib import Path
r=Path('/home/administrator/projects/hexalith/projects/references/Hexalith.Conversations')
def edit(name,fn):
 p=r/name;b=p.read_bytes();s=b.decode().replace('\r\n','\n');s=fn(s);p.write_bytes(s.replace('\n','\r\n').encode() if b'\r\n' in b else s.encode())
def fixture(s):
 s=s.replace('''    public InMemoryDaprStateClient Backend { get; } = new();''','''    public InMemoryDaprStateClient Backend { get; };
'''.rstrip())
 s=s.replace('''    public ResolutionTestTimeProvider Time { get; } = new(ResolutionMetadataFixture.Started.AddSeconds(10));''','''    public ResolutionTestTimeProvider Time { get; };
'''.rstrip())
 s=s.replace('''    public bool CanHaveBody => true;

    public ResolutionEnrollmentFixture(bool enroll = true, Action<IServiceCollection>? configure = null)
    {
        ProjectionRequest original = ResolutionMetadataFixture.Request();''','''    public bool CanHaveBody => true;
    private readonly bool _enroll;
    private readonly Action<IServiceCollection>? _configure;
    private bool _disposed;

    public ResolutionEnrollmentFixture(bool enroll = true, Action<IServiceCollection>? configure = null,
        InMemoryDaprStateClient? backend = null, ResolutionTestTimeProvider? time = null, ProjectionRequest? originalInput = null)
    {
        _enroll = enroll; _configure = configure;
        Backend = backend ?? new();
        Time = time ?? new(ResolutionMetadataFixture.Started.AddSeconds(10));
        ProjectionRequest original = originalInput ?? ResolutionMetadataFixture.Request();''')
 s=s.replace('''    public ValueTask DisposeAsync() => App.DisposeAsync();''','''    public async Task<ResolutionEnrollmentFixture> RestartAsync(DateTimeOffset now)
    {
        await DisposeAsync();
        // Only durable storage and original public input survive. Build a new container, handlers,
        // read-model adapter, gateway and clock; no admitted request or scoped service is retained.
        return new(_enroll, _configure, Backend, new(now), Input);
    }

    public async ValueTask DisposeAsync()
    {
        if (_disposed) return;
        _disposed = true;
        await App.DisposeAsync();
    }''')
 # Auto-properties do not take a trailing semicolon.
 return s.replace('Backend { get; };','Backend { get; }').replace('Time { get; };','Time { get; }')
edit('tests/Hexalith.Conversations.Server.Tests/ResolutionMetadata/ResolutionEnrollmentFixture.cs',fixture)
def transport(s):
 s=s.replace('using System.Net.Http.Json;','using System.Net.Http.Json;\nusing System.Security.Cryptography;')
 s=s.replace('using Hexalith.EventStore.Client.Gateway;','using Hexalith.EventStore.Client.Gateway;\nusing Hexalith.EventStore.Client.Streams;\nusing Hexalith.EventStore.Contracts.Identity;')
 s=s.replace('using Hexalith.EventStore.ServiceDefaults.Authentication;','using Hexalith.EventStore.ServiceDefaults.Authentication;\nusing Hexalith.Tenants.Contracts.Queries;')
 s=s.replace('''    public int Calls { get; private set; }
''','''    public int Calls { get; private set; }
    public int TenantCalls { get; private set; }
    public bool TenantAllowed { get; set; } = true;
    public Action<int>? OnProjection { get; set; }
''')
 s=s.replace('''        Calls++;
        var body''','''        var body''')
 s=s.replace('''        body.PrincipalId.ShouldBe("actor");
        body.Query.QueryType.ShouldBe(InspectProjectionCurrentQuery.QueryType);''','''        body.PrincipalId.ShouldBe("actor");
        if (body.Query.QueryType == ResolveTenantReadAuthority.QueryType)
        {
            // Native Tenant authority is a fixture transport authority, never deployment/G-4 evidence.
            // The production SDK delegated client, native evidence adapter, authorization and metadata
            // handler below still execute their actual before/after authority checks.
            TenantCalls++;
            body.Query.Tenant.ShouldBe(fixture.Input.TenantId);
            body.Query.AggregateId.ShouldBe(fixture.Input.TenantId);
            var identity = new AggregateIdentity("system", "tenants", fixture.Input.TenantId);
            var source = NativeSourceProofCodec.CreateSeed(identity, "01ARZ3NDEKTSV4RRFFQ69G5FAV");
            source = NativeSourceProofCodec.ExtendDigest(source, identity, 1, "fixture-tenant-read-1",
                Convert.ToHexStringLower(SHA256.HashData("fixture-native-tenant-read"u8)));
            var authority = new TenantReadAuthorityResult(fixture.Input.TenantId, body.PrincipalId,
                TenantAllowed, source, fixture.Time.Now);
            return new(HttpStatusCode.OK) { Content = JsonContent.Create(new SubmitQueryResponse("correlation",
                JsonSerializer.SerializeToElement(authority, JsonSerializerOptions.Web))) };
        }
        Calls++;
        OnProjection?.Invoke(Calls);
        body.Query.QueryType.ShouldBe(InspectProjectionCurrentQuery.QueryType);''')
 return s
edit('tests/Hexalith.Conversations.Server.Tests/ResolutionMetadata/ResolutionRebuildDelegatedTransport.cs',transport)
def session(s):
 s=s.replace('using Hexalith.EventStore.Contracts.Projections;', 'using Hexalith.EventStore.Contracts.Projections;\nusing Hexalith.EventStore.Contracts.Queries;')
 idx=s.index('    public void Dispose()')
 s=s[:idx]+'''    public async Task<QueryResult> ReadMetadataAsync()
    {
        var evidence = new ConversationResolutionNativeEvidence(_client, _fixture.Store);
        var authorization = new ConversationResolutionMetadataAuthorization(new ResolutionMetadataAccess(),
            _accessor, timeProvider: _fixture.Time, native: evidence);
        var handler = new GetConversationResolutionMetadataDomainQueryHandler(authorization,
            new ConversationProjectionReadStore(_fixture.Store), evidence);
        using var services = new ServiceCollection().AddSingleton<IHttpContextAccessor>(_accessor)
            .AddSingleton<IDomainQueryHandler>(handler).BuildServiceProvider();
        return await DomainQueryDispatcher.ExecuteAsync(services, ResolutionMetadataFixture.Query(), TestContext.Current.CancellationToken);
    }

'''+s[idx:]
 return s
edit('tests/Hexalith.Conversations.Server.Tests/ResolutionMetadata/ResolutionRebuildQuerySession.cs',session)
def tests(s):
 s=s.replace('using Hexalith.Conversations.Server.Projections;','using Hexalith.Conversations.Contracts.Queries;\nusing Hexalith.Conversations.Server.Projections;')
 old='''        fixture.Time.Now = fixture.Time.Now.AddHours(1);
        // The new request is deserialized through the endpoint; no private in-memory admission is reused.
        (await fixture.PostAsync<ProjectionDispatchResponse>("/project/rebuild/stage/v1", request)).Outcomes[0].Status.ShouldBe(ProjectionDispatchStatus.Completed);
        (await fixture.PostAsync<ProjectionDispatchResponse>("/project/rebuild/commit/v1", request)).Outcomes[0].Status.ShouldBe(ProjectionDispatchStatus.Completed);
        var recovered = await fixture.MetadataAsync();
        recovered.NativeSourceProof.ShouldBe(fixture.Input.NativeSourceProof);
        recovered.Freshness.ProjectionGeneratedAt.ShouldBe(ResolutionMetadataFixture.Started.AddSeconds(10));
        fixture.Backend.BeforeRead = key => AllowedRead(key).ShouldBeTrue(key);
        fixture.Backend.BeforeWrite = _ => throw new Xunit.Sdk.XunitException("Recovered query attempted mutation.");
        using var recoveredSession = new ResolutionRebuildQuerySession(fixture, catalog);
        (await recoveredSession.ReadAsync(recovered)).ShouldNotBeNull().Source.ShouldBe(fixture.Input.NativeSourceProof);'''
 new='''        var originalProof = fixture.Input.NativeSourceProof;
        await using var restarted = await fixture.RestartAsync(fixture.Time.Now.AddHours(1));
        restarted.App.ShouldNotBeSameAs(fixture.App);
        restarted.App.Services.ShouldNotBeSameAs(fixture.App.Services);
        restarted.Store.ShouldNotBeSameAs(fixture.Store);
        restarted.Time.ShouldNotBeSameAs(fixture.Time);
        restarted.Backend.ShouldBeSameAs(fixture.Backend);
        restarted.Input.NativeSourceProof.ShouldBe(originalProof);
        (await restarted.CatalogAsync()).CatalogFingerprint.ShouldBe(catalog);
        (await SnapshotAsync(restarted)).ShouldBe(before);
        // The original public request crosses a fresh host/container and is deserialized again. Only
        // retained SDK storage can recover the original immutable operation/time/generation.
        (await restarted.PostAsync<ProjectionDispatchResponse>("/project/rebuild/stage/v1", request)).Outcomes[0].Status.ShouldBe(ProjectionDispatchStatus.Completed);
        (await restarted.PostAsync<ProjectionDispatchResponse>("/project/rebuild/commit/v1", request)).Outcomes[0].Status.ShouldBe(ProjectionDispatchStatus.Completed);
        var recovered = await restarted.MetadataAsync();
        recovered.NativeSourceProof.ShouldBe(originalProof);
        recovered.Freshness.ProjectionGeneratedAt.ShouldBe(ResolutionMetadataFixture.Started.AddSeconds(10));
        var completed = await SnapshotAsync(restarted);
        (await restarted.PostAsync<ProjectionDispatchResponse>("/project/rebuild/commit/v1", request)).Outcomes[0].Status.ShouldBe(ProjectionDispatchStatus.Completed);
        (await SnapshotAsync(restarted)).ShouldBe(completed);
        restarted.Backend.BeforeRead = key => AllowedRead(key).ShouldBeTrue(key);
        restarted.Backend.BeforeWrite = _ => throw new Xunit.Sdk.XunitException("Recovered query attempted mutation.");
        using var recoveredSession = new ResolutionRebuildQuerySession(restarted, catalog);
        (await recoveredSession.ReadAsync(recovered)).ShouldNotBeNull().Source.ShouldBe(originalProof);
        restarted.Backend.BeforeRead = null; restarted.Backend.BeforeWrite = null;
        (await SnapshotAsync(restarted)).ShouldBe(completed);'''
 assert old in s;s=s.replace(old,new)
 idx=s.rfind('\n}')
 s=s[:idx]+'''
    [Theory]
    [InlineData("matching")]
    [InlineData("completion")]
    [InlineData("source")]
    [InlineData("catalog")]
    [InlineData("permission")]
    public async Task CompletedRebuildExecutesProductionMetadataQueryHandlerAndFinalAuthorityGates(string change)
    {
        await using var fixture = new ResolutionEnrollmentFixture();
        var catalog = (await fixture.CatalogAsync()).CatalogFingerprint!;
        var request = Rebuild(fixture, catalog);
        (await fixture.PostAsync<ProjectionDispatchResponse>("/project/rebuild/stage/v1", request)).Outcomes[0].Status.ShouldBe(ProjectionDispatchStatus.Completed);
        (await fixture.PostAsync<ProjectionDispatchResponse>("/project/rebuild/commit/v1", request)).Outcomes[0].Status.ShouldBe(ProjectionDispatchStatus.Completed);
        var metadata = await fixture.MetadataAsync();
        if (change == "completion")
        {
            string key = fixture.Backend.WrittenKeys.Distinct().Single(value => value.StartsWith("hxrmb:v1:completion:", StringComparison.Ordinal));
            var proof = (await fixture.Store.GetAsync<JsonObject>("statestore", key, Token)).Value!;
            proof["owners"]![0]!["messages"] = "unknown-nested-evidence";
            await fixture.Store.SaveAsync("statestore", key, proof, Token);
        }
        var before = await SnapshotAsync(fixture);
        int writes = fixture.Backend.WrittenKeys.Count, forbidden = 0;
        fixture.Backend.BeforeRead = key => { if (!AllowedRead(key)) { forbidden++; throw new Xunit.Sdk.XunitException("Metadata query attempted rich retrieval."); } };
        fixture.Backend.BeforeWrite = _ => throw new Xunit.Sdk.XunitException("Metadata query attempted mutation.");
        using var session = new ResolutionRebuildQuerySession(fixture, catalog);
        session.Transport.OnProjection = count =>
        {
            if (count != 2) return;
            if (change == "source") session.Transport.SourceOverride = fixture.Gateway.Proof with { SourceIncarnation = "01ARZ3NDEKTSV4RRFFQ69G5FAW" };
            if (change == "catalog") session.Transport.Catalog = "changed-catalog";
            if (change == "permission") session.Transport.TenantAllowed = false;
        };
        var query = await session.ReadMetadataAsync();
        if (change == "permission")
        {
            query.Success.ShouldBeFalse();
            query.ErrorMessage.ShouldBe("safe-denial");
        }
        else
        {
            query.Success.ShouldBeTrue();
            var result = query.GetPayload().Deserialize<ConversationResolutionMetadataResultV1>(JsonSerializerOptions.Web)!;
            if (change == "matching")
            {
                result.Metadata.ShouldBe(metadata.Metadata);
                result.Freshness.ShouldBe(metadata.Freshness);
                result.ResourceVersion.ShouldBe(JsonSerializer.Serialize(fixture.Input.NativeSourceProof, JsonSerializerOptions.Web));
                result.PermissionVersion.ShouldNotBeNullOrWhiteSpace();
                result.AuthorizedAt.ShouldBe(fixture.Time.Now);
            }
            else
            {
                result.Metadata.ShouldBeNull(); result.Freshness.ShouldBeNull();
                result.ResourceVersion.ShouldBeNull(); result.PermissionVersion.ShouldBeNull();
            }
        }
        session.Transport.Calls.ShouldBe(change == "completion" ? 1 : 2);
        session.Transport.TenantCalls.ShouldBeGreaterThanOrEqualTo(2);
        forbidden.ShouldBe(0);
        fixture.Backend.WrittenKeys.Count.ShouldBe(writes);
        fixture.Backend.BeforeRead = null; fixture.Backend.BeforeWrite = null;
        (await SnapshotAsync(fixture)).ShouldBe(before);
    }
''' +s[idx:]
 return s
edit('tests/Hexalith.Conversations.Server.Tests/Projections/ConversationResolutionRebuildCompletionTest.cs',tests)
