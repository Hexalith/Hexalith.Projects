from pathlib import Path
import json,hashlib,subprocess,tarfile,xml.etree.ElementTree as ET
root=Path.cwd();out=root/'_bmad-output/implementation-artifacts/evidence/6-4-native-provenance-20261021'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((out/'artifact-manifest.json').read_text());assert all(sha(out/f)==h for f,h in manifest['sha256'].items())
source=json.loads((out/'source-manifest.json').read_text())
for n,v in source['owners'].items():
 for f,h in v['files'].items():assert sha(root/'references'/n/f)==h,(n,f)
for f,h in source['binaries'].items():assert sha(root/f)==h,f
summary=json.loads((out/'verification-summary.json').read_text());assert summary['totals']=={'total':1534,'passed':1534,'failed':0,'skipped':0,'errors':0,'not-run':0}
with tarfile.open(out/'verification-artifacts.tar.xz') as t:
 names=t.getnames()
 for f in ['reviewed-sdk-tests.xml','reviewed-server-tests.xml','final-conversation-tests.xml','review/follow-up-confirmations.json','initial-snapshot.json','commands.jsonl']:
  assert f in names,f
 assert 'aspire-start.log' not in names and 'aspire-describe.json' not in names
 counts=[]
 for f in ['reviewed-sdk-tests.xml','reviewed-server-tests.xml','final-conversation-tests.xml']:
  r=ET.fromstring(t.extractfile(f).read());a=r.findall('.//assembly');counts.append(sum(int(v.get('passed','0')) for v in a));assert all(v.get('failed')=='0' and v.get('skipped')=='0' for v in a)
 assert counts==[86,393,1055],counts
spec=(root/'_bmad-output/implementation-artifacts/spec-6-4-prerequisite-current-authorized-resolution-evidence.md').read_text()
assert "status: 'in-progress'" in spec and 'implementation_authorized: false' in spec
assert 'status: blocked' in (root/'_bmad-output/implementation-artifacts/6-4-resolve-projects-with-transient-current-explanations.md').read_text()
assert '6-4-resolve-projects-with-transient-current-explanations: blocked' in (root/'_bmad-output/implementation-artifacts/sprint-status.yaml').read_text()
for d in [root,root/'references/Hexalith.EventStore',root/'references/Hexalith.Conversations']:
 assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=d).strip()
result={'command':['python3','verify_bundle.py'],'cwd':str(root),'exit_code':0,'artifact_hashes':'pass','source_and_binary_hashes':'pass','archived_native_xml_counts':counts,'untracked_evidence_integrity':'pass','parent_and_sprint':'blocked and unchanged','prerequisite':'in-progress; implementation_authorized false','staged_changes':'none','sanitization':'raw Aspire output excluded'}
(out/'closing-checks.json').write_text(json.dumps(result,indent=2)+'\n')
manifest['sha256']['closing-checks.json']=sha(out/'closing-checks.json');(out/'artifact-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
assert all(sha(out/f)==h for f,h in manifest['sha256'].items())
print(json.dumps(result))
