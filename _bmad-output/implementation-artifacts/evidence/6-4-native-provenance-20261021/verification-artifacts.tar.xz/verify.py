from pathlib import Path
import subprocess,sys
p=Path(__file__).parent
root=Path('/home/administrator/projects/hexalith/projects');sdk=root/'references/Hexalith.EventStore';conv=root/'references/Hexalith.Conversations'
runs=[
 ('independent-sdk-build',sdk,['dotnet','build','tests/Hexalith.EventStore.DomainService.Tests/Hexalith.EventStore.DomainService.Tests.csproj','-c','Debug','-p:UseHexalithProjectReferences=true','-m:1','--no-restore']),
 ('independent-server-build',sdk,['dotnet','build','tests/Hexalith.EventStore.Server.Tests/Hexalith.EventStore.Server.Tests.csproj','-c','Debug','-p:UseHexalithProjectReferences=true','-m:1','--no-restore']),
 ('independent-conversation-build',conv,['dotnet','build','tests/Hexalith.Conversations.Server.Tests/Hexalith.Conversations.Server.Tests.csproj','-c','Debug','-p:UseHexalithProjectReferences=true','-m:1','--no-restore']),
 ('independent-sdk-tests',sdk,['dotnet','tests/Hexalith.EventStore.DomainService.Tests/bin/Debug/net10.0/Hexalith.EventStore.DomainService.Tests.dll','-result-xml',str(p/'independent-sdk-tests.xml')]),
 ('independent-server-tests',sdk,['dotnet','tests/Hexalith.EventStore.Server.Tests/bin/Debug/net10.0/Hexalith.EventStore.Server.Tests.dll','-class','*NamedProjectionDispatchCoordinatorTests','-class','*ProjectionSourceGuard*','-class','*NativeSource*','-class','*AggregateActorGetEventsTests','-class','*StreamsControllerTests','-result-xml',str(p/'independent-server-tests.xml')]),
 ('independent-conversation-tests',conv,['dotnet','tests/Hexalith.Conversations.Server.Tests/bin/Debug/net10.0/Hexalith.Conversations.Server.Tests.dll','-result-xml',str(p/'independent-conversation-tests.xml')])]
for label,cwd,cmd in runs:
 code=subprocess.call([sys.executable,str(p/'record.py'),'--cwd',str(cwd),label,'--',*cmd])
 if code:sys.exit(code)
