import subprocess,json,difflib,hashlib
from pathlib import Path
root=Path('/home/administrator/projects/hexalith/projects'); out=Path(__file__).parent
before=json.loads((out/'implementation/source-before.json').read_text())
parts=[]; watched=[]; manifests={}
for n in ['Hexalith.EventStore','Hexalith.Conversations']:
 p=root/'references'/n; base=before[n]['head']; prefix='references/'+n+'/'
 changes=subprocess.check_output(['git','diff','--no-ext-diff','--src-prefix=a/'+prefix,'--dst-prefix=b/'+prefix,base],cwd=p)
 files=subprocess.check_output(['git','diff','--name-only',base],cwd=p).decode().splitlines()
 untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=p).decode().splitlines()
 for f in untracked:
  fpath=p/f
  if fpath.is_file():
   files.append(f)
   try:changes+=''.join(difflib.unified_diff([],fpath.read_text().splitlines(keepends=True),fromfile='a/'+prefix+f,tofile='b/'+prefix+f)).encode()
   except UnicodeDecodeError: changes+=('Binary untracked file '+prefix+f+'\n').encode()
 (out/(n+'-review.patch')).write_bytes(changes)
 parts.append(('Owner: '+n+'; baseline '+base+'\n').encode()+changes)
 manifests[n]={'baseline':base,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=p).decode().strip(),'files':{f:hashlib.sha256((p/f).read_bytes()).hexdigest() for f in files if (p/f).is_file()}}
 watched += [str(p/f) for f in files if (p/f).is_file()]
rootpatch=subprocess.check_output(['git','diff','4adca9ace85827d08fdb4b401879ebf2435e58b5','--','_bmad-output/implementation-artifacts/spec-6-4-prerequisite-current-authorized-resolution-evidence.md'],cwd=root)
parts.append(rootpatch)
(out/'review-input.patch').write_bytes(b'\n'.join(parts))
(out/'historical-workspace.patch').write_bytes(subprocess.check_output(['git','diff','b0caf2b5c25a1f761abed685c7c9ef811732c6fb'],cwd=root))
(out/'review-source-manifest.json').write_text(json.dumps(manifests,indent=2)+'\n')
(out/'watched-files.json').write_text(json.dumps(watched,indent=2)+'\n')
print(json.dumps({'review_diff_bytes':(out/'review-input.patch').stat().st_size,'historical_diff_bytes':(out/'historical-workspace.patch').stat().st_size,'files':{k:len(v['files']) for k,v in manifests.items()}}))
