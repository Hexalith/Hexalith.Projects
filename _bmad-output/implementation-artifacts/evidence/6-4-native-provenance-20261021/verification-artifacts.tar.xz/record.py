import argparse, subprocess, json, time, hashlib
from pathlib import Path
from datetime import datetime,timezone
p=argparse.ArgumentParser();p.add_argument('--cwd',required=True);p.add_argument('label');p.add_argument('command',nargs=argparse.REMAINDER);a=p.parse_args();cmd=a.command[1:] if a.command[:1]==['--'] else a.command
root=Path(__file__).parent
def hashes():
 watch=root/'watched-files.json'
 return {f:hashlib.sha256(Path(f).read_bytes()).hexdigest() if Path(f).is_file() else None for f in json.loads(watch.read_text())} if watch.exists() else {}
before=hashes();start=time.time(); started=datetime.now(timezone.utc).isoformat()
with (root/(a.label+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=a.cwd,stdout=f,stderr=subprocess.STDOUT)
after=hashes()
rec={'label':a.label,'cwd':a.cwd,'command':cmd,'exit_code':r.returncode,'seconds':round(time.time()-start,3),'started_utc':started,'finished_utc':datetime.now(timezone.utc).isoformat(),'log':a.label+'.log','source_before':before,'source_after':after,'source_unchanged':before==after}
with (root/'commands.jsonl').open('a') as f:f.write(json.dumps(rec)+'\n')
print(json.dumps({k:v for k,v in rec.items() if k not in ['source_before','source_after']}));print((root/(a.label+'.log')).read_text()[-2500:]);raise SystemExit(r.returncode)
