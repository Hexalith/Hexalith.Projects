from pathlib import Path
import json,hashlib,subprocess,re,xml.etree.ElementTree as ET,tarfile,shutil
from datetime import datetime,timezone
root=Path('/home/administrator/projects/hexalith/projects'); tmp=Path(__file__).parent
out=root/'_bmad-output/implementation-artifacts/evidence/6-4-native-provenance-20261021'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def git(p,*a):return subprocess.check_output(['git',*a],cwd=p).decode().strip()
def readxml(name):
 tree=ET.parse(tmp/name); assemblies=tree.findall('.//assembly'); tests=tree.findall('.//test')
 counts={k:sum(int(x.get(k,'0')) for x in assemblies) for k in ['total','passed','failed','skipped','errors','not-run']}
 return {'report':name,**counts,'classes':sorted({x.get('type','') for x in tests})},[{'name':x.get('name'),'result':x.get('result')} for x in tests]
summary=[];cases=[]
for label,name in [('SDK projection/native/delegation','reviewed-sdk-tests.xml'),('Producer/scheduler/native/controller','reviewed-server-tests.xml'),('Full Conversation Server','final-conversation-tests.xml')]:
 r,t=readxml(name);r['lane']=label;assert r['total']>0 and r['failed']==r['skipped']==r['errors']==0;summary.append(r);cases+=t
out.mkdir(exist_ok=True)
totals={k:sum(r[k] for r in summary) for k in ['total','passed','failed','skipped','errors','not-run']}
dump(out/'verification-summary.json',{'scope':'Final independent Debug source checks. No full-SDK all-pass, Release/package/deployment, production authority, G-4 or parent acceptance claim.','runs':summary,'totals':totals,'superseded_full_runs':[readxml('independent-sdk-tests.xml')[0],readxml('independent-conversation-tests.xml')[0],readxml('reviewed-conversation-tests.xml')[0]]})
dump(tmp/'executed-final-tests.json',cases)
records=[json.loads(x) for x in (tmp/'commands.jsonl').read_text().splitlines()]
dump(out/'command-records.json',records)
source=json.loads((tmp/'review-source-manifest.json').read_text()); binaries={}
for rel in ['references/Hexalith.EventStore/tests/Hexalith.EventStore.DomainService.Tests/bin/Debug/net10.0/Hexalith.EventStore.DomainService.Tests.dll','references/Hexalith.EventStore/tests/Hexalith.EventStore.Server.Tests/bin/Debug/net10.0/Hexalith.EventStore.Server.Tests.dll','references/Hexalith.Conversations/tests/Hexalith.Conversations.Server.Tests/bin/Debug/net10.0/Hexalith.Conversations.Server.Tests.dll','references/Hexalith.EventStore/src/Hexalith.EventStore.Contracts/bin/Debug/net10.0/Hexalith.EventStore.Contracts.dll','references/Hexalith.EventStore/src/Hexalith.EventStore.DomainService/bin/Debug/net10.0/Hexalith.EventStore.DomainService.dll','references/Hexalith.EventStore/src/Hexalith.EventStore.Server/bin/Debug/net10.0/Hexalith.EventStore.Server.dll','references/Hexalith.Conversations/src/Hexalith.Conversations.Server/bin/Debug/net10.0/Hexalith.Conversations.Server.dll']:
 binaries[rel]=sha(root/rel)
dump(out/'source-manifest.json',{'captured_utc':datetime.now(timezone.utc).isoformat(),'projects_head':git(root,'rev-parse','HEAD'),'owners':source,'binaries':binaries,'note':'All production sources remained unchanged across final checks. One subsequent Conversation rebuild-fixture correction was rebuilt and followed by the final full Conversation run; earlier runs retain their exact source hashes.'})
shutil.copyfile(tmp/'review-input.patch',out/'reviewed-owner.patch');shutil.copyfile(tmp/'runtime-baseline.json',out/'runtime-baseline.json')
initial=json.loads((tmp/'initial-snapshot.json').read_text());protected=json.loads((tmp/'protected-file-comparison.json').read_text())
for rel,v in protected.items():
 repo,f=next((r,rel[len(r)+1:]) for r in sorted(initial,key=len,reverse=True) if rel.startswith(r+'/'))
 p=root/repo/f
 v['current']=sha(p) if p.is_file() else None;v['unchanged']=v['current']==v['initial']
changed=[k for k,v in protected.items() if not v['unchanged']]
allowed=['./_bmad-output/implementation-artifacts/deferred-work.md','references/Hexalith.EventStore/src/Hexalith.EventStore/Controllers/StreamsController.cs','references/Hexalith.EventStore/tests/Hexalith.EventStore.Server.Tests/Controllers/StreamsControllerTests.cs']
assert set(changed)<=set(allowed),(changed,allowed)
path='_bmad-output/implementation-artifacts/spec-6-4-prerequisite-current-authorized-resolution-evidence.md'
old=subprocess.check_output(['git','show','4adca9ace85827d08fdb4b401879ebf2435e58b5:'+path],cwd=root); now=(root/path).read_bytes()
block=lambda b:re.search(rb'<frozen-after-approval\b.*?</frozen-after-approval>',b,re.S).group()
assert block(old)==block(now)
oldledger=subprocess.check_output(['git','show','4adca9ace85827d08fdb4b401879ebf2435e58b5:_bmad-output/implementation-artifacts/deferred-work.md'],cwd=root)
assert (root/'_bmad-output/implementation-artifacts/deferred-work.md').read_bytes().startswith(oldledger)
states={}
for repo in initial:
 p=root/repo;states[repo]={'initial_head':initial[repo]['head'],'closing_head':git(p,'rev-parse','HEAD'),'status':git(p,'status','--porcelain=v1'),'staged_changes':git(p,'diff','--cached','--name-only'),'logical_index_sha256':hashlib.sha256(subprocess.check_output(['git','ls-files','--stage','-z'],cwd=p)).hexdigest()}
 assert not states[repo]['staged_changes'],states[repo]
dump(tmp/'protected-file-comparison-final.json',protected)
dump(out/'preservation.json',{'protected_files_checked':len(protected),'unchanged':len(protected)-len(changed),'intentional_changes':changed,'frozen_block_sha256':hashlib.sha256(block(now)).hexdigest(),'frozen_block_unchanged':True,'deferred_ledger_original_prefix_unchanged':True,'parent_story_and_sprint':'Unchanged; both remain blocked. Selected D1-D6 and dependency/configuration hashes unchanged.','prior_native_head_work':'Preserved. Controller and its tests extended only to retain exact native UserId; five other original changed source/test files retain initial hashes. The entire prior evidence bundle is unchanged.','git_states':states,'concurrent_git_activity':'External activity advanced Projects from first observed 99977941d69827675ef710157655b9f84fda4a43 through snapshot 4adca9ace85827d08fdb4b401879ebf2435e58b5 to 1c4d814bc0ae3cebabe853bac30e2cdd50f80af2, and advanced several owner heads/gitlinks during inspection. This run performed no Git mutations; byte-identical head/index preservation is not claimed across that external activity. See archived concurrent-state and initial/handoff snapshots.'})
rows=[]
s=(root/path).read_text();section=s.split('### Native provenance source review — 2026-10-21',1)[1].split('## Design Notes',1)[0]
for line in section.splitlines():
 if line.startswith('| NP-'):
  parts=[x.strip() for x in line.strip('|').split('|')];rows.append(dict(zip(['finding','verdict','route','evidence'],parts)))

for row in rows: row['resolution']='deferred existing layout blocker' if row['finding']=='NP-P2' else 'corrected; final execution and review confirmation retained'
dump(out/'review-results.json',{'reviewers':3,'separate_claims':15,'additional_parent_findings':3,'findings':rows,'follow_up':'Blind reviewer confirmed NP-B1..B10 resolved; edge reviewer confirmed NP-E1/E2 resolved; verification reviewer confirmed NP-V1..V3 and the final NP-P3 helper correction. All confirmations were independent source inspection; parent execution is authoritative.','deferred':['NP-P2: full SDK authoring guardrail requires absent nested Tenants checkout.'],'allocation_measurement':{'payload_bytes':8388608,'checks':5,'allocated_bytes':8720,'scope':'Proof mutation hashing only; not full-result or production performance qualification.'}})
shutil.copyfile(tmp/'implementation/trust-boundary.md',out/'trust-boundary.md')
(out/'.gitattributes').write_text('* -text\n')
rows_md='\n'.join(f"| {r['lane']} | {r['passed']} | {r['failed']} | {r['skipped']} |" for r in summary)
(out/'README.md').write_text(f'''# Story 6.4 native Conversation generation provenance

Status: **reviewed source slice complete; prerequisite in progress; Story 6.4 blocked**.

EventStore carries a producer-frozen native incarnation, complete prefix and head with the original full-prefix projection input. SDK dispatch verifies that original cut before evolution/materialization. Conversation metadata, lasting generation, digest/fingerprint and selected owner batch retain exactly the admitted proof. Existing SDK atomic writes and recovery remain authoritative. Conversation metadata queries retrieve no Conversation events, detail or index and compare complete current native evidence; query reads never certify or repair older generations.

Original proof or absence is frozen in existing durable retry work and retained across ordinary, compatible, recovery and reconciliation requests. An append can verify the original supplied cut within an authenticated complete prefix; its newer head never replaces the cut. Legacy generations, old retry records, missing verification authority, unsupported protected/evolved provenance and incomplete rebuild/recovery remain unavailable for resolution metadata. Ordinary protected/legacy projection delivery is preserved. The authenticated native event path preserves exact actor metadata; ordinary stream normalization and head-only inspection stay intact.

## Independent verification

| Final Debug source check | Passed | Failed | Skipped |
| --- | ---: | ---: | ---: |
{rows_md}
| Total | {totals['passed']} | 0 | 0 |

Independent test-project builds succeeded with zero warnings/errors. Every command retains its actual argv, working directory, timing and before/after source hashes in [command records](command-records.json). [Native result counts](verification-summary.json), [full source revisions and binary hashes](source-manifest.json), and the [reviewed owner patch](reviewed-owner.patch) bind these results to the uncommitted owner sources. Final native XML, complete logs, executed test names, recorder, original/review snapshots and superseded failures are in [verification artifacts](verification-artifacts.tar.xz).

The earlier full SDK run was 1090/1091: `DomainModuleAuthoringGuardrailTests.TenantsDomainService_DoesNotReferenceGeneratedApiHostOrDeclarePerMessageControllers` requires an absent nested `EventStore/references/Hexalith.Tenants` project. Nested initialization is unauthorized. The guard and dependency layout remain unchanged; focused SDK results above are separate. Earlier full Conversation runs failed two stale legacy expectations and then 28 cases sharing an unconfigured rebuild fixture. The corrected fixture supplies the exact supported native gateway and an untrusted JSON request; the final full suite above supersedes those runs. No failed or filtered run is promoted as a pass.

Coverage includes tampering, incarnation/replacement, source advance, frozen retry proof and absence, persisted scheduler scope/replacement checks, original proof across replay/rebuild/recovery, real rebuild/reconciliation admission, actual raw-envelope codec interoperability, 101-event paging, production signed delegated adapter success/refusal, and content-free persisted reads. Mutation hashing measured 8,720 allocated bytes for five checks over an 8 MiB payload; this does not qualify production performance.

## Review and preservation

Three context-free reviewers filed fifteen separate claims. Parent execution added three findings. [Individual verdicts and follow-up confirmations](review-results.json) retain all claims; NP-P2 is the existing layout blocker above. All in-scope corrections passed parent verification. The [prerequisite review log](../../spec-6-4-prerequisite-current-authorized-resolution-evidence.md#native-provenance-source-review--2026-10-21) records every disposition.

[Preservation checks](preservation.json) bind parent story/spec, sprint, frozen intent, D1-D6, dependencies/configuration and existing native-head work. Concurrent external commits changed workspace/owner heads and gitlink state during inspection; their revisions and snapshots are retained. This run performed no staging, commit, push, branch, dependency, gitlink, submodule or deployment mutation. The prior evidence bundle is unchanged.

## Remaining blockers

Production native read enrollment and legacy-compatible guarded Conversation composition, content-free post-rebuild promotion, installation/all-writer coverage, cold-activation zero-write evidence, deployed owner authority, native Folder/Organization generation binding, committed File/Projects reference mapping, production metadata mutation adoption, exact-current qualification and accepted Projects G-4 evidence remain incomplete. Protected/evolved or retained-away source inputs without supported exact native admission stay unproven. Legacy generations receive no migration or retrospective certificate.

The [runtime baseline](runtime-baseline.json) started the exact Projects AppHost with source references, observed security Unhealthy and dependents Waiting, and stopped it normally before edits. No healthy live topology, production acceptance or installation-wide zero-write result is claimed. RTI and parent resolution handlers remain gated; parent Story 6.4 and sprint tracking remain blocked.
''')
# The archive intentionally excludes unsanitized Aspire output, including dashboard URLs.
with tarfile.open(out/'verification-artifacts.tar.xz','w:xz') as archive:
 for p in sorted(tmp.rglob('*')):
  if p.is_file() and p.name not in ['aspire-start.log','aspire-describe.json']:
   archive.add(p,arcname=str(p.relative_to(tmp)),recursive=False)
files={str(p.relative_to(out)):sha(p) for p in out.rglob('*') if p.is_file() and p.name!='artifact-manifest.json'}
dump(out/'artifact-manifest.json',{'sha256':files,'scope':'All bundle files except this self-referential manifest; native logs/XML are retained inside the hashed archive.'})
print(json.dumps({'bundle':str(out),'totals':totals,'protected':len(protected),'intentional_changes':changed,'files':len(files)}))
