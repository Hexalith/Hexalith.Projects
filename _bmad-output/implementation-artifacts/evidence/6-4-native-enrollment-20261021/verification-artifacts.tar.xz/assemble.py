from pathlib import Path
import hashlib,json,tarfile,xml.etree.ElementTree as ET
ROOT=Path('/home/administrator/projects/hexalith/projects')
OUT=Path('/tmp/story64-enrollment-20261021')
BUNDLE=ROOT/'_bmad-output/implementation-artifacts/evidence/6-4-native-enrollment-20261021'
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(path,data):path.write_text(json.dumps(data,indent=2)+'\n')
records=[];runs=[]
for path in OUT.glob('*.json'):
    data=json.loads(path.read_text())
    if not isinstance(data,dict) or 'argv' not in data:continue
    record={k:v for k,v in data.items() if k not in ['source_before','source_after','binary_before','binary_after']}
    for key in ['source_before','source_after','binary_before','binary_after']:
        if key in data:record[key+'_sha256']=sha(json.dumps(data[key],sort_keys=True,separators=(',',':')).encode())
    record['archive_record']=path.name
    record['source_unchanged']=data['source_before']==data['source_after']
    if 'binary_before' in data:record['binary_unchanged']=data['binary_before']==data['binary_after']
    xml_flag=next((flag for flag in ['-result-xml','-xml'] if flag in data['argv']),None)
    if xml_flag:
        xml=Path(data['argv'][data['argv'].index(xml_flag)+1])
        if xml.exists():
            tests=list(ET.parse(xml).getroot().iter('test'))
            failed=[{'name':t.get('name'),'message':''.join(t.find('failure/message').itertext()) if t.find('failure/message') is not None else ''} for t in tests if t.get('result')=='Fail']
            run={'label':data['label'],'total':len(tests),'passed':sum(t.get('result')=='Pass' for t in tests),'failed':sum(t.get('result')=='Fail' for t in tests),'skipped':sum(t.get('result')=='Skip' for t in tests),'failures':failed,'xml':xml.name,'exit_code':data['exit_code'],'source_unchanged':record['source_unchanged'],'binary_unchanged':record.get('binary_unchanged'),'final_verification':data['label'].startswith('final-')}
            dump(OUT/(data['label']+'-executed-tests.json'),[{'name':t.get('name'),'result':t.get('result')} for t in tests])
            run['disposition']='blocked-existing-nested-layout' if data['label']=='final-sdk-domain-full' else 'final-pass' if run['final_verification'] else 'superseded-failed' if run['failed'] or run['exit_code'] else 'superseded-pass'
            runs.append(run)
    record['disposition']='blocked-existing-nested-layout' if data['label']=='final-sdk-domain-full' else 'final-pass' if data['label'].startswith('final-') else 'failed-attempt' if data['exit_code'] else 'earlier-or-closing-check'
    records.append(record)
records.sort(key=lambda r:r['start_utc']);runs.sort(key=lambda r:r['label'])
dump(BUNDLE/'command-records.json',records)
dump(BUNDLE/'verification-summary.json',runs)
initial=json.loads((OUT/'initial-snapshot.json').read_text());final=json.loads((OUT/'final-snapshot.json').read_text())
configs=lambda d:{k:v for k,v in d['sources'].items() if k.endswith(('.csproj','.props','.targets','.slnx','global.json','.editorconfig','.gitattributes','.gitmodules','AGENTS.md'))}
reviewed=json.loads((OUT/'review-2-snapshot.json').read_text())
assert final['sources']==reviewed['sources'], 'Reviewed source changed'
for r in records:
    if r['label'].startswith('final-'):
        raw=json.loads((OUT/r['archive_record']).read_text())
        assert raw['source_before']==final['sources'] and raw['source_after']==final['sources'], 'Final run source mismatch: '+r['label']
        if '-result-xml' in raw['argv']:assert raw.get('binary_before')==raw.get('binary_after'), 'Test binaries changed'
changed={k:v for k,v in final['sources'].items() if initial['sources'].get(k)!=v}
source={'initial_revisions':{k:v['head'] for k,v in initial['repos'].items()},'final_revisions':{k:v['head'] for k,v in final['repos'].items()},'changed_source_files':changed,'final_source_snapshot_sha256':sha((OUT/'final-snapshot.json').read_bytes()),'full_snapshot_archive_path':'final-snapshot.json','binary_hashes':{r['label']:json.loads((OUT/r['archive_record']).read_text()).get('binary_after',{}) for r in records if r['label'].startswith('final-') and r.get('binary_after_sha256')}}
for name in ['owner-cumulative.patch','enrollment-incremental.patch']:
    (BUNDLE/name).write_bytes((OUT/name).read_bytes())
    source[name+'_sha256']=sha((OUT/name).read_bytes())
source['source_roots']={'Projects':str(ROOT),'EventStore':str(ROOT/'references/Hexalith.EventStore'),'Conversations':str(ROOT/'references/Hexalith.Conversations')}
source['reviewed_source_matches_final']=True
source['all_final_build_and_test_source_maps_match_final']=True
source['instruction_snapshot_archive_path']='workflow-provenance.json'
dump(BUNDLE/'source-manifest.json',source)
preservation={'protected_hashes_unchanged':initial['protected']==final['protected'],'protected_initial':initial['protected'],'protected_final':final['protected'],'configuration_dependencies_unchanged':configs(initial)==configs(final),'indexes_unchanged':{k:initial['repos'][k]['index']==final['repos'][k]['index'] for k in initial['repos']},'heads_unchanged':{k:initial['repos'][k]['head']==final['repos'][k]['head'] for k in initial['repos']},'initial_status':{k:v['status'] for k,v in initial['repos'].items()},'final_status':{k:v['status'] for k,v in final['repos'].items()},'existing_dirty_bytes_retained_in_archive':'initial-files/ (prior evidence duplicated there is omitted; its hashes are protected above)','actions':'Authorized source/evidence edits only; no staging, commits, pushes, branch changes, dependencies/gitlinks, nested submodule initialization or deployment.'}
assert preservation['protected_hashes_unchanged'], 'Protected artifact changed'
assert preservation['configuration_dependencies_unchanged'], 'Dependency/configuration changed'
assert all(preservation['indexes_unchanged'].values()), 'Index changed'
assert all(preservation['heads_unchanged'].values()), 'HEAD changed'
assert not any(k.startswith('Projects/') for k in changed), 'Projects source changed'
dump(BUNDLE/'preservation.json',preservation)
s=(OUT/'runtime-describe.log').read_text();desc=json.loads(s[s.index('{'):])
runtime={'commands':[{k:r[k] for k in ['label','cwd','argv','exit_code','start_utc','seconds']} for r in records if r['label'].startswith('runtime-')],'resources':[{k:r[k] for k in ['name','state','healthStatus'] if k in r} for r in desc.get('resources',[])],'live_acceptance':False,'other_apphosts':'Pre-existing Tenants, EventStore and story49 qualification AppHosts were left untouched.','output_handling':'Resource/state summary retained. Raw discovery output containing dashboard session grants or environment values is excluded from the archive.','raw_log_sha256':{p.name:sha(p.read_bytes()) for p in OUT.glob('runtime-*.log')}}
dump(BUNDLE/'runtime-baseline.json',runtime)
with tarfile.open(BUNDLE/'verification-artifacts.tar.xz','w:xz',preset=6) as archive:
    for p in sorted(OUT.rglob('*')):
        rel=p.relative_to(OUT)
        if not p.is_file() or '__pycache__' in rel.parts or p.name=='assembly-summary.log':continue
        if p.name in ['runtime-ps.log','runtime-start.log','runtime-describe.log']:continue
        if str(rel).startswith('initial-files/Projects/_bmad-output/implementation-artifacts/evidence/'):continue
        archive.add(p,arcname=str(rel),recursive=False)
print(json.dumps({'final_runs':[r for r in runs if r['final_verification']],'changed_source_count':len(changed),'preservation_passed':True,'archive_bytes':(BUNDLE/'verification-artifacts.tar.xz').stat().st_size},indent=2))
