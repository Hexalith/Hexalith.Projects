from pathlib import Path
import json,hashlib,re,tarfile
root=Path('/home/administrator/projects/hexalith/projects')
bundle=root/'_bmad-output/implementation-artifacts/evidence/6-4-native-enrollment-20261021'
out=Path('/tmp/story64-enrollment-20261021')
snapshot=json.loads((out/'final-snapshot.json').read_text())
roots={'Projects':root,'EventStore':root/'references/Hexalith.EventStore','Conversations':root/'references/Hexalith.Conversations'}
for logical,digest in snapshot['sources'].items():
 owner,relative=logical.split('/',1);p=roots[owner]/relative
 assert hashlib.sha256(p.read_bytes()).hexdigest()==digest,logical
preservation=json.loads((bundle/'preservation.json').read_text())
assert preservation['protected_hashes_unchanged'] and preservation['configuration_dependencies_unchanged']
assert all(preservation['indexes_unchanged'].values()) and all(preservation['heads_unchanged'].values())
assert all(json.loads((bundle/'coverage-map.json').read_text()).values())
summary=json.loads((bundle/'verification-summary.json').read_text())
assert len(summary)==20 and sum(not r['final_verification'] for r in summary)==15
for row in summary:
 if row['final_verification']:
  assert row['source_unchanged'] and row['binary_unchanged']
  assert row['failed']==(1 if row['label']=='final-sdk-domain-full' else 0)
for p in bundle.glob('*.md'):
 for target in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  if not target.startswith(('http:','https:','#')):assert (p.parent/target.split('#')[0]).exists(),target
with tarfile.open(bundle/'verification-artifacts.tar.xz','r:xz') as archive:
 names=set(archive.getnames())
 assert not {'runtime-ps.log','runtime-start.log','runtime-describe.log'} & names
 for row in summary:assert row['xml'] in names
 assert 'final-snapshot.json' in names and 'review-2-snapshot.json' in names
assert "status: 'in-progress'" in (root/'_bmad-output/implementation-artifacts/spec-6-4-prerequisite-current-authorized-resolution-evidence.md').read_text().split('---',2)[1]
print('PASS: final reviewed sources, protected artifacts, configuration/dependencies, indexes/heads, all 20 run records/XML, complete requested coverage, artifact links, runtime output exclusion and prerequisite in-progress status')
