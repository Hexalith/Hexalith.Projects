using System.Text.Json;

using Dapr;

using Hexalith.EventStore.Client.Conventions;
using Hexalith.EventStore.Client.Events;
using Hexalith.EventStore.Client.Projections;
using Hexalith.EventStore.Contracts.Projections;

using Microsoft.Extensions.DependencyInjection;

namespace Hexalith.EventStore.DomainService;

/// <summary>
/// Routes a <see cref="ProjectionRequest"/> to the registered <see cref="IDomainProjectionHandler"/> whose
/// <see cref="IDomainProjectionHandler.Domain"/> matches. Backs the SDK's <c>/project</c> endpoint, mirroring
/// how <see cref="DomainServiceRequestRouter"/> backs <c>/process</c> and <see cref="DomainQueryDispatcher"/>
/// backs <c>/query</c>.
/// </summary>
public static class DomainProjectionDispatcher {
    private static readonly JsonSerializerOptions SerializerOptions = new(JsonSerializerDefaults.Web);

    internal static ProjectionRequest UpcastRequest(IServiceProvider serviceProvider, ProjectionRequest request)
    {
        EventPayloadEvolutionRegistry? evolution = serviceProvider.GetService<EventPayloadEvolutionRegistry>();
        if (evolution is null || request.Events.Length == 0)
        {
            return request;
        }

        var events = new ProjectionEventDto[request.Events.Length];
        for (int index = 0; index < events.Length; index++)
        {
            events[index] = UpcastEvent(evolution, request.Events[index]);
        }

        return request with { Events = events };
    }

    internal static ProjectionEventDto UpcastEvent(EventPayloadEvolutionRegistry? evolution,
        ProjectionEventDto item)
    {
        if (evolution is null) return item;
        ResolvedEventPayload effective = evolution.Read(item.EventTypeName, item.StoredPayloadVersion,
            item.Payload, item.SequenceNumber);
        if (effective.EventType is not null
            && !string.Equals(item.SerializationFormat, "json", StringComparison.OrdinalIgnoreCase))
            throw new EventPayloadEvolutionException(item.EventTypeName, item.StoredPayloadVersion ?? 1,
                item.SequenceNumber, "unsupported serialization format");
        return item with { EventTypeName = effective.EventTypeName, Payload = effective.Payload };
    }
    /// <summary>
    /// Projects a request by dispatching it to the matching domain projection handler.
    /// </summary>
    /// <param name="serviceProvider">The scoped request service provider.</param>
    /// <param name="request">The projection request to dispatch.</param>
    /// <returns>
    /// The handler's <see cref="ProjectionResponse"/>, or <c>null</c> when no handler is registered for the
    /// request's domain (the endpoint maps a <c>null</c> result to <c>404 Not Found</c>).
    /// </returns>
    public static ProjectionResponse? Project(IServiceProvider serviceProvider, ProjectionRequest request) {
        return Project(serviceProvider, request, CancellationToken.None);
    }

    /// <summary>Dispatches a full replay request with its originating cancellation token.</summary>
    public static ProjectionResponse? Project(IServiceProvider serviceProvider, ProjectionRequest request, CancellationToken cancellationToken) {
        ArgumentNullException.ThrowIfNull(serviceProvider);
        ArgumentNullException.ThrowIfNull(request);
        cancellationToken.ThrowIfCancellationRequested();
        DomainProjectionEvolutionAdmission.RequireLegacy(request);

        IDomainProjectionHandler? handler = DomainProjectionHandlerRouteValidator
            .MaterializeAndValidate(serviceProvider.GetServices<IDomainProjectionHandler>())
            .FirstOrDefault(h => string.Equals(h.Domain, request.Domain, StringComparison.OrdinalIgnoreCase));

        if (handler is null) return null;
        ProjectionRequest compatible = UpcastRequest(serviceProvider, request);
        return MeasureHandler(handler).Project(compatible, cancellationToken);
    }

    /// <summary>Dispatches one v2 request to every exact admitted named projection handler.</summary>
    /// <param name="serviceProvider">The scoped request service provider.</param>
    /// <param name="dispatchRequest">The version-2 dispatch request.</param>
    /// <param name="options">The validated dispatch bounds.</param>
    /// <param name="catalogRegistry">The fingerprints issued by this service's metadata endpoint.</param>
    /// <param name="cancellationToken">Propagates request cancellation and prevents later starts.</param>
    /// <returns>A bounded deterministic per-projection response.</returns>
    public static async Task<ProjectionDispatchResponse> DispatchAsync(
        IServiceProvider serviceProvider,
        ProjectionDispatchRequest dispatchRequest,
        ProjectionDispatchOptions options,
        DomainProjectionCatalogRegistry catalogRegistry,
        CancellationToken cancellationToken) {
        ArgumentNullException.ThrowIfNull(serviceProvider);
        ArgumentNullException.ThrowIfNull(dispatchRequest);
        ArgumentNullException.ThrowIfNull(options);
        ArgumentNullException.ThrowIfNull(catalogRegistry);
        options.Validate();
        ValidateRequest(dispatchRequest, options);
        if (!catalogRegistry.Contains(dispatchRequest.CatalogFingerprint)) {
            throw new ProjectionDispatchValidationException(ProjectionDispatchReasonCodes.UnsupportedCapability);
        }

        if (!catalogRegistry.Authorizes(
            dispatchRequest.CatalogFingerprint,
            dispatchRequest.Request.Domain,
            dispatchRequest.ProjectionTypes)) {
            throw new ProjectionDispatchValidationException(ProjectionDispatchReasonCodes.UnsupportedRoute);
        }

        return await DispatchCoreAsync(serviceProvider, dispatchRequest, options, cancellationToken)
            .ConfigureAwait(false);
    }

    /// <summary>Reconciles terminal named routes against the authoritative stable dispatch input.</summary>
    /// <param name="serviceProvider">The scoped request service provider.</param>
    /// <param name="dispatchRequest">The terminal routes and their original dispatch input.</param>
    /// <param name="options">The validated dispatch bounds.</param>
    /// <param name="identityOptions">The authoritative local service binding.</param>
    /// <param name="cancellationToken">Propagates reconciliation cancellation.</param>
    /// <returns>One bounded reconciliation outcome per requested terminal route.</returns>
    public static async Task<ProjectionDispatchResponse> ReconcileAsync(
        IServiceProvider serviceProvider,
        ProjectionDispatchRequest dispatchRequest,
        ProjectionDispatchOptions options,
        DomainProjectionIdentityOptions identityOptions,
        CancellationToken cancellationToken) {
        ArgumentNullException.ThrowIfNull(serviceProvider);
        ArgumentNullException.ThrowIfNull(dispatchRequest);
        ArgumentNullException.ThrowIfNull(options);
        ArgumentNullException.ThrowIfNull(identityOptions);
        options.Validate();
        identityOptions.Validate();
        ValidateRequest(dispatchRequest, options);

        IAsyncDomainProjectionHandler[] allHandlers = DomainProjectionHandlerRouteValidator
            .MaterializeAndValidateNamed(serviceProvider.GetServices<IAsyncDomainProjectionHandler>(), options);
        ProjectionDispatchRoute[] authoritativeRoutes = [.. allHandlers
            .Where(handler => string.Equals(handler.Domain, dispatchRequest.Request.Domain, StringComparison.Ordinal))
            .Select(handler => new ProjectionDispatchRoute(handler.Domain, handler.ProjectionType))];
        if (authoritativeRoutes.Length == 0
            || !DomainProjectionOwnerProof.MatchesCatalog(serviceProvider,
                identityOptions.AppId, identityOptions.ServiceVersion, authoritativeRoutes,
                allHandlers.Where(handler => handler.OrdinaryDeliveryEnabled
                    && string.Equals(handler.Domain, dispatchRequest.Request.Domain, StringComparison.Ordinal))
                    .Select(handler => new ProjectionDispatchRoute(handler.Domain, handler.ProjectionType)),
                dispatchRequest.CatalogFingerprint)) {
            throw new ProjectionDispatchValidationException(ProjectionDispatchReasonCodes.UnsupportedCapability);
        }

        HashSet<string> requestedTypes = new(dispatchRequest.ProjectionTypes, StringComparer.Ordinal);
        IAsyncDomainProjectionHandler[] handlers = [.. allHandlers.Where(handler =>
            string.Equals(handler.Domain, dispatchRequest.Request.Domain, StringComparison.Ordinal)
            && requestedTypes.Contains(handler.ProjectionType))];
        if (handlers.Length != requestedTypes.Count) {
            throw new ProjectionDispatchValidationException(ProjectionDispatchReasonCodes.UnsupportedRoute);
        }

        ProjectionRequest effectiveRequest = UpcastRequest(serviceProvider, await DomainProjectionNativeSourceAdmission
            .VerifyAsync(serviceProvider, dispatchRequest.Request, cancellationToken).ConfigureAwait(false));
        var outcomes = new List<ProjectionDispatchOutcome>(handlers.Length);
        foreach (IAsyncDomainProjectionHandler handler in handlers) {
            cancellationToken.ThrowIfCancellationRequested();
            ProjectionDispatchOutcome outcome;
            if (handler is not IAsyncDomainProjectionReconciliationHandler reconciliationHandler) {
                outcome = new ProjectionDispatchOutcome(
                    handler.ProjectionType,
                    ProjectionDispatchStatus.Failed,
                    null,
                    ProjectionDispatchReasonCodes.UnsupportedCapability);
            }
            else {
                try {
                    DomainProjectionHandlerResult result = await reconciliationHandler
                        .ReconcileAsync(effectiveRequest, dispatchRequest.DispatchId, cancellationToken)
                        .ConfigureAwait(false);
                    outcome = NormalizeOutcome(handler.ProjectionType, result, options);
                }
                catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested) {
                    throw;
                }
                catch (Exception) {
                    outcome = new ProjectionDispatchOutcome(
                        handler.ProjectionType,
                        ProjectionDispatchStatus.Indeterminate,
                        null,
                        ProjectionDispatchReasonCodes.HandlerFailure);
                }
            }

            outcomes.Add(outcome);
        }

        return new ProjectionDispatchResponse(ProjectionDispatchProtocol.Version, outcomes);
    }

    /// <summary>
    /// Plans every required named full-replay projection and promotes the candidates through one
    /// coordinated read-model batch.
    /// </summary>
    /// <param name="serviceProvider">The scoped request service provider.</param>
    /// <param name="dispatchRequest">The rebuild dispatch containing the complete event prefix.</param>
    /// <param name="options">The validated dispatch bounds.</param>
    /// <param name="identityOptions">The authoritative local service binding.</param>
    /// <param name="cancellationToken">Propagates request cancellation and prevents later starts.</param>
    /// <returns>One durable, distinguishable outcome per required projection route.</returns>
    public static async Task<ProjectionDispatchResponse> RebuildAsync(
        IServiceProvider serviceProvider,
        ProjectionDispatchRequest dispatchRequest,
        ProjectionDispatchOptions options,
        DomainProjectionIdentityOptions identityOptions,
        CancellationToken cancellationToken) {
        DomainProjectionRebuildPreparation preparation = await PrepareRebuildBatchAsync(
                serviceProvider,
                dispatchRequest,
                options,
                identityOptions,
                cancellationToken)
            .ConfigureAwait(false);
        if (preparation.Failure is not null) {
            return preparation.Failure;
        }

        IReadModelBatchStore? batchStore = serviceProvider.GetService<IReadModelBatchStore>();
        if (batchStore is null || preparation.Batch is null) {
            return FailureForEveryRoute(preparation.Handlers, ProjectionDispatchReasonCodes.UnsupportedCapability);
        }

        DomainProjectionHandlerResult result;
        try {
            ReadModelBatchResult batchResult = await batchStore
                .ExecuteAsync(preparation.Batch, cancellationToken)
                .ConfigureAwait(false);
            result = ReadModelBatchProjectionResultMapper.Map(batchResult);
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested) {
            throw;
        }
        catch (Exception) {
            result = DomainProjectionHandlerResult.Indeterminate(ProjectionDispatchReasonCodes.HandlerFailure);
        }

        return new ProjectionDispatchResponse(
            ProjectionDispatchProtocol.Version,
            [.. preparation.Handlers.Select(handler => new ProjectionDispatchOutcome(
                handler.ProjectionType,
                result.Status,
                null,
                result.ReasonCode))]);
    }

    /// <summary>Stages named rebuild candidates behind the existing resumable batch marker.</summary>
    public static Task<ProjectionDispatchResponse> StageRebuildAsync(
        IServiceProvider serviceProvider,
        ProjectionDispatchRequest dispatchRequest,
        ProjectionDispatchOptions options,
        DomainProjectionIdentityOptions identityOptions,
        CancellationToken cancellationToken)
        => ExecuteStagedRebuildAsync(
            serviceProvider,
            dispatchRequest,
            options,
            identityOptions,
            DomainProjectionRebuildBatchAction.Stage,
            cancellationToken);

    /// <summary>Commits and reads back named rebuild candidates.</summary>
    public static Task<ProjectionDispatchResponse> CommitRebuildAsync(
        IServiceProvider serviceProvider,
        ProjectionDispatchRequest dispatchRequest,
        ProjectionDispatchOptions options,
        DomainProjectionIdentityOptions identityOptions,
        CancellationToken cancellationToken)
        => ExecuteStagedRebuildAsync(
            serviceProvider,
            dispatchRequest,
            options,
            identityOptions,
            DomainProjectionRebuildBatchAction.Commit,
            cancellationToken);

    /// <summary>Compensates uncommitted named rebuild candidates.</summary>
    public static Task<ProjectionDispatchResponse> AbortRebuildAsync(
        IServiceProvider serviceProvider,
        ProjectionDispatchRequest dispatchRequest,
        ProjectionDispatchOptions options,
        DomainProjectionIdentityOptions identityOptions,
        CancellationToken cancellationToken)
        => ExecuteStagedRebuildAsync(
            serviceProvider,
            dispatchRequest,
            options,
            identityOptions,
            DomainProjectionRebuildBatchAction.Abort,
            cancellationToken);

    /// <summary>Verifies named rebuild marker and operation evidence.</summary>
    public static Task<ProjectionDispatchResponse> VerifyRebuildAsync(
        IServiceProvider serviceProvider,
        ProjectionDispatchRequest dispatchRequest,
        ProjectionDispatchOptions options,
        DomainProjectionIdentityOptions identityOptions,
        CancellationToken cancellationToken)
        => ExecuteStagedRebuildAsync(
            serviceProvider,
            dispatchRequest,
            options,
            identityOptions,
            DomainProjectionRebuildBatchAction.Verify,
            cancellationToken);

    /// <summary>Dispatches using a catalog fingerprint recomputed from authoritative local identity and routes.</summary>
    /// <param name="serviceProvider">The scoped request service provider.</param>
    /// <param name="dispatchRequest">The version-2 dispatch request.</param>
    /// <param name="options">The validated dispatch bounds.</param>
    /// <param name="identityOptions">The authoritative local service binding.</param>
    /// <param name="cancellationToken">Propagates request cancellation and prevents later starts.</param>
    /// <returns>A bounded deterministic per-projection response.</returns>
    public static async Task<ProjectionDispatchResponse> DispatchAsync(
        IServiceProvider serviceProvider,
        ProjectionDispatchRequest dispatchRequest,
        ProjectionDispatchOptions options,
        DomainProjectionIdentityOptions identityOptions,
        CancellationToken cancellationToken) {
        ArgumentNullException.ThrowIfNull(serviceProvider);
        ArgumentNullException.ThrowIfNull(dispatchRequest);
        ArgumentNullException.ThrowIfNull(options);
        ArgumentNullException.ThrowIfNull(identityOptions);
        options.Validate();
        identityOptions.Validate();
        ValidateRequest(dispatchRequest, options);

        IAsyncDomainProjectionHandler[] allHandlers = DomainProjectionHandlerRouteValidator
            .MaterializeAndValidateNamed(serviceProvider.GetServices<IAsyncDomainProjectionHandler>(), options)
            .ToArray();
        ProjectionDispatchRoute[] authoritativeRoutes = [.. allHandlers
            .Where(handler => string.Equals(handler.Domain, dispatchRequest.Request.Domain, StringComparison.Ordinal))
            .Select(handler => new ProjectionDispatchRoute(handler.Domain, handler.ProjectionType))];
        if (authoritativeRoutes.Length == 0
            || !DomainProjectionOwnerProof.MatchesCatalog(serviceProvider,
                identityOptions.AppId, identityOptions.ServiceVersion, authoritativeRoutes,
                allHandlers.Where(handler => handler.OrdinaryDeliveryEnabled
                    && string.Equals(handler.Domain, dispatchRequest.Request.Domain, StringComparison.Ordinal))
                    .Select(handler => new ProjectionDispatchRoute(handler.Domain, handler.ProjectionType)),
                dispatchRequest.CatalogFingerprint)) {
            throw new ProjectionDispatchValidationException(ProjectionDispatchReasonCodes.UnsupportedCapability);
        }

        return await DispatchCoreAsync(
                serviceProvider,
                dispatchRequest,
                options,
                cancellationToken,
                allHandlers,
                DomainProjectionOwnerProof.UsesGuardedCatalog(serviceProvider, dispatchRequest, identityOptions))
            .ConfigureAwait(false);
    }

    private static async Task<ProjectionDispatchResponse> ExecuteStagedRebuildAsync(
        IServiceProvider serviceProvider,
        ProjectionDispatchRequest dispatchRequest,
        ProjectionDispatchOptions options,
        DomainProjectionIdentityOptions identityOptions,
        DomainProjectionRebuildBatchAction action,
        CancellationToken cancellationToken) {
        ArgumentNullException.ThrowIfNull(dispatchRequest);
        DomainProjectionEvolutionAdmission.RequireLegacy(dispatchRequest.Request);
        ProjectionDispatchRequest transportHeader = dispatchRequest;
        var guarded = DomainProjectionGuardedReplay.Resolve(serviceProvider, transportHeader, options, identityOptions);
        ReadModelBatch? original = guarded is { } route
            ? await DomainProjectionGuardedReplay.ReadAsync(serviceProvider, transportHeader, route.Store, cancellationToken).ConfigureAwait(false)
            : null;
        if (guarded is not null && original is null && ProjectionReplayTransportContext.HasOwners(transportHeader.Request)
            && action != DomainProjectionRebuildBatchAction.Stage)
            return FailureForEveryRoute(guarded.Value.Handlers, ProjectionDispatchReasonCodes.DeliveryReconciliationRequired);
        DomainProjectionRebuildPreparation? streamed = original is not null || transportHeader.RebuildTransport is null
            ? null
            : await PrepareStreamedRebuildBatchAsync(serviceProvider, transportHeader, options,
                identityOptions, cancellationToken).ConfigureAwait(false);
        DomainProjectionRebuildPreparation preparation;
        if (original is not null) preparation = new(guarded!.Value.Handlers, original, null);
        else if (streamed is not null) preparation = streamed;
        else
        {
            dispatchRequest = await DomainProjectionRebuildTransport.ResolveAsync(
                serviceProvider, dispatchRequest, options, identityOptions, cancellationToken).ConfigureAwait(false);
            preparation = await PrepareRebuildBatchAsync(serviceProvider, dispatchRequest, options,
                identityOptions, cancellationToken).ConfigureAwait(false);
        }
        if (preparation.Failure is not null) {
            return preparation.Failure;
        }

        if (!ProjectionReplayTransportContext.HasOwners(transportHeader.Request) && preparation.Batch?.OwnerSelections is null)
            guarded = null;

        if (guarded is { } guardedRoute && original is null && preparation.Batch is not null)
        {
            preparation = preparation with { Batch = await DomainProjectionGuardedReplay.SaveAsync(serviceProvider,
                transportHeader, preparation.Batch, guardedRoute.Store, cancellationToken).ConfigureAwait(false) };
        }
        if (guarded is null && transportHeader.RebuildTransport is not null && preparation.Batch is not null) {
            ReadModelBatch batch = action == DomainProjectionRebuildBatchAction.Stage
                ? await DomainProjectionRebuildTransport.SavePlanAsync(serviceProvider,
                    transportHeader, preparation.Batch, options, identityOptions, cancellationToken)
                    .ConfigureAwait(false)
                : await DomainProjectionRebuildTransport.RestorePlanAsync(serviceProvider,
                    transportHeader, preparation.Batch, options, identityOptions, cancellationToken)
                    .ConfigureAwait(false);
            preparation = preparation with { Batch = batch };
        }

        IReadModelBatchStagingStore? stagingStore = serviceProvider.GetService<IReadModelBatchStagingStore>();
        if (stagingStore is null || preparation.Batch is null) {
            return FailureForEveryRoute(preparation.Handlers, ProjectionDispatchReasonCodes.UnsupportedCapability);
        }

        ReadModelBatchStagingResult stagingResult;
        try {
            stagingResult = action switch {
                DomainProjectionRebuildBatchAction.Stage => await stagingStore
                    .StageAsync(preparation.Batch, cancellationToken)
                    .ConfigureAwait(false),
                DomainProjectionRebuildBatchAction.Commit => await stagingStore
                    .CommitAsync(preparation.Batch, cancellationToken)
                    .ConfigureAwait(false),
                DomainProjectionRebuildBatchAction.Abort => await stagingStore
                    .AbortAsync(preparation.Batch, cancellationToken)
                    .ConfigureAwait(false),
                _ => await stagingStore
                    .VerifyAsync(preparation.Batch, cancellationToken)
                    .ConfigureAwait(false),
            };
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested) {
            throw;
        }
        catch (Exception) {
            stagingResult = new ReadModelBatchStagingResult(
                ReadModelBatchStagingStatus.Indeterminate,
                string.Empty,
                ProjectionDispatchReasonCodes.HandlerFailure);
        }

        bool succeeded = action switch {
            DomainProjectionRebuildBatchAction.Stage => stagingResult.Status
                is ReadModelBatchStagingStatus.Prepared or ReadModelBatchStagingStatus.Committed,
            DomainProjectionRebuildBatchAction.Abort => stagingResult.Status == ReadModelBatchStagingStatus.Aborted,
            _ => stagingResult.Status == ReadModelBatchStagingStatus.Committed,
        };
        ProjectionDispatchStatus status = succeeded
            ? ProjectionDispatchStatus.Completed
            : stagingResult.Status == ReadModelBatchStagingStatus.Conflict
                ? ProjectionDispatchStatus.Failed
                : ProjectionDispatchStatus.Indeterminate;
        string? reasonCode = succeeded
            ? null
            : stagingResult.Status == ReadModelBatchStagingStatus.Conflict
                ? ProjectionDispatchReasonCodes.MalformedOutcome
                : ProjectionDispatchReasonCodes.HandlerFailure;
        ProjectionDispatchResponse response = new(
            ProjectionDispatchProtocol.Version,
            [.. preparation.Handlers.Select(handler => new ProjectionDispatchOutcome(
                handler.ProjectionType,
                status,
                null,
                reasonCode))]);
        if (succeeded && action is DomainProjectionRebuildBatchAction.Verify or DomainProjectionRebuildBatchAction.Abort
            && transportHeader.RebuildTransport is not null)
        {
            try
            {
                await DomainProjectionRebuildTransport.ReclaimAsync(serviceProvider, transportHeader,
                    options, identityOptions, cancellationToken).ConfigureAwait(false);
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
            {
                throw;
            }
            catch (Exception)
            {
                // Parts have a bounded TTL, and a retried operation can reclaim them later.
            }
        }

        return response;
    }

    private static async Task<DomainProjectionRebuildPreparation?> PrepareStreamedRebuildBatchAsync(
        IServiceProvider services, ProjectionDispatchRequest header, ProjectionDispatchOptions options,
        DomainProjectionIdentityOptions identity, CancellationToken cancellationToken)
    {
        string storeName = DomainProjectionRebuildTransport.ValidateAndGetStore(services, header, options, identity);
        IAsyncDomainProjectionHandler[] handlers = [.. DomainProjectionHandlerRouteValidator
            .MaterializeAndValidateNamed(services.GetServices<IAsyncDomainProjectionHandler>(), options)
            .Where(handler => StringComparer.Ordinal.Equals(handler.Domain, header.Request.Domain)
                && header.ProjectionTypes.Contains(handler.ProjectionType, StringComparer.Ordinal))];
        if (handlers.All(handler => handler is not IAsyncDomainProjectionStreamedRebuildHandler)) return null;

        ProjectionRequest? fullReplayRequest = null;
        var operations = new List<ReadModelBatchOperation>();
        var failures = new Dictionary<string, ProjectionDispatchOutcome>(StringComparer.Ordinal);
        foreach (IAsyncDomainProjectionHandler handler in handlers)
        {
            try
            {
                bool streamComplete = false;
                async IAsyncEnumerable<ProjectionEventDto> VerifiedEvents()
                {
                    await foreach (ProjectionEventDto item in DomainProjectionRebuildTransport.ReadEventsAsync(
                        services, header, options, identity, cancellationToken).ConfigureAwait(false))
                        yield return item;
                    streamComplete = true;
                }
                DomainProjectionRebuildPlan plan;
                if (handler is IAsyncDomainProjectionStreamedRebuildHandler streamedHandler)
                {
                    plan = await MeasureHandler(streamedHandler).PrepareStreamedRebuildAsync(header.Request,
                        VerifiedEvents(), header.DispatchId, cancellationToken).ConfigureAwait(false);
                    if (!streamComplete)
                        throw new DomainProjectionRebuildRejectedException(ProjectionDispatchReasonCodes.DeliveryGap);
                }
                else
                {
                    if (handler is not IAsyncDomainProjectionRebuildHandler fullHandler
                        || fullHandler.RebuildSemantics != DomainProjectionRebuildSemantics.FullReplay)
                        throw new DomainProjectionRebuildRejectedException(ProjectionDispatchReasonCodes.UnsupportedCapability);
                    if (fullReplayRequest is null)
                    {
                        ProjectionDispatchRequest complete = await DomainProjectionRebuildTransport.ResolveAsync(services,
                            header, options, identity, cancellationToken).ConfigureAwait(false);
                        ValidateRequest(complete, options);
                        ValidateRebuildEventHistory(complete.Request, options.MaxRebuildEventCount);
                        fullReplayRequest = UpcastRequest(services, await DomainProjectionNativeSourceAdmission
                            .VerifyAsync(services, complete.Request, cancellationToken).ConfigureAwait(false));
                    }
                    plan = await MeasureHandler(fullHandler).PrepareRebuildAsync(fullReplayRequest,
                        header.DispatchId, cancellationToken).ConfigureAwait(false);
                }
                if (!StringComparer.Ordinal.Equals(plan.StoreName, storeName))
                    throw new DomainProjectionRebuildRejectedException(
                        ProjectionDispatchReasonCodes.UnsupportedCapability);
                operations.AddRange(plan.Operations);
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested) { throw; }
            catch (ProjectionDispatchValidationException) { throw; }
            catch (DomainProjectionRebuildRejectedException exception)
            {
                failures[handler.ProjectionType] = new(handler.ProjectionType,
                    ProjectionDispatchStatus.Failed, null, exception.ReasonCode);
            }
            catch (Exception)
            {
                failures[handler.ProjectionType] = new(handler.ProjectionType,
                    ProjectionDispatchStatus.Indeterminate, null, ProjectionDispatchReasonCodes.HandlerFailure);
            }
        }
        if (failures.Count != 0)
            return new(handlers, null, new(ProjectionDispatchProtocol.Version,
                [.. handlers.Select(handler => failures.TryGetValue(handler.ProjectionType, out var outcome)
                    ? outcome : new ProjectionDispatchOutcome(handler.ProjectionType,
                        ProjectionDispatchStatus.Retryable, null, ProjectionDispatchReasonCodes.PartialRetry))]));
        var batch = new ReadModelBatch(new ReadModelBatchScope(storeName, header.Request.TenantId,
            header.Request.Domain, header.Request.AggregateId, "rebuild", header.DispatchId), operations);
        return new(handlers, DomainProjectionOwnerProof.BindRebuildBatch(services, header, batch, identity), null);
    }

    internal static async Task<DomainProjectionRebuildPreparation> PrepareRebuildBatchAsync(
        IServiceProvider serviceProvider,
        ProjectionDispatchRequest dispatchRequest,
        ProjectionDispatchOptions options,
        DomainProjectionIdentityOptions identityOptions,
        CancellationToken cancellationToken) {
        ArgumentNullException.ThrowIfNull(serviceProvider);
        ArgumentNullException.ThrowIfNull(dispatchRequest);
        ArgumentNullException.ThrowIfNull(options);
        ArgumentNullException.ThrowIfNull(identityOptions);
        options.Validate();
        identityOptions.Validate();
        ValidateRequest(dispatchRequest, options);
        ValidateRebuildEventHistory(dispatchRequest.Request, options.MaxRebuildEventCount);

        IAsyncDomainProjectionHandler[] allHandlers = DomainProjectionHandlerRouteValidator
            .MaterializeAndValidateNamed(serviceProvider.GetServices<IAsyncDomainProjectionHandler>(), options);
        ProjectionDispatchRoute[] authoritativeRoutes = [.. allHandlers
            .Where(handler => string.Equals(handler.Domain, dispatchRequest.Request.Domain, StringComparison.Ordinal))
            .Select(handler => new ProjectionDispatchRoute(handler.Domain, handler.ProjectionType))];
        if (authoritativeRoutes.Length == 0
            || !DomainProjectionOwnerProof.MatchesCatalog(serviceProvider,
                identityOptions.AppId, identityOptions.ServiceVersion, authoritativeRoutes,
                allHandlers.Where(handler => handler.OrdinaryDeliveryEnabled
                    && string.Equals(handler.Domain, dispatchRequest.Request.Domain, StringComparison.Ordinal))
                    .Select(handler => new ProjectionDispatchRoute(handler.Domain, handler.ProjectionType)),
                dispatchRequest.CatalogFingerprint)) {
            throw new ProjectionDispatchValidationException(ProjectionDispatchReasonCodes.UnsupportedCapability);
        }

        HashSet<string> requestedTypes = new(dispatchRequest.ProjectionTypes, StringComparer.Ordinal);
        if (requestedTypes.Count == 0
            || requestedTypes.Count != dispatchRequest.ProjectionTypes.Count
            || requestedTypes.Any(type => !authoritativeRoutes.Any(route => string.Equals(route.ProjectionType, type, StringComparison.Ordinal)))) {
            throw new ProjectionDispatchValidationException(ProjectionDispatchReasonCodes.UnsupportedRoute);
        }

        IAsyncDomainProjectionHandler[] handlers = [.. allHandlers.Where(handler =>
            string.Equals(handler.Domain, dispatchRequest.Request.Domain, StringComparison.Ordinal)
            && requestedTypes.Contains(handler.ProjectionType))];
        if (handlers.Length != requestedTypes.Count) {
            throw new ProjectionDispatchValidationException(ProjectionDispatchReasonCodes.UnsupportedRoute);
        }

        ProjectionRequest effectiveRequest = UpcastRequest(serviceProvider, await DomainProjectionNativeSourceAdmission
            .VerifyAsync(serviceProvider, dispatchRequest.Request, cancellationToken).ConfigureAwait(false));
        var outcomes = new Dictionary<string, ProjectionDispatchOutcome>(StringComparer.Ordinal);
        var operations = new List<ReadModelBatchOperation>();
        string? storeName = null;
        foreach (IAsyncDomainProjectionHandler handler in handlers) {
            cancellationToken.ThrowIfCancellationRequested();
            if (handler is not IAsyncDomainProjectionRebuildHandler rebuildHandler
                || rebuildHandler.RebuildSemantics != DomainProjectionRebuildSemantics.FullReplay) {
                outcomes[handler.ProjectionType] = new ProjectionDispatchOutcome(
                    handler.ProjectionType,
                    ProjectionDispatchStatus.Failed,
                    null,
                    ProjectionDispatchReasonCodes.UnsupportedCapability);
                continue;
            }

            try {
                DomainProjectionRebuildPlan plan = await MeasureHandler(rebuildHandler)
                    .PrepareRebuildAsync(
                        effectiveRequest,
                        dispatchRequest.DispatchId,
                        cancellationToken)
                    .ConfigureAwait(false);
                if (storeName is not null && !string.Equals(storeName, plan.StoreName, StringComparison.Ordinal)) {
                    outcomes[handler.ProjectionType] = new ProjectionDispatchOutcome(
                        handler.ProjectionType,
                        ProjectionDispatchStatus.Failed,
                        null,
                        ProjectionDispatchReasonCodes.UnsupportedCapability);
                    continue;
                }

                storeName ??= plan.StoreName;
                operations.AddRange(plan.Operations);
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested) {
                throw;
            }
            catch (DomainProjectionRebuildRejectedException exception) {
                outcomes[handler.ProjectionType] = new ProjectionDispatchOutcome(
                    handler.ProjectionType,
                    ProjectionDispatchStatus.Failed,
                    null,
                    exception.ReasonCode);
            }
            catch (Exception) {
                outcomes[handler.ProjectionType] = new ProjectionDispatchOutcome(
                    handler.ProjectionType,
                    ProjectionDispatchStatus.Indeterminate,
                    null,
                    ProjectionDispatchReasonCodes.HandlerFailure);
            }
        }

        if (outcomes.Count > 0) {
            var failure = new ProjectionDispatchResponse(
                ProjectionDispatchProtocol.Version,
                [.. handlers.Select(handler => outcomes.TryGetValue(handler.ProjectionType, out ProjectionDispatchOutcome? outcome)
                    ? outcome
                    : new ProjectionDispatchOutcome(
                        handler.ProjectionType,
                        ProjectionDispatchStatus.Retryable,
                        null,
                        ProjectionDispatchReasonCodes.PartialRetry))]);
            return new DomainProjectionRebuildPreparation(handlers, null, failure);
        }

        if (storeName is null) {
            return new DomainProjectionRebuildPreparation(
                handlers,
                null,
                FailureForEveryRoute(handlers, ProjectionDispatchReasonCodes.UnsupportedCapability));
        }

        try {
            var batch = new ReadModelBatch(
                new ReadModelBatchScope(
                    storeName,
                    dispatchRequest.Request.TenantId,
                    dispatchRequest.Request.Domain,
                    dispatchRequest.Request.AggregateId,
                    "rebuild",
                    dispatchRequest.DispatchId),
                operations);
            return new DomainProjectionRebuildPreparation(handlers,
                DomainProjectionOwnerProof.BindRebuildBatch(serviceProvider, dispatchRequest, batch, identityOptions), null);
        }
        catch (Exception exception) when (exception is ArgumentException or ArgumentNullException) {
            return new DomainProjectionRebuildPreparation(
                handlers,
                null,
                FailureForEveryRoute(handlers, ProjectionDispatchReasonCodes.MalformedOutcome));
        }
    }

    private static async Task<ProjectionDispatchResponse> DispatchCoreAsync(
        IServiceProvider serviceProvider,
        ProjectionDispatchRequest dispatchRequest,
        ProjectionDispatchOptions options,
        CancellationToken cancellationToken,
        IReadOnlyList<IAsyncDomainProjectionHandler>? materializedHandlers = null,
        bool boundGuardCatalog = false) {
        HashSet<string> requestedTypes = new(dispatchRequest.ProjectionTypes, StringComparer.Ordinal);
        IAsyncDomainProjectionHandler[] handlers = [.. (materializedHandlers
            ?? DomainProjectionHandlerRouteValidator.MaterializeAndValidateNamed(
                serviceProvider.GetServices<IAsyncDomainProjectionHandler>(),
                options))
            .Where(handler => string.Equals(handler.Domain, dispatchRequest.Request.Domain, StringComparison.Ordinal)
                && requestedTypes.Contains(handler.ProjectionType))];
        if (handlers.Length != requestedTypes.Count) {
            throw new ProjectionDispatchValidationException(ProjectionDispatchReasonCodes.UnsupportedRoute);
        }

        if (handlers.Any(handler => !handler.OrdinaryDeliveryEnabled))
            throw new ProjectionDispatchValidationException(ProjectionDispatchReasonCodes.UnsupportedCapability);

        ProjectionRequest effectiveRequest = UpcastRequest(serviceProvider, await DomainProjectionNativeSourceAdmission
            .VerifyAsync(serviceProvider, dispatchRequest.Request, cancellationToken).ConfigureAwait(false));

        var outcomes = new List<ProjectionDispatchOutcome>(handlers.Length);
        foreach (IAsyncDomainProjectionHandler handler in handlers) {
            cancellationToken.ThrowIfCancellationRequested();
            ProjectionDispatchOutcome outcome;
            try {
                DomainProjectionHandlerResult result = handler is IAsyncDomainSharedProjectionEpochHandler { EpochEnabled: true } epochHandler
                    ? await DispatchFencedSharedAsync(
                        serviceProvider,
                        epochHandler,
                        effectiveRequest,
                        serviceProvider.GetServices<DomainProjectionOwnerProofRegistration>().Any(registration =>
                            registration.Domain == handler.Domain && registration.ProjectionType == handler.ProjectionType
                            && registration.Capability.HandlerSemantics == "shared-epoch-v1" && registration.Capability.IsSupported
                            && (boundGuardCatalog || serviceProvider.GetService<DomainProjectionCatalogRegistry>()?.AuthorizesSourceGuard(
                                dispatchRequest.CatalogFingerprint, handler.Domain, handler.ProjectionType, registration.Capability) == true)),
                        cancellationToken).ConfigureAwait(false)
                    : await MeasureHandler(handler)
                        .ProjectAsync(effectiveRequest, dispatchRequest.DispatchId, cancellationToken)
                        .ConfigureAwait(false);
                outcome = NormalizeOutcome(handler.ProjectionType, result, options);
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested) {
                throw;
            }
            catch (SharedProjectionRetryableFoldException)
            {
                outcome = new ProjectionDispatchOutcome(
                    handler.ProjectionType,
                    ProjectionDispatchStatus.Retryable,
                    null,
                    ProjectionDispatchReasonCodes.PartialRetry);
            }
            catch (SharedProjectionReadUnavailableException)
            {
                outcome = new ProjectionDispatchOutcome(
                    handler.ProjectionType,
                    ProjectionDispatchStatus.Retryable,
                    null,
                    ProjectionDispatchReasonCodes.DeliveryStateUnavailable);
            }
            catch (SharedProjectionWriteUnavailableException)
            {
                outcome = new ProjectionDispatchOutcome(
                    handler.ProjectionType,
                    ProjectionDispatchStatus.Retryable,
                    null,
                    ProjectionDispatchReasonCodes.DeliveryStateUnavailable);
            }
            catch (Exception exception) when (exception is not OperationCanceledException
                && IsReadModelStoreUnavailable(exception))
            {
                outcome = new ProjectionDispatchOutcome(
                    handler.ProjectionType,
                    ProjectionDispatchStatus.Retryable,
                    null,
                    ProjectionDispatchReasonCodes.DeliveryStateUnavailable);
            }
            catch (OperationCanceledException) {
                outcome = new ProjectionDispatchOutcome(
                    handler.ProjectionType,
                    ProjectionDispatchStatus.Indeterminate,
                    null,
                    ProjectionDispatchReasonCodes.HandlerFailure);
            }
            catch (Exception) {
                outcome = new ProjectionDispatchOutcome(
                    handler.ProjectionType,
                    ProjectionDispatchStatus.Indeterminate,
                    null,
                    ProjectionDispatchReasonCodes.HandlerFailure);
            }

            outcomes.Add(outcome);
            if (TryGetEnvelopeSize(outcomes, out int envelopeSize)
                && envelopeSize <= options.MaxOutcomeEnvelopeBytes) {
                continue;
            }

            outcomes[^1] = new ProjectionDispatchOutcome(
                handler.ProjectionType,
                ProjectionDispatchStatus.Failed,
                null,
                ProjectionDispatchReasonCodes.MalformedOutcome);
            for (int index = 0;
                (!TryGetEnvelopeSize(outcomes, out envelopeSize)
                    || envelopeSize > options.MaxOutcomeEnvelopeBytes)
                && index < outcomes.Count;
                index++) {
                ProjectionDispatchOutcome prior = outcomes[index];
                if (prior.State is null) {
                    continue;
                }

                outcomes[index] = new ProjectionDispatchOutcome(
                    prior.ProjectionType,
                    ProjectionDispatchStatus.Failed,
                    null,
                    ProjectionDispatchReasonCodes.MalformedOutcome);
            }
        }

        return new ProjectionDispatchResponse(ProjectionDispatchProtocol.Version, outcomes);
    }

    private static async Task<DomainProjectionHandlerResult> DispatchFencedSharedAsync(
        IServiceProvider serviceProvider,
        IAsyncDomainSharedProjectionEpochHandler handler,
        ProjectionRequest request,
        bool requireAppliedProof,
        CancellationToken cancellationToken) {
        SharedProjectionEpochCoordinator? coordinator = serviceProvider.GetService<SharedProjectionEpochCoordinator>();
        if (coordinator is null) {
            return DomainProjectionHandlerResult.Failed(ProjectionDispatchReasonCodes.UnsupportedCapability);
        }

        SharedProjectionScope scope = handler.CreateScope(request.TenantId);
        scope.Validate();
        if (!string.Equals(scope.StoreName, handler.RebuildStoreName, StringComparison.Ordinal)
            || (!handler.GlobalEpochScope
                && !string.Equals(scope.TenantId, request.TenantId, StringComparison.Ordinal))
            || (handler.GlobalEpochScope
                && !string.Equals(scope.TenantId,
                    IAsyncDomainSharedProjectionEpochHandler.GlobalTenantSegment, StringComparison.Ordinal))
            || !string.Equals(scope.Domain, request.Domain, StringComparison.Ordinal)
            || !string.Equals(scope.Family, handler.ProjectionType, StringComparison.Ordinal)) {
            return DomainProjectionHandlerResult.Failed(ProjectionDispatchReasonCodes.UnsupportedCapability);
        }

        if (request.Events.Length == 0
            || request.Events.Any(static item => item.GlobalPosition <= 0
                || item.SequenceNumber <= 0
                || item.Payload is null
                || string.IsNullOrWhiteSpace(item.EventTypeName)
                || string.IsNullOrWhiteSpace(item.SerializationFormat))) {
            return DomainProjectionHandlerResult.Retryable(ProjectionDispatchReasonCodes.DeliveryGap);
        }

        long previousSequence = 0;
        long previousPosition = 0;
        foreach (ProjectionEventDto item in request.Events) {
            if ((previousSequence > 0 && item.SequenceNumber != previousSequence + 1)
                || item.GlobalPosition <= previousPosition) {
                return DomainProjectionHandlerResult.Failed(ProjectionDispatchReasonCodes.MalformedOutcome);
            }

            previousSequence = item.SequenceNumber;
            previousPosition = item.GlobalPosition;
        }

        SharedProjectionLease lease;
        try {
            lease = await coordinator.RegisterWriterAsync(
                scope,
                handler.OrdinaryWriterId,
                cancellationToken).ConfigureAwait(false);
        }
        catch (Exception exception) when (!cancellationToken.IsCancellationRequested
            && IsReadModelStoreUnavailable(exception)) {
            return DomainProjectionHandlerResult.Retryable(ProjectionDispatchReasonCodes.DeliveryStateUnavailable);
        }
        SharedProjectionControlIndexIntent? controlIndexIntent = handler.ControlIndexName is { } indexName
            ? new SharedProjectionControlIndexIntent(indexName)
            : null;
        bool accepted = false;
        bool retry = false;
        bool ownerGap = false;
        bool catchUp = false;
        var deliveries = new List<SharedProjectionDelivery>();
        foreach (ProjectionEventDto item in request.Events) {
            cancellationToken.ThrowIfCancellationRequested();
            var singleEventRequest = new ProjectionRequest(
                request.TenantId,
                request.Domain,
                request.AggregateId,
                [item]);
            var delivery = new SharedProjectionDelivery(
                handler.SourceStreamKey(request.TenantId, request.AggregateId),
                item.GlobalPosition,
                JsonSerializer.SerializeToUtf8Bytes(singleEventRequest, SerializerOptions),
                JsonSerializer.SerializeToUtf8Bytes(item.GlobalPosition, SerializerOptions),
                controlIndexIntent,
                item.SequenceNumber);
            deliveries.Add(delivery);
            SharedProjectionJournalResult journaled;
            try {
                journaled = await coordinator.JournalAsync(
                    scope,
                    lease,
                    delivery,
                    cancellationToken).ConfigureAwait(false);
            }
            catch (Exception exception) when (!cancellationToken.IsCancellationRequested
                && IsReadModelStoreUnavailable(exception)) {
                return DomainProjectionHandlerResult.Retryable(ProjectionDispatchReasonCodes.DeliveryStateUnavailable);
            }
            if (journaled == SharedProjectionJournalResult.IdentityConflict) {
                return DomainProjectionHandlerResult.Failed(ProjectionDispatchReasonCodes.DeliveryIdentityConflict);
            }

            if (journaled == SharedProjectionJournalResult.RebuildRequired) {
                return DomainProjectionHandlerResult.Retryable(ProjectionDispatchReasonCodes.DeliveryRebuildRequired);
            }

            if (journaled is SharedProjectionJournalResult.StaleLease or SharedProjectionJournalResult.Backpressure
                or SharedProjectionJournalResult.DeliveryGap) {
                retry = true;
                ownerGap = journaled == SharedProjectionJournalResult.DeliveryGap;
                break;
            }
            else if (journaled == SharedProjectionJournalResult.Journaled) {
                accepted = true;
                catchUp = true;
            }
            else if (journaled == SharedProjectionJournalResult.AlreadyJournaled) {
                catchUp = true;
            }
        }

        if (catchUp) {
            try {
                _ = await coordinator.CatchUpAsync(
                    scope,
                    async (delivery, generation, token) => {
                        try {
                            return await handler.FoldCatchUpAsync(delivery, generation, coordinator, token)
                                .ConfigureAwait(false);
                        }
                        catch (OperationCanceledException exception) when (!token.IsCancellationRequested) {
                            throw new InvalidOperationException(
                                "The shared projection handler cancelled independently of the request.", exception);
                        }
                    },
                    cancellationToken).ConfigureAwait(false);
            }
            catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested) {
                return DomainProjectionHandlerResult.Retryable(ProjectionDispatchReasonCodes.DeliveryStateUnavailable);
            }
        }
        if (requireAppliedProof && !retry)
        {
            foreach (SharedProjectionDelivery delivery in deliveries)
            {
                SharedProjectionAppliedDeliveryProof proof = await coordinator.ReadAppliedDeliveryProofAsync(scope,
                    delivery, cancellationToken).ConfigureAwait(false);
                if (!proof.IsApplied)
                    return DomainProjectionHandlerResult.Retryable(proof.ReasonCode ?? ProjectionDispatchReasonCodes.DeliveryReconciliationRequired);
            }
        }
        return retry
            ? DomainProjectionHandlerResult.Retryable(ownerGap
                ? ProjectionDispatchReasonCodes.DeliveryGap
                : ProjectionDispatchReasonCodes.PartialRetry)
            : accepted
                ? DomainProjectionHandlerResult.Completed()
                : DomainProjectionHandlerResult.AlreadyCompleted();
    }

    private static bool IsReadModelStoreUnavailable(Exception exception)
        => exception is DaprException or IOException or HttpRequestException or TimeoutException or TaskCanceledException;

    private static ProjectionDispatchResponse FailureForEveryRoute(
        IEnumerable<IAsyncDomainProjectionHandler> handlers,
        string reasonCode)
        => new(
            ProjectionDispatchProtocol.Version,
            [.. handlers.Select(handler => new ProjectionDispatchOutcome(
                handler.ProjectionType,
                ProjectionDispatchStatus.Failed,
                null,
                reasonCode))]);

    internal static void ValidateRequest(ProjectionDispatchRequest dispatchRequest, ProjectionDispatchOptions options) {
        if (dispatchRequest.Request is null
            || string.IsNullOrWhiteSpace(dispatchRequest.Request.TenantId)
            || string.IsNullOrWhiteSpace(dispatchRequest.Request.AggregateId)
            || dispatchRequest.Request.Events is null
            || dispatchRequest.Request.Events.Any(static item => item is null)
            || dispatchRequest.ProjectionTypes is not { Count: > 0 }
            || dispatchRequest.ProjectionTypes.Count > options.MaxOutcomes
            || string.IsNullOrWhiteSpace(dispatchRequest.DispatchId)
            || string.IsNullOrWhiteSpace(dispatchRequest.CatalogFingerprint)) {
            throw new ProjectionDispatchValidationException(ProjectionDispatchReasonCodes.MalformedOutcome);
        }

        DomainProjectionEvolutionAdmission.RequireLegacy(dispatchRequest.Request);

        try {
            NamingConventionEngine.ValidateKebabCase(dispatchRequest.Request.Domain, nameof(dispatchRequest.Request.Domain));
            foreach (string projectionType in dispatchRequest.ProjectionTypes) {
                NamingConventionEngine.ValidateKebabCase(projectionType, nameof(dispatchRequest.ProjectionTypes));
            }
        }
        catch (ArgumentException) {
            throw new ProjectionDispatchValidationException(ProjectionDispatchReasonCodes.UnsupportedRoute);
        }

        if (dispatchRequest.ProjectionTypes.Distinct(StringComparer.Ordinal).Count() != dispatchRequest.ProjectionTypes.Count) {
            throw new ProjectionDispatchValidationException(ProjectionDispatchReasonCodes.DuplicateRoute);
        }
    }

    private static void ValidateRebuildEventHistory(
        ProjectionRequest request,
        int maxEventCount) {
        IReadOnlyList<ProjectionEventDto> events = request.Events;
        if (events.Count > maxEventCount
            || (events.Count == 0 && (!request.RebuildSourceErased || request.RebuildSourceHeadSequence != 0))
            || (events.Count > 0 && request.RebuildSourceErased)) {
            throw new ProjectionDispatchValidationException(ProjectionDispatchReasonCodes.MalformedOutcome);
        }

        long expectedSequence = 1;
        foreach (ProjectionEventDto item in events) {
            if (item.SequenceNumber != expectedSequence
                || item.Payload is null
                || string.IsNullOrWhiteSpace(item.EventTypeName)
                || string.IsNullOrWhiteSpace(item.SerializationFormat)) {
                throw new ProjectionDispatchValidationException(ProjectionDispatchReasonCodes.MalformedOutcome);
            }

            expectedSequence++;
        }
    }

    private static ProjectionDispatchOutcome NormalizeOutcome(
        string projectionType,
        DomainProjectionHandlerResult? result,
        ProjectionDispatchOptions options) {
        if (result is null
            || !Enum.IsDefined(result.Status)
            || result.State is { ValueKind: JsonValueKind.Undefined }
            || (result.State is not null
                && result.Status is not ProjectionDispatchStatus.Completed and not ProjectionDispatchStatus.AlreadyCompleted)
            || !IsValidReasonCode(result.ReasonCode, options.MaxReasonCodeBytes)) {
            return new ProjectionDispatchOutcome(
                projectionType,
                ProjectionDispatchStatus.Failed,
                null,
                ProjectionDispatchReasonCodes.MalformedOutcome);
        }

        try {
            JsonElement? state = result.State?.Clone();
            return new ProjectionDispatchOutcome(projectionType, result.Status, state, result.ReasonCode);
        }
        catch (InvalidOperationException) {
            return new ProjectionDispatchOutcome(
                projectionType,
                ProjectionDispatchStatus.Failed,
                null,
                ProjectionDispatchReasonCodes.MalformedOutcome);
        }
    }

    private static bool IsValidReasonCode(string? reasonCode, int maxBytes) {
        if (reasonCode is null) {
            return true;
        }

        return reasonCode.Length <= maxBytes
            && reasonCode.All(static character => character <= 0x7f);
    }

    private static bool TryGetEnvelopeSize(
        IReadOnlyList<ProjectionDispatchOutcome> outcomes,
        out int envelopeSize) {
        try {
            envelopeSize = JsonSerializer.SerializeToUtf8Bytes(
                new ProjectionDispatchResponse(ProjectionDispatchProtocol.Version, outcomes),
                SerializerOptions).Length;
            return true;
        }
        catch (Exception exception) when (exception is InvalidOperationException or JsonException or NotSupportedException) {
            envelopeSize = int.MaxValue;
            return false;
        }
    }
    private static THandler MeasureHandler<THandler>(THandler handler)
    {
        ProjectionDeliveryCostDiagnostics.Record(ProjectionDeliveryCost.HandlerAttempts);
        return handler;
    }

}
