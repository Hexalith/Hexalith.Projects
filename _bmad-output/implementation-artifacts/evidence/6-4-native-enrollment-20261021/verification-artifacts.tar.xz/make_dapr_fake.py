from pathlib import Path
import re
root=Path('/home/administrator/projects/hexalith/projects/references/Hexalith.EventStore')
s=(root/'tests/Hexalith.EventStore.Client.Tests/Projections/RecordingDaprClient.cs').read_text()
methods=[]
for match in re.finditer(r'    public override (?!JsonSerializerOptions)', s):
 start=match.start(); a=s.find('=>',start); b=s.find('{',start)
 if a!=-1 and (b==-1 or a<b):
  end=s.find(';',a)+1; signature=s[start:a].strip(); body='=> throw new NotSupportedException();'
 else:
  depth=1;end=b+1
  while depth:
   if s[end]=='{':depth+=1
   if s[end]=='}':depth-=1
   end+=1
  signature=s[start:b].strip();body='=> throw new NotSupportedException();'
 name=re.search(r'(\w+)(?:<[^>]+>)?\s*\(',signature).group(1)
 methods.append((name,signature.replace('async Task','Task'),body))
impl={
'TrySaveStateAsync': '=> TrySaveByteStateAsync(storeName, key, JsonSerializer.SerializeToUtf8Bytes(value, JsonSerializerOptions), etag, stateOptions, metadata, cancellationToken);',
'SaveStateAsync': '=> SaveByteStateAsync(storeName, key, JsonSerializer.SerializeToUtf8Bytes(value, JsonSerializerOptions), stateOptions, metadata, cancellationToken);',
'GetByteStateAndETagAsync': '''{
        cancellationToken.ThrowIfCancellationRequested();
        ReadKeys.Add(key);
        BeforeRead?.Invoke(key);
        return Task.FromResult(_state.TryGetValue((storeName, key), out var entry)
            ? ((ReadOnlyMemory<byte>)entry.Value.ToArray(), entry.ETag) : (ReadOnlyMemory<byte>.Empty, string.Empty));
    }''',
'GetStateAndETagAsync': '''{
        cancellationToken.ThrowIfCancellationRequested();
        ReadKeys.Add(key);
        BeforeRead?.Invoke(key);
        return Task.FromResult(_state.TryGetValue((storeName, key), out var entry)
            ? (JsonSerializer.Deserialize<TValue>(entry.Value, JsonSerializerOptions), entry.ETag) : (default(TValue), string.Empty));
    }''',
'GetStateAsync': '''{
        cancellationToken.ThrowIfCancellationRequested();
        ReadKeys.Add(key);
        BeforeRead?.Invoke(key);
        return Task.FromResult(_state.TryGetValue((storeName, key), out var entry)
            ? JsonSerializer.Deserialize<TValue>(entry.Value, JsonSerializerOptions) : default);
    }''',
'TrySaveByteStateAsync': '''{
        cancellationToken.ThrowIfCancellationRequested();
        BeforeWrite?.Invoke(key);
        bool exists = _state.TryGetValue((storeName, key), out var current);
        if (exists ? current.ETag != etag : !string.IsNullOrEmpty(etag)) return Task.FromResult(false);
        _state[(storeName, key)] = (binaryValue.ToArray(), (++_revision).ToString(System.Globalization.CultureInfo.InvariantCulture));
        WrittenKeys.Add(key);
        return Task.FromResult(true);
    }''',
'SaveByteStateAsync': '''{
        cancellationToken.ThrowIfCancellationRequested();
        BeforeWrite?.Invoke(key);
        _state[(storeName, key)] = (binaryValue.ToArray(), (++_revision).ToString(System.Globalization.CultureInfo.InvariantCulture));
        WrittenKeys.Add(key);
        return Task.CompletedTask;
    }''',
'TryDeleteStateAsync': '''{
        cancellationToken.ThrowIfCancellationRequested();
        BeforeWrite?.Invoke(key);
        if (!_state.TryGetValue((storeName, key), out var current) || current.ETag != etag) return Task.FromResult(false);
        _state.Remove((storeName, key));
        WrittenKeys.Add(key);
        return Task.FromResult(true);
    }''',
'DeleteStateAsync': '''{
        cancellationToken.ThrowIfCancellationRequested();
        BeforeWrite?.Invoke(key);
        _state.Remove((storeName, key));
        WrittenKeys.Add(key);
        return Task.CompletedTask;
    }''',
}
header='''#pragma warning disable CS0672, DAPR_DISTRIBUTEDLOCK
#nullable disable

using System.Text.Json;
using Dapr.Client;

namespace Hexalith.EventStore.Testing.Fakes;

/// <summary>Isolated byte-state transport for production SDK persistence tests; never an installation authority.</summary>
public sealed class InMemoryDaprStateClient : DaprClient
{
    private readonly Dictionary<(string Store, string Key), (byte[] Value, string ETag)> _state = [];
    private long _revision;

    /// <inheritdoc/>
    public override JsonSerializerOptions JsonSerializerOptions { get; } = new(JsonSerializerDefaults.Web);

    /// <summary>Gets the observed raw read keys.</summary>
    public List<string> ReadKeys { get; } = [];

    /// <summary>Gets successful mutation keys.</summary>
    public List<string> WrittenKeys { get; } = [];

    /// <summary>Gets or sets a raw-read spy or fault injection hook.</summary>
    public Action<string> BeforeRead { get; set; }

    /// <summary>Gets or sets a pre-mutation spy or fault injection hook.</summary>
    public Action<string> BeforeWrite { get; set; }

'''
# Bulk generic only used by rich writer durability checking.
for name,sig,body in methods:
 if name=='GetBulkStateAsync' and '<TValue>' in sig:
  body='''{
        ArgumentNullException.ThrowIfNull(keys);
        cancellationToken.ThrowIfCancellationRequested();
        return Task.FromResult<IReadOnlyList<BulkStateItem<TValue>>>([.. keys.Select(key =>
        {
            ReadKeys.Add(key);
            BeforeRead?.Invoke(key);
            return _state.TryGetValue((storeName, key), out var entry)
                ? new BulkStateItem<TValue>(key, JsonSerializer.Deserialize<TValue>(entry.Value, JsonSerializerOptions), entry.ETag)
                : new BulkStateItem<TValue>(key, default, string.Empty);
        })]);
    }'''
 else: body=impl.get(name,body)
 header+='    /// <inheritdoc/>\n    '+sig+' '+body+'\n\n'
header+='}\n\n#nullable restore\n#pragma warning restore CS0672, DAPR_DISTRIBUTEDLOCK\n'
(root/'src/Hexalith.EventStore.Testing/Fakes/InMemoryDaprStateClient.cs').write_text(header)
