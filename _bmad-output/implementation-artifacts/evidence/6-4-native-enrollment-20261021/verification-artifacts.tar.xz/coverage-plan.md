# Enrollment verification plan

This run preserves the previous native provenance evidence and proves only explicitly declared local source behavior.

| Boundary | Evidence required |
| --- | --- |
| Legacy `/project` response | Same response projection and original routes; no metadata persistence or retroactive certificate |
| Negotiation | Unrequested catalog unchanged; guard descriptor only with explicit exact complete local coexistence |
| Unsupported declaration/inventory | Missing, wrong, extra, duplicate or case-conflicting relevant handlers fail enrollment before proof reads |
| Guarded named delivery | Original verified proof survives exact isolated metadata, durable generation and actual SDK terminal owner receipt |
| Tampering/replacement | Altered original input/native proof/incarnation rejected without persisted effects |
| Redelivery/replay | Stable dispatch retains original proof or absence; same current head does not certify old input |
| Reconciliation/recovery | Original immutable batch evidence retained; interruption refuses until original work recovers |
| Rebuild | Existing SDK guarded staged rebuild and coordinated rich legacy owner retained; content-free query promotion remains unavailable |
| Direct persisted writer | Invalidation barriers prevent a direct/resuming writer from keeping metadata current |
| Reads/current authority | Content-free storage spy, exact resource binding and before/after native permission/source checks; no query repair |

Installation-wide coverage, native-read enrollment, cold-activation zero-write acceptance, content-free rebuild promotion, other owner prerequisites and accepted G-4 remain separate gates. Synthetic source fixtures are not installation authority.
