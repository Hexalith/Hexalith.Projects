from pathlib import Path
import subprocess,json,difflib,hashlib
root=Path('/home/administrator/projects/hexalith/projects')
out=Path('/tmp/story64-enrollment-20261021')
initial=json.loads((out/'initial-snapshot.json').read_text())
changed={}
cumulative=bytearray()
incremental=[]
for name in ['EventStore','Conversations']:
    repo=root/'references'/('Hexalith.'+name)
    patch=subprocess.check_output(['git','diff','--binary','HEAD'],cwd=repo)
    prefix=('references/Hexalith.'+name+'/').encode()
    patch=b''.join(line.replace(b'a/',b'a/'+prefix,1).replace(b'b/',b'b/'+prefix,1) if line.startswith(b'diff --git ') else line.replace(b'--- a/',b'--- a/'+prefix,1) if line.startswith(b'--- a/') else line.replace(b'+++ b/',b'+++ b/'+prefix,1) if line.startswith(b'+++ b/') else line for line in patch.splitlines(keepends=True))
    cumulative.extend(patch)
    paths=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=repo).decode().split('\0')
    for p in paths:
        if not p or p.startswith('references/'):continue
        f=repo/p
        if f.is_file() and f.suffix in ['.cs','.csproj','.md','.json']:
            content=f.read_text().splitlines(keepends=True)
            cumulative.extend(''.join(difflib.unified_diff([],content,fromfile='/dev/null',tofile='b/references/Hexalith.'+name+'/'+p)).encode())
    inventory=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=repo).decode().split('\0')
    changes=[]
    for p in sorted(set(inventory)):
        f=repo/p
        if not p or p.startswith('references/') or not f.is_file() or f.suffix not in ['.cs','.csproj']:continue
        if initial['sources'].get(name+'/'+p)==hashlib.sha256(f.read_bytes()).hexdigest():continue
        baseline=out/'initial-files'/name/p
        try:before=baseline.read_text() if baseline.is_file() else subprocess.check_output(['git','show','HEAD:'+p],cwd=repo,stderr=subprocess.DEVNULL).decode().replace('\r\n','\n')
        except subprocess.CalledProcessError:before=''
        after=f.read_text()
        if before!=after:
            changes.append(p)
            incremental.extend(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='a/references/Hexalith.'+name+'/'+p,tofile='b/references/Hexalith.'+name+'/'+p))
    changed[name]=changes
(out/'owner-cumulative.patch').write_bytes(cumulative)
(out/'enrollment-incremental.patch').write_text(''.join(incremental))
(out/'changed-files.json').write_text(json.dumps(changed,indent=2)+'\n')
print(json.dumps({'files':changed,'cumulative_bytes':len(cumulative),'incremental_bytes':(out/'enrollment-incremental.patch').stat().st_size},indent=2))
