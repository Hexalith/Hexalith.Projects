import sys, pathlib, subprocess, hashlib, json, datetime, time
ROOT=pathlib.Path('/home/administrator/projects/hexalith/projects')
OUT=pathlib.Path('/tmp/story64-enrollment-20261021')
REPOS={'Projects':ROOT,'EventStore':ROOT/'references/Hexalith.EventStore','Conversations':ROOT/'references/Hexalith.Conversations'}
def git(repo,*args):
    r=subprocess.run(['git',*args],cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    if r.returncode: raise RuntimeError(r.stderr.decode())
    return r.stdout

def sources():
    result={}
    for name,repo in REPOS.items():
        for p in git(repo,'ls-files','-z','--cached','--others','--exclude-standard').decode().split('\0'):
            if not p or p.startswith('references/') or (name=='Projects' and p.startswith('_bmad/render/')): continue
            f=repo/p
            if f.is_file() and (p.endswith(('.cs','.csproj','.props','.targets','.slnx')) or p in ['global.json','Directory.Packages.props','.editorconfig','.gitattributes','.gitmodules','AGENTS.md']):
                result[name+'/'+p]=hashlib.sha256(f.read_bytes()).hexdigest()
    return result

def snapshot(label):
    data={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sources':sources(),'repos':{}}
    for name,repo in REPOS.items():
        data['repos'][name]={'head':git(repo,'rev-parse','HEAD').decode().strip(),'status':git(repo,'status','--porcelain=v1').decode(),'index':hashlib.sha256(git(repo,'ls-files','-s','-z')).hexdigest()}
        (OUT/(label+'-'+name+'.patch')).write_bytes(git(repo,'diff','--binary','HEAD'))
        if label=='initial':
            for p in git(repo,'ls-files','-z','--modified','--others','--exclude-standard').decode().split('\0'):
                if not p or p.startswith('references/') or p.startswith('_bmad/render/'): continue
                f=repo/p
                if f.is_file():
                    dest=OUT/'initial-files'/name/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(f.read_bytes())
    protected={}
    paths=['_bmad-output/implementation-artifacts/spec-6-4-resolve-projects-with-transient-current-explanations.md','_bmad-output/implementation-artifacts/sprint-status.yaml','_bmad-output/implementation-artifacts/6-4-prerequisite-decisions-2026-10-20.md','_bmad-output/implementation-artifacts/6-4-resolution-evidence-contracts.md','_bmad-output/implementation-artifacts/deferred-work.md']
    paths += [str(x.relative_to(ROOT)) for x in (ROOT/'_bmad-output/implementation-artifacts/evidence/6-4-native-provenance-20261021').rglob('*') if x.is_file()]
    for p in paths:
        f=ROOT/p
        if f.is_file(): protected[p]=hashlib.sha256(f.read_bytes()).hexdigest()
    spec=(ROOT/'_bmad-output/implementation-artifacts/spec-6-4-prerequisite-current-authorized-resolution-evidence.md').read_bytes()
    protected['frozen-spec-block']=hashlib.sha256(spec[spec.index(b'<frozen-after-approval'):spec.index(b'</frozen-after-approval>')+len(b'</frozen-after-approval>')]).hexdigest()
    data['protected']=protected
    (OUT/(label+'-snapshot.json')).write_text(json.dumps(data,indent=2)+'\n')
    print(json.dumps({'snapshot':label,'repos':{k:v['head'] for k,v in data['repos'].items()},'source_files':len(data['sources'])}))

if sys.argv[1]=='snapshot':snapshot(sys.argv[2]);sys.exit()
label,cwd,*argv=sys.argv[1:]
def binaries():
    result={}
    if argv and argv[0]=='dotnet':
        for arg in argv[1:]:
            assembly=pathlib.Path(cwd)/arg
            if arg.endswith('.dll') and assembly.is_file():
                for f in sorted(assembly.parent.glob('*')):
                    if f.is_file() and f.suffix in ['.dll','.json']:
                        result[str(f)]=hashlib.sha256(f.read_bytes()).hexdigest()
    return result
binary_before=binaries()
before=sources();start=datetime.datetime.now(datetime.timezone.utc).isoformat();clock=time.monotonic()
with (OUT/(label+'.log')).open('wb') as f:
    r=subprocess.run(argv,cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
record={'label':label,'cwd':cwd,'argv':argv,'start_utc':start,'seconds':round(time.monotonic()-clock,3),'exit_code':r.returncode,'log':label+'.log','source_before':before,'source_after':sources(),'binary_before':binary_before,'binary_after':binaries()}
(OUT/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k not in ['source_before','source_after','binary_before','binary_after']}))
print((OUT/(label+'.log')).read_text(errors='replace')[-4500:])
sys.exit(r.returncode)
