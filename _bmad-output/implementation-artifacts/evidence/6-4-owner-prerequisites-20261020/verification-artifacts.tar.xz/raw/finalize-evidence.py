from pathlib import Path
import hashlib,json,datetime,subprocess,re,shlex,xml.etree.ElementTree as ET
root=Path('/home/administrator/projects/hexalith/projects'); tmp=Path('/tmp/6-4-owner-delivery'); out=root/'_bmad-output/implementation-artifacts/evidence/6-4-owner-prerequisites-20261020'
def sha(b): return hashlib.sha256(b).hexdigest()
def write(name,j): (out/name).write_text(json.dumps(j,indent=2)+'\n')
selected=['final-eventstore-client','final-eventstore-server','final-eventstore-routes','review-domainservice-focused-01','final-tenants-authority','final-conversations-full','final-folders-core-tests','final-folders-server-full','final-projects-owner-integration']
builds=['review-client-build-06','review-server-build-01','review-domainservice-build-01','review-conversations-build-02','review-tenants-build-01','final-folders-core-build','final-folders-server-build','final-projects-build']
commands=[]
for f in sorted(tmp.glob('*.json')):
 j=json.loads(f.read_text())
 if not isinstance(j,dict):continue
 argv=j.get('argv',j.get('command'))
 if not isinstance(argv,list): continue
 r={k:v for k,v in j.items() if k!='source_files'}
 r.update(id=f.stem,record=f.name,record_sha256=sha(f.read_bytes()),selected_closing=f.stem in selected+builds)
 if 'source_files' in j:
  changes=[]
  for path,digest in j['source_files'].items():
   if not (path.startswith(('src/','tests/')) or path in ['Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json']):continue
   p=Path(j['cwd'])/path
   if not p.is_file() or sha(p.read_bytes())!=digest:changes.append(path)
  r['current_build_source_matches']=not changes; r['current_build_source_changes']=changes
  if r['selected_closing']:assert not changes,(f,changes)
 if r['selected_closing']:
  assert j.get('exit',j.get('exit_code'))==0,f
  if f.stem in selected:assert j.get('counts',{}).get('total',0)>0,f
 commands.append(r)
write('command-records.json',{'note':'Exact argv/cwd and outcomes. Raw records, per-command source hashes, full logs and native XML are in verification-artifacts.tar.xz. Only selected_closing records describe the final checkpoint. Failed, timed-out, empty and superseded attempts remain retained. Source-fixture success does not establish production authority.','records':commands})
source=json.loads((tmp/'final-source-manifest.json').read_text());write('source-manifest.json',source)
protect=json.loads((tmp/'protected-preservation.json').read_text())
for item in protect['root_files']:
 p=root/item['path']; item['current_sha256']=sha(p.read_bytes()) if p.is_file() else None
 item['unchanged_since_start']=item['current_sha256']==item['initial_sha256'];assert item['unchanged_since_start'],item['path']
for item in protect['owner_configuration']:
 p=root/item['repository']/item['path'];item['current_sha256']=sha(p.read_bytes()) if p.is_file() else None
 item['unchanged_since_start']=item['current_sha256']==item['initial_sha256'];assert item['unchanged_since_start'],item
for f in ['.gitmodules','Directory.Build.props','Directory.Packages.props','global.json']:
 repo=root/'references/Hexalith.Tenants';p=repo/f
 before=subprocess.run(['git','show','1f0f4edb6be91dd07028c0303a3f308841c3b414:'+f],cwd=repo,capture_output=True)
 initial=sha(before.stdout) if before.returncode==0 else None; current=sha(p.read_bytes()) if p.is_file() else None
 assert initial==current,f
 protect['owner_configuration'].append({'repository':'references/Hexalith.Tenants','path':f,'baseline':'1f0f4edb6be91dd07028c0303a3f308841c3b414','initial_sha256':initial,'current_sha256':current,'unchanged_since_start':True})
spec=(root/'_bmad-output/implementation-artifacts/spec-6-4-prerequisite-current-authorized-resolution-evidence.md').read_text()
frozen=re.search(r'<frozen-after-approval.*?</frozen-after-approval>',spec,re.S).group()
expected=json.loads((tmp/'frozen-spec-preservation.json').read_text())['initial_sha256'];assert sha(frozen.encode())==expected
protect['captured_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();protect['frozen_spec']={'initial_sha256':expected,'current_sha256':sha(frozen.encode()),'equal':True}
raw_spec=(root/'_bmad-output/implementation-artifacts/spec-6-4-prerequisite-current-authorized-resolution-evidence.md').read_bytes()
raw_frozen=re.search(rb'<frozen-after-approval.*?</frozen-after-approval>',raw_spec,re.S).group()
original_spec=subprocess.check_output(['git','show','1be617abe38773ca665cb3e44bf8f6d812f574a1:_bmad-output/implementation-artifacts/spec-6-4-prerequisite-current-authorized-resolution-evidence.md'],cwd=root)
original_frozen=re.search(rb'<frozen-after-approval.*?</frozen-after-approval>',original_spec,re.S).group()
assert raw_frozen==original_frozen
protect['frozen_spec']['hash_representation']='normalized LF text; historical preservation receipt'
protect['frozen_spec']['raw_sha256']=sha(raw_frozen)
protect['frozen_spec']['original_raw_sha256']=sha(original_frozen)
protect['frozen_spec']['raw_bytes_equal_original_revision']=True
protect['gates']={'spec_status':'in-progress','RTI_implementation_authorized':False,'parent_handlers_unchanged':True,'accepted_G4_consumption_established':False,'production_completeness_established':False}
write('preservation.json',protect)
# Clear replayable command text for the final checkpoint; JSON retains every earlier attempt.
lines=['# Closing commands','','These are exact argv rendered with shell quoting, in the recorded working directory. Debug source references were used; dependency versions were not changed. Raw records and XML are in the archive.','']
for name in builds+selected:
 j=json.loads((tmp/(name+'.json')).read_text());a=j.get('argv',j.get('command'))
 lines += ['## '+name,'','Working directory: `'+j['cwd']+'`','', '```sh',shlex.join(a),'```','', 'Result: exit '+str(j.get('exit',j.get('exit_code')))+(('; '+json.dumps(j['counts'])) if 'counts' in j else ''), '']
(out/'commands.md').write_text('\n'.join(lines))
# Source facts are explicitly kept apart from unresolved owner delivery and external qualification.
protocol=json.loads((tmp/'review-fix-final-manifest.json').read_text())['remaining_protocol']
write('verification-summary.json',{'captured_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'selected_closing':[{k:v for k,v in next(r for r in commands if r['id']==n).items() if k in ['id','counts','source_sha256','head','exit','xml_sha256','log_sha256','current_build_source_matches']} for n in selected],'builds':builds,'historical_limits':{'folders-core-full.xml':'2166 pass, 4 failures at absent nested Builds Props/Directory.Packages.props, 2 external-provider skips; no nested initialization or pin/gate changes.','closing-conversations-full.xml':'997 pass/16 DI failures; superseded by final-conversations-full.xml 1013 pass.','eventstore-native-reader-tests-2.xml':'Stale Client binary after failed CS0122 source build: EXCLUDED, never current-source evidence.','native-conversations-focused-final.xml':'Timed out/empty or incomplete, EXCLUDED. See exact command records.','native-conversations-focused-final-02.xml':'Timed out/incomplete, EXCLUDED. See exact command records.'},'reviewed_snapshot':{'file':'review-owner-source.patch','bytes':(tmp/'review-owner-source.patch').stat().st_size,'sha256':sha((tmp/'review-owner-source.patch').read_bytes())},'final_snapshot':{'file':'final-owner-source.patch','bytes':(tmp/'final-owner-source.patch').stat().st_size,'sha256':sha((tmp/'final-owner-source.patch').read_bytes())},'remaining_native_rebuild_protocol':protocol,'qualification':'Source builds, serialized state fixtures and in-process HTTP only. No certified installation, deployed native Folder/Conversation authority, exact-current qualification or accepted Projects G-4 consumption.'})
report=out/'owner-contracts.md';text=report.read_text();heading='## Exact revisions and retained verification'
if heading in text:text=text.split(heading)[0].rstrip()+'\n'
rows=['| Repository | Closing HEAD | Comparison baseline |','| --- | --- | --- |']
for name in ['Projects','Hexalith.EventStore','Hexalith.Conversations','Hexalith.Folders','Hexalith.Tenants','Hexalith.Builds','Hexalith.Platform']:
 r=source['repositories'][name];rows.append('| '+name+' | `'+r['head']+'` | '+('`'+r['baseline']+'`' if 'baseline' in r else 'preservation/context only')+' |')
text+='\n'+heading+'\n\n'+'\n'.join(rows)+'\n\n'
text+='The [source manifest](source-manifest.json) binds '+str(sum(len(r.get('files',[])) for r in source['repositories'].values()))+' changed owner source/test files to SHA-256 hashes and complete patches from the comparison baselines. These deltas include concurrent commits; they are not an attribution claim. The archive retains the original reviewed snapshot and the final corrected snapshot separately. [Preservation evidence](preservation.json) confirms protected parent/spec/sprint/pin bytes and the frozen block remain unchanged. No stage, commit, push, dependency update or submodule update was performed by this run.\n\n'
text+='| Final checkpoint | Passed | Failed | Skipped | Command record |\n| --- | ---: | ---: | ---: | --- |\n'
labels=['SDK Client native inventory/feed, reader and batch recovery','SDK Server native actor/proof/current authority','SDK canonical endpoint mapping','SDK real delegated-origin client','Tenant native Read/Owner authority','Conversation Server full suite','Folder core focused mutations/authorization','Folder Server full suite','Projects owner integration subset']
for name,label in zip(selected,labels):
 c=json.loads((tmp/(name+'.json')).read_text())['counts'];text+=f'| {label} | {c["passed"]} | {c["failed"]} | {c["skipped"]} | `{name}` |\n'
text+='\nAll eight closing source builds listed in [commands.md](commands.md) exited 0. [Command records](command-records.json) retain exact working directories, argv, outcomes, source and log hashes. [Verification summary](verification-summary.json) identifies final, failed, stale and superseded evidence. The [archive](verification-artifacts.tar.xz) contains full command records/source maps, logs, native XML, patches, Platform checks, sanitized Aspire results and review correction evidence. [Artifact hashes](artifact-manifest.json) bind every archive member.\n\n'
text+='The focused native tests use the SDK source codec, serialized actor/read-model state and signed HTTP client path. Installation/permission test doubles remain test doubles. Passing recovery, revocation/regrant and initialized-empty cases establishes source behavior, not certified production coverage. In particular, warm actor inspection does not qualify cold activation, and successful legacy metadata rebuild/recovery does not complete native post-rebuild promotion.\n'
report.write_text(text)
print(json.dumps({'closing_tests':{n:json.loads((tmp/(n+'.json')).read_text())['counts'] for n in selected},'source_files':sum(len(r.get('files',[])) for r in source['repositories'].values()),'protected_root_files':len(protect['root_files']),'frozen_unchanged':True},indent=2))
