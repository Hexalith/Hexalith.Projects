from pathlib import Path
r=Path('/home/administrator/projects/hexalith/projects/references/Hexalith.Conversations')
def put(f,s): (r/f).write_text(s)
def rep(f,a,b):
 p=r/f;s=p.read_text();assert a in s,f;p.write_text(s.replace(a,b))
f='src/Hexalith.Conversations.Server/Projections/ConversationProjectedReadModels.cs'
rep(f,'    public string DispatchId { get; init; } = string.Empty;','''    public string DispatchId { get; init; } = string.Empty;

    /// <summary>Gets the exact source-local sequence supplied by the named producer, separate from projection position.</summary>
    public long? SourceHeadSequence { get; init; }

    /// <summary>Gets the actual native persisted head message, absent for legacy materializations.</summary>
    public string? SourceHeadMessageId { get; init; }
''')
f='src/Hexalith.Conversations.Server/Projections/ConversationResolutionMetadataReadModel.cs'
rep(f,'    /// <summary>The owner classification bound','''    /// <summary>Gets the exact native source-local sequence admitted by the named producer.</summary>
    public long? SourceHeadSequence { get; init; }

    /// <summary>Gets the actual persisted event identity, never an allocated generation identity.</summary>
    public string? SourceHeadMessageId { get; init; }

    /// <summary>The owner classification bound''')
rep(f,'complete ? ConversationResolutionScoringPolicy.Classification : null);','''complete ? ConversationResolutionScoringPolicy.Classification : null)
        { SourceHeadSequence = models.SourceHeadSequence, SourceHeadMessageId = models.SourceHeadMessageId };''')
f='src/Hexalith.Conversations.Server/Projections/ConversationAsyncProjectionHandler.cs'
rep(f,'            metadataWriteFailed: false);','''            metadataWriteFailed: false) with
        {
            SourceHeadSequence = request.Events.LastOrDefault()?.SequenceNumber,
            SourceHeadMessageId = request.Events.LastOrDefault()?.MessageId,
        };''')
# Small standalone selection row; queries/proof readers never hydrate rich rebuild manifests.
put('src/Hexalith.Conversations.Server/Projections/ConversationResolutionNativeSelection.cs','''using Hexalith.EventStore.Contracts.Projections;

namespace Hexalith.Conversations.Server.Projections;

/// <summary>Content-free selected output metadata embedded in the original committed metadata batch.</summary>
/// <param name="ProjectionVersion">The unmodified owner freshness version.</param>
/// <param name="ProjectionOwner">The exact source identity, actual head message and immutable subset generation.</param>
public sealed record ConversationResolutionNativeSelection(string ProjectionVersion, ProjectionOwnerSelection ProjectionOwner)
{
    /// <summary>Builds evidence only when the named producer supplied an actual persisted event identity.</summary>
    internal static ConversationResolutionNativeSelection? From(ConversationResolutionMetadataReadModel model, string batchId,
        bool rebuild = false)
        => model.SourceHeadSequence is > 0 && !string.IsNullOrWhiteSpace(model.SourceHeadMessageId)
            ? new(model.Freshness.ProjectionCursor, new(1, model.TenantId.Value, ConversationProjectionHandler.ConversationDomain,
                model.ConversationId.Value, ConversationAsyncProjectionHandler.ConversationReadModelProjectionType,
                model.ConversationId.Value, model.Digest(), model.SourceHeadSequence.Value, model.SourceHeadMessageId,
                batchId, model.Freshness.ProjectionCursor) { ReceiptProjectionName = rebuild ? "rebuild" : null }) : null;
}
''')
f='src/Hexalith.Conversations.Server/Projections/ConversationProjectionReadModelKeys.cs'
rep(f,'    /// <summary>Builds the permanent content-free generation-proof key.</summary>','''    /// <summary>Builds the bounded native selected-generation key; it contains no detail or rich manifest.</summary>
    internal static string ResolutionSelectionKey(TenantId tenantId, ConversationId conversationId)
        => $"projection:conversations-resolution-selection:{ResolutionStorageToken(tenantId.Value)}:{ResolutionStorageToken(conversationId.Value)}";

    /// <summary>Builds the permanent content-free generation-proof key.</summary>''')
f='src/Hexalith.Conversations.Server/Projections/ConversationResolutionMetadataPersistence.cs'
# Actual identities in new receipt scopes; explicit old-scope recovery remains first for interrupted historical writes.
rep(f,'                ConversationProjectionHandler.ConversationDomain, ConversationProjectionReadModelKeys.ResolutionStorageToken(conversationId.Value), "resolution-metadata", "pending-discovery"),','                ConversationProjectionHandler.ConversationDomain, ConversationProjectionReadModelKeys.ResolutionStorageToken(conversationId.Value), "resolution-metadata", "pending-discovery"),') if False else None
# Recover scope belongs to existing marker; platform ignores proposed scope tokens? inspect later, preserve both scopes via own key.
rep(f,'        ReadModelBatchResult result = await batches.ExecuteAsync(new(new(\n            ConversationProjectionReadModelKeys.StateStoreName, ConversationProjectionReadModelKeys.ResolutionStorageToken(model.TenantId.Value), ConversationProjectionHandler.ConversationDomain,\n            ConversationProjectionReadModelKeys.ResolutionStorageToken(model.ConversationId.Value), "resolution-metadata", batchId), operations)\n            { RetainManifestForRecovery = true }, cancellationToken).ConfigureAwait(false);','''        ConversationResolutionNativeSelection? selected = ConversationResolutionNativeSelection.From(model, batchId);
        if (selected is not null)
        {
            string selectionKey = ConversationProjectionReadModelKeys.ResolutionSelectionKey(model.TenantId, model.ConversationId);
            var priorSelection = await store.GetAsync<ConversationResolutionNativeSelection>(
                ConversationProjectionReadModelKeys.StateStoreName, selectionKey, cancellationToken).ConfigureAwait(false);
            operations.Add(ReadModelBatchOperation.Write(selectionKey, selected, Concurrency(priorSelection)));
        }
        ReadModelBatchResult result = await batches.ExecuteAsync(new(new(
            ConversationProjectionReadModelKeys.StateStoreName, model.TenantId.Value, ConversationProjectionHandler.ConversationDomain,
            model.ConversationId.Value, ConversationAsyncProjectionHandler.ConversationReadModelProjectionType, batchId), operations)
            { RetainManifestForRecovery = true, OwnerSelection = selected?.ProjectionOwner }, cancellationToken).ConfigureAwait(false);''')
# probe current scope first; legacy historical scope fallback only applies to known stored batch metadata, no authority assigned
rep(f,'ConversationProjectionReadModelKeys.StateStoreName, ConversationProjectionReadModelKeys.ResolutionStorageToken(tenantId.Value),\n                ConversationProjectionHandler.ConversationDomain, ConversationProjectionReadModelKeys.ResolutionStorageToken(conversationId.Value), "resolution-metadata", "pending-discovery"','ConversationProjectionReadModelKeys.StateStoreName, tenantId.Value,\n                ConversationProjectionHandler.ConversationDomain, conversationId.Value, ConversationAsyncProjectionHandler.ConversationReadModelProjectionType, "pending-discovery"')
rep(f,'            ConversationProjectionReadModelKeys.ResolutionMetadataKey(tenantId, conversationId),','            ConversationProjectionReadModelKeys.ResolutionMetadataKey(tenantId, conversationId),\n            ConversationProjectionReadModelKeys.ResolutionSelectionKey(tenantId, conversationId),')
# Rebuild can embed original native selection, but legacy SDK receipt remains unqualified and gate refuses it.
f='src/Hexalith.Conversations.Server/Projections/ConversationAsyncProjectionHandler.cs'
rep(f,'        return new DomainProjectionRebuildPlan(\n            ConversationProjectionReadModelKeys.StateStoreName,\n            [','''        ConversationResolutionNativeSelection? nativeSelection = ConversationResolutionNativeSelection.From(metadata, operationId, rebuild: true);
        var priorSelection = await _store.GetAsync<ConversationResolutionNativeSelection>(
            ConversationProjectionReadModelKeys.StateStoreName,
            ConversationProjectionReadModelKeys.ResolutionSelectionKey(metadata.TenantId, metadata.ConversationId), cancellationToken).ConfigureAwait(false);
        List<ReadModelBatchOperation> nativeOperations = nativeSelection is null ? [] :
            [ReadModelBatchOperation.Write(ConversationProjectionReadModelKeys.ResolutionSelectionKey(metadata.TenantId, metadata.ConversationId),
                nativeSelection, WriteConcurrency(priorSelection))];
        return new DomainProjectionRebuildPlan(
            ConversationProjectionReadModelKeys.StateStoreName,
            [
                .. nativeOperations,''')
put('src/Hexalith.Conversations.Server/Queries/IConversationResolutionNativeEvidence.cs','''using Hexalith.Conversations.Server.Projections;
using Hexalith.EventStore.Contracts.Projections;
using Hexalith.EventStore.Contracts.Queries;
using Hexalith.Tenants.Contracts.Queries;

namespace Hexalith.Conversations.Server.Queries;

/// <summary>Current native evidence transported through the SDK; this interface conveys no cached grant.</summary>
public interface IConversationResolutionNativeEvidence
{
    /// <summary>Reads the exact delegated actor's current native Tenant Read decision.</summary>
    Task<TenantReadAuthorityResult?> ReadTenantAsync(QueryEnvelope query, CancellationToken cancellationToken);
    /// <summary>Inspects the original selected immutable generation through the existing native guard.</summary>
    Task<ProjectionCurrentProof?> ReadProjectionAsync(ConversationResolutionMetadataReadModel metadata, CancellationToken cancellationToken);
}
''')
put('src/Hexalith.Conversations.Server/Queries/ConversationResolutionNativeEvidence.cs','''using System.Text.Json;
using Hexalith.Conversations.Server.Projections;
using Hexalith.EventStore.Client.Projections;
using Hexalith.EventStore.Contracts.Projections;
using Hexalith.EventStore.Contracts.Queries;
using Hexalith.EventStore.DomainService;
using Hexalith.Tenants.Contracts.Queries;

namespace Hexalith.Conversations.Server.Queries;

/// <summary>Uses only the existing signed bound-owner SDK and isolated content-free selected-owner key.</summary>
/// <param name="client">The existing delegated SDK transport.</param>
/// <param name="store">The supported read-model store.</param>
public sealed class ConversationResolutionNativeEvidence(DelegatedOwnerQueryClient client, IReadModelStore store)
    : IConversationResolutionNativeEvidence
{
    /// <inheritdoc/>
    public async Task<TenantReadAuthorityResult?> ReadTenantAsync(QueryEnvelope query, CancellationToken cancellationToken)
    {
        QueryResult result = await client.InvokeAsync(new(query.TenantId, "tenants", query.TenantId,
            ResolveTenantReadAuthority.QueryType, Payload: JsonSerializer.SerializeToElement(new ResolveTenantReadAuthority(), JsonSerializerOptions.Web)),
            cancellationToken).ConfigureAwait(false);
        if (!result.Success) return null;
        TenantReadAuthorityResult? evidence = result.GetPayload().Deserialize<TenantReadAuthorityResult>(JsonSerializerOptions.Web);
        return evidence?.TenantId == query.TenantId && evidence.PrincipalId == query.UserId
            && evidence.NativeProof is { TenantId: "system", Domain: "tenants", Erased: false }
            && evidence.NativeProof.AggregateId == query.TenantId ? evidence : null;
    }

    /// <inheritdoc/>
    public async Task<ProjectionCurrentProof?> ReadProjectionAsync(ConversationResolutionMetadataReadModel metadata, CancellationToken cancellationToken)
    {
        var selected = await store.GetAsync<ConversationResolutionNativeSelection>(ConversationProjectionReadModelKeys.StateStoreName,
            ConversationProjectionReadModelKeys.ResolutionSelectionKey(metadata.TenantId, metadata.ConversationId), cancellationToken).ConfigureAwait(false);
        ProjectionOwnerSelection? selection = selected.Value?.ProjectionOwner;
        if (string.IsNullOrEmpty(selected.ETag) || selection is null || selection.OwnerGeneration != metadata.Digest()
            || selection.TenantId != metadata.TenantId.Value || selection.AggregateId != metadata.ConversationId.Value
            || selection.Domain != ConversationProjectionHandler.ConversationDomain
            || selection.ProjectionName != ConversationAsyncProjectionHandler.ConversationReadModelProjectionType
            || selection.AppliedSequence != metadata.SourceHeadSequence || selection.MessageId != metadata.SourceHeadMessageId
            || selection.FreshnessVersion != metadata.Freshness.ProjectionCursor) return null;
        QueryResult result = await client.InvokeAsync(new(selection.TenantId, selection.Domain, selection.AggregateId,
            InspectProjectionCurrentQuery.QueryType, Payload: JsonSerializer.SerializeToElement(new InspectProjectionCurrentQuery(selection), JsonSerializerOptions.Web)),
            cancellationToken).ConfigureAwait(false);
        if (!result.Success) return null;
        ProjectionCurrentProof? proof = result.GetPayload().Deserialize<ProjectionCurrentProof>(JsonSerializerOptions.Web);
        return proof?.Owner.Selection == selection && proof.Source.TenantId == selection.TenantId
            && proof.Source.Domain == selection.Domain && proof.Source.AggregateId == selection.AggregateId
            && proof.Source.HeadSequence == selection.AppliedSequence && proof.Source.HeadMessageId == selection.MessageId ? proof : null;
    }
}
''')
# Explicit owner registration leaves legacy SDK refusal active; nothing certifies deployment/qualification.
put('src/Hexalith.Conversations.Server/Projections/ConversationResolutionNativeProofRegistration.cs','''using Hexalith.Conversations.Contracts.Identifiers;
using Hexalith.EventStore.DomainService;
using Microsoft.Extensions.DependencyInjection;

namespace Hexalith.Conversations.Server.Projections;

/// <summary>Explicit source-proof descriptor for owner-controlled enrollment; coexisting legacy routes remain refused by the SDK.</summary>
public static class ConversationResolutionNativeProofRegistration
{
    /// <summary>Registers the exact named route and private selection key without activating or qualifying any source guard.</summary>
    public static IServiceCollection AddConversationResolutionNativeProof(this IServiceCollection services)
    {
        ArgumentNullException.ThrowIfNull(services);
        services.AddSingleton(new DomainProjectionOwnerProofRegistration(ConversationProjectionHandler.ConversationDomain,
            ConversationAsyncProjectionHandler.ConversationReadModelProjectionType,
            new(1, 1, 1, "full-replay-v1", "projection-owner-proof/v1", null, null),
            new(ConversationProjectionReadModelKeys.StateStoreName, "resolution-native-selection")
            { SelectionKey = request => ConversationProjectionReadModelKeys.ResolutionSelectionKey(new TenantId(request.TenantId),
                new ConversationId(request.AggregateId)) }));
        return services;
    }
}
''')
f='src/Hexalith.Conversations.Server/Queries/ConversationQueryServiceCollectionExtensions.cs'
rep(f,'        services.TryAddScoped<ConversationResolutionMetadataAuthorization>();','''        services.TryAddScoped<ConversationResolutionMetadataAuthorization>();
        services.TryAddScoped<IConversationResolutionNativeEvidence, ConversationResolutionNativeEvidence>();''')
f='src/Hexalith.Conversations.Server/Queries/GetConversationResolutionMetadataDomainQueryHandler.cs'
rep(f,'/// <param name="store">','/// <param name="native">The strict native source and permission gate; absence withholds metadata.</param>\n/// <param name="store">')
rep(f,'    IConversationProjectionReadStore store) : IDomainQueryHandler','    IConversationProjectionReadStore store,\n    IConversationResolutionNativeEvidence? native = null) : IDomainQueryHandler')
rep(f,'            ConversationResolutionMetadataReadModel? metadata = await store.ReadResolutionMetadataAsync','''            var tenantBefore = native is null ? null : await native.ReadTenantAsync(query, cancellationToken).ConfigureAwait(false);
            if (tenantBefore is null) return Unavailable();
            if (!tenantBefore.Allowed) return QueryResult.Failure("safe-denial");
            ConversationResolutionMetadataReadModel? metadata = await store.ReadResolutionMetadataAsync''')
rep(f,'            var final = await authorization.CheckAsync','''            var resourceBefore = await native!.ReadProjectionAsync(metadata, cancellationToken).ConfigureAwait(false);
            if (resourceBefore is null) return Unavailable();
            var final = await authorization.CheckAsync''')
rep(f,'            cancellationToken.ThrowIfCancellationRequested();\n            return Success(new(metadata.Metadata, metadata.Freshness, metadata.Freshness.ProjectionCursor,\n                final.PermissionVersion, final.AuthorizedAt));','''            var tenantAfter = await native!.ReadTenantAsync(query, cancellationToken).ConfigureAwait(false);
            if (tenantAfter is { Allowed: false }) return QueryResult.Failure("safe-denial");
            var resourceAfter = await native.ReadProjectionAsync(confirmed, cancellationToken).ConfigureAwait(false);
            if (tenantAfter is null || tenantAfter.NativeProof != tenantBefore.NativeProof
                || tenantAfter.TenantId != query.TenantId || tenantAfter.PrincipalId != query.UserId
                || resourceAfter != resourceBefore) return Unavailable();
            cancellationToken.ThrowIfCancellationRequested();
            return Success(new(metadata.Metadata, metadata.Freshness,
                JsonSerializer.Serialize(resourceAfter.Source, JsonSerializerOptions.Web),
                JsonSerializer.Serialize(tenantAfter.NativeProof, JsonSerializerOptions.Web), tenantAfter.VerifiedAt));''')
