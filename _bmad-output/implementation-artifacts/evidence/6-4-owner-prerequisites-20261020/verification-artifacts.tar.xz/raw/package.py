from pathlib import Path
import json,hashlib,zipfile,datetime
root=Path('/home/administrator/projects/hexalith/projects');tmp=Path('/tmp/6-4-owner-delivery');out=root/'_bmad-output/implementation-artifacts/evidence/6-4-owner-prerequisites-20261020'
def sha(b):return hashlib.sha256(b).hexdigest()
archive=out/'verification-artifacts.zip'; members=[]
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for path in sorted(tmp.rglob('*')):
  if not path.is_file() or path.suffix not in {'.json','.xml','.log','.patch','.py','.md','.cs'}:continue
  name='raw/'+path.relative_to(tmp).as_posix();data=path.read_bytes()
  info=zipfile.ZipInfo(name,date_time=(2026,10,20,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
  z.writestr(info,data);members.append({'path':name,'bytes':len(data),'sha256':sha(data)})
external=[]
for path in sorted(out.iterdir()):
 if path.is_file() and path.name!='artifact-manifest.json':external.append({'path':path.name,'bytes':path.stat().st_size,'sha256':sha(path.read_bytes())})
manifest={'captured_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':archive.name,'archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,'external_files':external,'archive_members':members,'note':'Raw commands/results/source maps, earlier failed/stale attempts, actual source patches and sanitized environment checks. Not production qualification. Artifact hashes provide integrity only, never completeness or native authority.'}
(out/'artifact-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for member in members:assert sha(z.read(member['path']))==member['sha256']
print(json.dumps({'archive_bytes':archive.stat().st_size,'archive_members':len(members),'archive_sha256':manifest['archive_sha256'],'integrity':'verified'},indent=2))
