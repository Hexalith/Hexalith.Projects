from pathlib import Path
import subprocess,hashlib,json,datetime,zipfile,xml.etree.ElementTree as ET
root=Path('/home/administrator/projects/hexalith/projects'); tmp=Path('/tmp/6-4-owner-delivery'); out=root/'_bmad-output/implementation-artifacts/evidence/6-4-owner-prerequisites-20261020'
baselines={'Hexalith.EventStore':'6c56c27bc1a8d63c83f9631f7162cf79fdde0a1e','Hexalith.Conversations':'0c7bfac19cafbf4cbb2f67340b06e569280ef05a','Hexalith.Folders':'9bacd7f62848c23222dc7309635eb65dc6e5ed9c','Hexalith.Tenants':'1f0f4edb6be91dd07028c0303a3f308841c3b414'}
def git(repo,*args):return subprocess.check_output(['git',*args],cwd=repo)
def sha(data):return hashlib.sha256(data).hexdigest()
doc={'captured_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'kind':'owner-source-delivery; partial prerequisites, no production completeness or qualification acceptance','note':'Initial preservation revisions identify the source comparison, not authorship of concurrent commits. Working patches include named source/test changes and untracked source. No stage/commit/push/submodule/dependency action was performed by this run.','repositories':{}}
review=[]
for name,base in baselines.items():
 repo=root/'references'/name
 tracked=git(repo,'diff','--name-only',base,'--','src','tests').decode().splitlines()
 untracked=git(repo,'ls-files','--others','--exclude-standard','--','src','tests').decode().splitlines()
 patch=git(repo,'diff','--binary',base,'--','src','tests')
 for f in untracked:
  r=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',f],cwd=repo,capture_output=True)
  if r.returncode not in (0,1):raise RuntimeError(r.stderr.decode())
  patch+=r.stdout
 patchname=name+'-closing-source.patch';(tmp/patchname).write_bytes(patch)
 files=[]
 for f in sorted(set(tracked+untracked)):
  p=repo/f
  old=subprocess.run(['git','show',base+':'+f],cwd=repo,capture_output=True)
  files.append({'path':f,'sha256':sha(p.read_bytes()) if p.is_file() else None,'baseline_sha256':sha(old.stdout) if old.returncode==0 else None})
 doc['repositories'][name]={'baseline':base,'head':git(repo,'rev-parse','HEAD').decode().strip(),'branch':git(repo,'branch','--show-current').decode().strip(),'status':git(repo,'status','--porcelain').decode(),'files':files,'patch':patchname,'patch_sha256':sha(patch),'patch_bytes':len(patch)}
 review.append(('# Repository: references/'+name+'; source comparison '+base+'\n').encode()+patch)
for name,path in [('Projects',root),('Hexalith.Builds',root/'references/Hexalith.Builds'),('Hexalith.Platform',root/'references/Hexalith.Platform')]:
 doc['repositories'][name]={'head':git(path,'rev-parse','HEAD').decode().strip(),'branch':git(path,'branch','--show-current').decode().strip(),'status':git(path,'status','--porcelain').decode()}
(tmp/'closing-source-manifest.json').write_text(json.dumps(doc,indent=2)+'\n')
(tmp/'review-owner-source.patch').write_bytes(b'\n'.join(review))
print(json.dumps({'review_bytes':(tmp/'review-owner-source.patch').stat().st_size,'owner_files':{n:len(r.get('files',[])) for n,r in doc['repositories'].items()}},indent=2))
