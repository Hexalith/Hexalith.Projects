from pathlib import Path
import json,hashlib,tarfile,datetime,io
root=Path('/home/administrator/projects/hexalith/projects');tmp=Path('/tmp/6-4-owner-delivery');out=root/'_bmad-output/implementation-artifacts/evidence/6-4-owner-prerequisites-20261020'
def sha(b):return hashlib.sha256(b).hexdigest()
old=out/'verification-artifacts.zip'
if old.exists():
 assert sha(old.read_bytes())=='51d18fae6341b9abba6c5c7d0e4a7290bafc0ffb4a83eee6cab742b60c2e9178'
 old.unlink()
archive=out/'verification-artifacts.tar.xz';members=[]
with tarfile.open(archive,'w:xz',preset=6) as tar:
 for path in sorted(tmp.rglob('*')):
  if not path.is_file() or path.suffix not in {'.json','.xml','.log','.patch','.py','.md','.cs'}:continue
  name='raw/'+path.relative_to(tmp).as_posix();data=path.read_bytes()
  info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644
  tar.addfile(info,io.BytesIO(data));members.append({'path':name,'bytes':len(data),'sha256':sha(data)})
external=[]
for path in sorted(out.iterdir()):
 if path.is_file() and path.name!='artifact-manifest.json':external.append({'path':path.name,'bytes':path.stat().st_size,'sha256':sha(path.read_bytes())})
manifest={'captured_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':archive.name,'archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,'external_files':external,'archive_members':members,'note':'Raw commands/results/source maps, earlier failed/stale attempts, actual source patches and sanitized environment checks. Not production qualification. Artifact hashes provide integrity only, never completeness or native authority.'}
(out/'artifact-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(archive,'r:xz') as tar:
 for member in members:assert sha(tar.extractfile(member['path']).read())==member['sha256']
print(json.dumps({'archive_bytes':archive.stat().st_size,'archive_members':len(members),'archive_sha256':manifest['archive_sha256'],'integrity':'verified'},indent=2))
