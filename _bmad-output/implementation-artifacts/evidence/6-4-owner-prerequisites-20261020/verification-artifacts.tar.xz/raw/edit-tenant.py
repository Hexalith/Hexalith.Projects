from pathlib import Path
r=Path('/home/administrator/projects/hexalith/projects/references/Hexalith.Tenants')
def put(f,s): (r/f).write_text(s)
p=r/'src/Hexalith.Tenants/Queries/Handlers/TenantOwnerAuthorityQueryHandler.cs';s=p.read_text();s=s.replace('    private static bool TryFold(', '    internal static bool TryFold(');p.write_text(s)
put('src/Hexalith.Tenants.Contracts/Queries/ResolveTenantReadAuthority.cs','''namespace Hexalith.Tenants.Contracts.Queries;

/// <summary>Requests current Tenant Read authority for the fixed owner metadata purpose; the payload is empty.</summary>
public sealed record ResolveTenantReadAuthority
{
    /// <summary>The exact additive delegated query discriminator.</summary>
    public const string QueryType = "Hexalith.Tenants.Queries.ResolveTenantReadAuthority.v1";
}
''')
put('src/Hexalith.Tenants.Contracts/Queries/TenantReadAuthorityResult.cs','''using Hexalith.EventStore.Contracts.Streams;

namespace Hexalith.Tenants.Contracts.Queries;

/// <summary>Content-free current Read evidence from the native canonical Tenant prefix.</summary>
/// <param name="TenantId">The exact managed Tenant, independent of the internal system source scope.</param>
/// <param name="PrincipalId">The SDK-verified actor.</param>
/// <param name="Allowed">The current existing Reader, Contributor or Owner Read policy decision.</param>
/// <param name="NativeProof">The actual native prefix folded for this decision.</param>
/// <param name="VerifiedAt">The final native source verification instant.</param>
public sealed record TenantReadAuthorityResult(string TenantId, string PrincipalId, bool Allowed,
    NativeSourceProof NativeProof, DateTimeOffset VerifiedAt);
''')
put('src/Hexalith.Tenants/Queries/Handlers/TenantReadAuthorityQueryHandler.cs','''using System.Text.Json;
using Hexalith.EventStore.Client.Streams;
using Hexalith.EventStore.Contracts.Identity;
using Hexalith.EventStore.Contracts.Queries;
using Hexalith.EventStore.DomainService;
using Hexalith.Tenants.Contracts.Enums;
using Hexalith.Tenants.Contracts.Queries;
using Microsoft.AspNetCore.Http;

namespace Hexalith.Tenants.Queries.Handlers;

/// <summary>Folds the exact native Tenant prefix for the fixed owner metadata Read purpose without returning roster or grants.</summary>
/// <param name="reader">The existing authenticated source gateway reader, explicitly requiring native proof.</param>
/// <param name="metadata">The native metadata seam for the final source sample.</param>
/// <param name="accessor">The SDK-established exact caller.</param>
/// <param name="clock">The server observation clock.</param>
public sealed class TenantReadAuthorityQueryHandler(IAuthoritativeEventStreamReader reader,
    INativeSourceMetadataReader metadata, IHttpContextAccessor accessor, TimeProvider clock) : IDomainQueryHandler
{
    /// <inheritdoc/>
    public string Domain => "tenants";
    /// <inheritdoc/>
    public string QueryType => ResolveTenantReadAuthority.QueryType;

    /// <inheritdoc/>
    public async Task<QueryResult> ExecuteAsync(QueryEnvelope query, CancellationToken cancellationToken)
    {
        ArgumentNullException.ThrowIfNull(query);
        cancellationToken.ThrowIfCancellationRequested();
        VerifiedQueryCaller? caller = VerifiedQueryCaller.Get(accessor.HttpContext);
        OriginatingQueryContext? origin = caller?.OriginatingContext;
        if (caller is null || !ReferenceEquals(caller.Query, query) || origin is null
            || query.CallerAuthority?.Origin != "delegated-owner-query" || !query.IsDelegated
            || query.AuthenticatedWorkloadId is not ("projects" or "conversations" or "folders")
            || query.Domain != Domain || query.QueryType != QueryType || query.TenantId == "system"
            || query.AggregateId != query.TenantId || !Canonical(query.TenantId) || !Canonical(query.UserId)
            || query.OriginalActorId != query.UserId || origin.OriginalActorId != query.UserId
            || query.IsGlobalAdmin || query.Paging is not null
            || query.EntityId is not null && query.EntityId != query.AggregateId
            || origin.IsDelegated && !Canonical(origin.DelegationId)
            || !origin.IsDelegated && origin.DelegationId is not null
            || !Compatible(origin.Scopes, "projects.read") || !Compatible(origin.Audience, "hexalith-eventstore")
            || !Empty(query.Payload)) return QueryResult.Failure("safe-denial");
        try
        {
            // This is an owner-internal source identity. The managed caller Tenant remains unchanged.
            var identity = new AggregateIdentity("system", Domain, query.TenantId);
            var read = await reader.ReadAsync(identity, cancellationToken).ConfigureAwait(false);
            if (!read.IsAuthoritative || read.Stream is not { NativeProof: { Erased: false } proof } source
                || !NativeSourceProofCodec.IsValid(proof, identity, source.Head, 1)
                || source.Head <= 0 || source.ObservedAt > clock.GetUtcNow()
                || !TenantOwnerAuthorityQueryHandler.TryFold(source, query.TenantId, out var state))
                return QueryResult.Failure(QueryAdapterFailureReason.ActorException);
            bool allowed = state!.Status == TenantStatus.Active && state.HasMembershipHistory
                && state.Users.TryGetValue(query.UserId, out TenantRole role)
                && role is TenantRole.TenantReader or TenantRole.TenantContributor or TenantRole.TenantOwner;
            var final = await metadata.ReadAsync(identity, cancellationToken).ConfigureAwait(false);
            if (final is null || final.Proof != proof || final.ObservedAt > clock.GetUtcNow())
                return QueryResult.Failure(QueryAdapterFailureReason.ActorException);
            cancellationToken.ThrowIfCancellationRequested();
            return QueryResult.FromPayload(JsonSerializer.SerializeToElement(new TenantReadAuthorityResult(
                query.TenantId, query.UserId, allowed, proof, final.ObservedAt), JsonSerializerOptions.Web), QueryType);
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested) { throw; }
        catch { return QueryResult.Failure(QueryAdapterFailureReason.ActorException); }
    }

    private static bool Canonical(string? value) => !string.IsNullOrWhiteSpace(value) && value == value.Trim();
    private static bool Compatible(IReadOnlyList<string>? values, string expected)
        => values is null || values.Count == 0 || values.Contains(expected, StringComparer.Ordinal);
    private static bool Empty(byte[] payload)
    {
        try { using var document = JsonDocument.Parse(payload);
            return document.RootElement.ValueKind == JsonValueKind.Object && !document.RootElement.EnumerateObject().Any(); }
        catch (Exception exception) when (exception is JsonException or ArgumentException) { return false; }
    }
}
''')
p=r/'src/Hexalith.Tenants/Program.cs';s=p.read_text();s=s.replace('provider.GetRequiredService<TimeProvider>(), TimeSpan.FromSeconds(10)));','provider.GetRequiredService<TimeProvider>(), TimeSpan.FromSeconds(10), requireNativeProof: true));\nbuilder.Services.AddEventStoreNativeSourceMetadataReader();');p.write_text(s)
