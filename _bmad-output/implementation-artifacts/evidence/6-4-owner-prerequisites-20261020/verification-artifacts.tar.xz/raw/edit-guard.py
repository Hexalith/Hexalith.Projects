from pathlib import Path
r=Path('/home/administrator/projects/hexalith/projects/references/Hexalith.EventStore')
def put(f,s): (r/f).write_text(s)
def rep(f,a,b):
 p=r/f;s=p.read_text();assert a in s,f;p.write_text(s.replace(a,b))
put('src/Hexalith.EventStore.Contracts/Projections/InspectProjectionCurrentQuery.cs','''namespace Hexalith.EventStore.Contracts.Projections;

/// <summary>Inspects the native guarded binding for one exact selected owner through the existing bound-owner workload route.</summary>
/// <param name="Selection">The exact content-free generation selected by the owner query, never a grant.</param>
public sealed record InspectProjectionCurrentQuery(ProjectionOwnerSelection Selection)
{
    /// <summary>The exact additive technical inspection discriminator, requiring explicit workload enrollment.</summary>
    public const string QueryType = "Hexalith.EventStore.Queries.InspectProjectionCurrent.v1";
}
''')
put('src/Hexalith.EventStore.Contracts/Projections/ProjectionCurrentProof.cs','''using Hexalith.EventStore.Contracts.Streams;

namespace Hexalith.EventStore.Contracts.Projections;

/// <summary>The existing guarded native source, selected immutable receipt and catalog observed current together.</summary>
/// <param name="Source">Actual native source evidence.</param>
/// <param name="Owner">The original selected generation and completed batch receipt.</param>
/// <param name="CatalogFingerprint">The verified route catalog.</param>
public sealed record ProjectionCurrentProof(NativeSourceProof Source, ProjectionOwnerProof Owner, string CatalogFingerprint);
''')
f='src/Hexalith.EventStore.Server/Projections/ProjectionSourceGuardDeliveryResult.cs'
rep(f,'    /// <summary>Indicates that exact conditional completion','''    /// <summary>Retains only the original content-free owner proofs established by current inspection.</summary>
    internal IReadOnlyDictionary<string, Hexalith.EventStore.Contracts.Projections.ProjectionOwnerProof> ProvenOwners { get; init; }
        = new Dictionary<string, Hexalith.EventStore.Contracts.Projections.ProjectionOwnerProof>();

    /// <summary>Retains the exact native proof whose prefix was compared to the completion binding.</summary>
    internal Hexalith.EventStore.Server.Events.SourceProof? ProvenSource { get; init; }

    /// <summary>Indicates that exact conditional completion''')
f='src/Hexalith.EventStore.Server/Projections/ProjectionSourceGuardDelivery.cs'
rep(f,'        var freshness = new Dictionary<string, string>(StringComparer.Ordinal);','''        var freshness = new Dictionary<string, string>(StringComparer.Ordinal);
        var owners = new Dictionary<string, ProjectionOwnerProof>(StringComparer.Ordinal);''')
rep(f,'            freshness[projection] = selected.Proof.Selection.FreshnessVersion;','''            freshness[projection] = selected.Proof.Selection.FreshnessVersion;
            owners[projection] = selected.Proof;''')
rep(f,'            ProvenFreshnessVersions = freshness,\n        };','''            ProvenFreshnessVersions = freshness,
            ProvenOwners = owners,
            ProvenSource = observedSource?.Proof,
        };''')
# Existing signed gateway route remains the only entry; no new custom auth/headers.
f='src/Hexalith.EventStore/Controllers/QueriesController.cs'
rep(f,'if (request.OriginatingQuery is not { CallerAuthority.Origin: "authenticated-caller" } original','if (request.OriginatingQuery is not { CallerAuthority.Origin: "authenticated-caller" or "delegated-owner-query" } original')
rep(f,'                OriginatingContext = new(original.OriginalActorId!, original.AuthenticatedWorkloadId,\n                    original.IsDelegated, original.DelegationId, original.Scopes, original.Audience),','''                OriginatingContext = original.CallerAuthority.Origin == "delegated-owner-query"
                    ? original.CallerAuthority.OriginatingContext
                    : new(original.OriginalActorId!, original.AuthenticatedWorkloadId,
                        original.IsDelegated, original.DelegationId, original.Scopes, original.Audience),''')
rep(f,'            ownerAuthority = new("delegated-owner-query", [], original.CallerAuthority.Permissions)','''            if (original.CallerAuthority.Origin == "delegated-owner-query"
                && (original.CallerAuthority.OriginatingContext is not { } inherited
                    || inherited.OriginalActorId != request.PrincipalId || !original.IsDelegated
                    || inherited.IsDelegated && string.IsNullOrWhiteSpace(inherited.DelegationId)
                    || !inherited.IsDelegated && inherited.DelegationId is not null)) return Forbid();
            ownerAuthority = new("delegated-owner-query", [], original.CallerAuthority.Permissions)''')
rep(f,'        SubmitQueryResult result = await mediator.Send(submitted, cancellationToken).ConfigureAwait(false);','''        if (query.QueryType == Hexalith.EventStore.Contracts.Projections.InspectProjectionCurrentQuery.QueryType)
            return await InspectProjectionCurrentAsync(request, ownerAuthority, correlationId, cancellationToken).ConfigureAwait(false);
        SubmitQueryResult result = await mediator.Send(submitted, cancellationToken).ConfigureAwait(false);''')
f='src/Hexalith.EventStore.DomainService/DelegatedOwnerQueryClient.cs'
rep(f,'caller?.Query.CallerAuthority?.Origin != "authenticated-caller"','caller?.Query.CallerAuthority?.Origin is not ("authenticated-caller" or "delegated-owner-query")')
put('src/Hexalith.EventStore/Controllers/QueriesController.ProjectionCurrent.cs','''using System.Text.Json;
using Hexalith.EventStore.Client.Gateway;
using Hexalith.EventStore.Contracts.Identity;
using Hexalith.EventStore.Contracts.Projections;
using Hexalith.EventStore.Contracts.Queries;
using Hexalith.EventStore.Server.Events;
using Hexalith.EventStore.Server.Projections;
using Microsoft.AspNetCore.Mvc;

namespace Hexalith.EventStore.Controllers;

public partial class QueriesController
{
    private async Task<IActionResult> InspectProjectionCurrentAsync(BoundOwnerQueryRequest request,
        QueryCallerAuthority? authority, string correlationId, CancellationToken cancellationToken)
    {
        if (authority?.OriginatingContext is not { } origin || origin.OriginalActorId != request.PrincipalId
            || request.Query.Payload is not { } payload
            || HttpContext.RequestServices.GetService<IProjectionSourceGuardDelivery>() is not { } guard)
            return Forbid();
        try
        {
            InspectProjectionCurrentQuery? inspection = payload.Deserialize<InspectProjectionCurrentQuery>(JsonSerializerOptions.Web);
            ProjectionOwnerSelection? selection = inspection?.Selection;
            if (selection is null || selection.TenantId != request.Query.Tenant || selection.Domain != request.Query.Domain
                || selection.AggregateId != request.Query.AggregateId) return Forbid();
            var identity = new AggregateIdentity(selection.TenantId, selection.Domain, selection.AggregateId);
            ProjectionSourceGuardDeliveryResult result = await guard.InspectCurrentAsync(identity,
                selection.ProjectionName, cancellationToken).ConfigureAwait(false);
            ProjectionCurrentProof? current = result.Owned && result.AlreadyCurrent && result.ProvenSource is { } source
                && result.CatalogFingerprint is { } catalog
                && result.ProvenOwners.TryGetValue(selection.ProjectionName, out ProjectionOwnerProof? owner)
                && owner.Selection == selection
                ? new(SourceProofCodec.ToNative(source), owner, catalog) : null;
            Response.Headers.CacheControl = "no-store";
            return Ok(new SubmitQueryResponse(correlationId, JsonSerializer.SerializeToElement(current, JsonSerializerOptions.Web)));
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested) { throw; }
        catch (Exception exception) when (exception is JsonException or ArgumentException)
        { return Forbid(); }
    }
}
''')
# Narrow technical selection-key registration, preserving exact receipt source identities.
f='src/Hexalith.EventStore.Client/Projections/ReadModelOwnerProofBinding.cs'
p=r/f;s=p.read_text().rstrip();s=s[:-1]+'''
{
    /// <summary>Gets an explicitly registered private selection-key locator. The source and receipt scopes remain exact identities.</summary>
    public Func<ProjectionOwnerProofRequest, string>? SelectionKey { get; init; }
}
''';p.write_text(s)
f='src/Hexalith.EventStore.Client/Projections/DaprReadModelStore.OwnerProof.cs'
rep(f,'accessor.ReadAsync(identity.ActorId + ":" + binding.SelectionSuffix, cancellationToken)','accessor.ReadAsync(binding.SelectionKey?.Invoke(request) ?? identity.ActorId + ":" + binding.SelectionSuffix, cancellationToken)')
