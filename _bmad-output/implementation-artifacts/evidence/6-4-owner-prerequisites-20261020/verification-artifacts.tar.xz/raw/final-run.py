import hashlib,json,subprocess,sys,time,xml.etree.ElementTree as ET
from pathlib import Path
folder=Path('/tmp/6-4-owner-delivery');name,repo,*argv=sys.argv[1:]
root=Path('/home/administrator/projects/hexalith/projects')
r=root if repo == 'Projects' else root/'references'/repo
files=subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=r).decode().split('\0')
source={}
for f in files:
 p=r/f
 if p.is_file() and (f.endswith(('.cs','.csproj','.props','.targets','.json')) or f in ['AGENTS.md','.editorconfig','.gitattributes']):
  source[f]=hashlib.sha256(p.read_bytes()).hexdigest()
manifest={'cwd':str(r),'argv':argv,'started_at':time.time(),'source_sha256':hashlib.sha256(json.dumps(source,sort_keys=True).encode()).hexdigest(),'source_files':source,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()}
(folder/(name+'.json')).write_text(json.dumps(manifest,indent=2)+'\n')
with (folder/(name+'.log')).open('w') as log:
 code=subprocess.run(argv,cwd=r,stdout=log,stderr=subprocess.STDOUT).returncode
manifest.update(exit=code,finished_at=time.time(),log_sha256=hashlib.sha256((folder/(name+'.log')).read_bytes()).hexdigest())
for opt in ['-result-xml','-xml']:
 if opt in argv:
  xml=Path(argv[argv.index(opt)+1]);manifest['xml']=str(xml)
  if xml.exists():
   manifest['xml_sha256']=hashlib.sha256(xml.read_bytes()).hexdigest()
   assemblies=ET.parse(xml).findall('assembly');manifest['counts']={a:sum(int(e.get(a,0)) for e in assemblies) for a in ['total','passed','failed','skipped','errors']}
   if manifest['counts']['total']==0: manifest['empty_run']=True
(folder/(name+'.json')).write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k not in ['source_files','argv']},indent=2))
print('\n'.join((folder/(name+'.log')).read_text().splitlines()[-22:]))
sys.exit(code)
