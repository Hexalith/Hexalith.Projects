from pathlib import Path
root=Path('/home/administrator/projects/hexalith/projects/references/Hexalith.EventStore')
def put(f,s): (root/f).write_text(s)
def replace(f,a,b):
 p=root/f;s=p.read_text();assert a in s,f;s=s.replace(a,b);p.write_text(s)
# Share only the existing source-v1 seed/step metadata algorithm. Raw envelope hashing remains server-owned.
s=(root/'src/Hexalith.EventStore.Server/Events/SourceProofCodec.cs').read_text()
start=s.index('    /// <summary>Creates the scoped chain seed')
end=s.index('    /// <summary>Hashes every persisted envelope')
seed=s[start:end].replace('internal static SourceProof','public static NativeSourceProof')
start=s.index('    /// <summary>Extends using an already measured')
end=s.index('    /// <summary>Recognizes only an authenticated')
step=s[start:end]
step=step.replace('internal static SourceProof ExtendVerified(SourceProof previous, EventEnvelope envelope, string eventDigest)','public static NativeSourceProof ExtendDigest(NativeSourceProof previous, AggregateIdentity identity, long sequence, string messageId, string eventDigest)')
step=step.replace('        ArgumentNullException.ThrowIfNull(envelope);\n        var identity = new AggregateIdentity(envelope.TenantId, envelope.Domain, envelope.AggregateId);','        ArgumentNullException.ThrowIfNull(identity);')
step=step.replace('envelope.SequenceNumber','sequence').replace('envelope.MessageId','messageId').replace('nameof(envelope)','nameof(sequence)')
step=step.replace('        ProjectionDeliveryCostDiagnostics.Record(ProjectionDeliveryCost.SourceChainExtensions);\n','')
step=step.replace('internal static bool IsValid(SourceProof proof','public static bool IsValid(NativeSourceProof proof')
helpers=s[s.index('    private static bool IsDigest'):]
put('src/Hexalith.EventStore.Client/Streams/NativeSourceProofCodec.cs','''using System.Buffers.Binary;
using System.Security.Cryptography;
using System.Text;
using ByteAether.Ulid;
using Hexalith.EventStore.Contracts.Identity;
using Hexalith.EventStore.Contracts.Streams;

namespace Hexalith.EventStore.Client.Streams;

/// <summary>The existing source-v1 seed, step and metadata validation shared with the native server codec.</summary>
public static class NativeSourceProofCodec
{
    /// <summary>The supported source codec version.</summary>
    public const int Version = 1;
'''+seed+step+helpers)
# Server delegates to shared exact seed, step and metadata validator.
start=s.index('    /// <summary>Creates the scoped chain seed');end=s.index('    /// <summary>Hashes every persisted envelope')
s=s[:start]+'''    /// <summary>Creates the existing scoped source-v1 seed.</summary>
    internal static SourceProof CreateSeed(AggregateIdentity identity, string incarnation)
        => FromNative(Hexalith.EventStore.Client.Streams.NativeSourceProofCodec.CreateSeed(identity, incarnation));

'''+s[end:]
start=s.index('    /// <summary>Extends using an already measured');end=s.index('    /// <summary>Recognizes only an authenticated')
s=s[:start]+'''    /// <summary>Extends using the shared source-v1 step and the already measured raw-envelope hash.</summary>
    internal static SourceProof ExtendVerified(SourceProof previous, EventEnvelope envelope, string eventDigest)
    {
        ProjectionDeliveryCostDiagnostics.Record(ProjectionDeliveryCost.SourceChainExtensions);
        return FromNative(Hexalith.EventStore.Client.Streams.NativeSourceProofCodec.ExtendDigest(ToNative(previous),
            new(envelope.TenantId, envelope.Domain, envelope.AggregateId), envelope.SequenceNumber, envelope.MessageId, eventDigest));
    }

    /// <summary>Validates native metadata through the existing shared codec.</summary>
    internal static bool IsValid(SourceProof proof, AggregateIdentity identity, long head, long floor)
        => Hexalith.EventStore.Client.Streams.NativeSourceProofCodec.IsValid(ToNative(proof), identity, head, floor);

    /// <summary>Copies native metadata without assigning a new revision or receipt.</summary>
    internal static Hexalith.EventStore.Contracts.Streams.NativeSourceProof ToNative(SourceProof proof)
        => new(proof.CodecVersion, proof.TenantId, proof.Domain, proof.AggregateId, proof.SourceIncarnation,
            proof.HeadSequence, proof.HeadMessageId, proof.CumulativeDigest, proof.RetainedFloor, proof.Erased);

    private static SourceProof FromNative(Hexalith.EventStore.Contracts.Streams.NativeSourceProof proof)
        => new(proof.CodecVersion, proof.TenantId, proof.Domain, proof.AggregateId, proof.SourceIncarnation,
            proof.HeadSequence, proof.HeadMessageId, proof.CumulativeDigest, proof.RetainedFloor, proof.Erased);

'''+s[end:]
# ByteAether now only the shared codec uses it.
s=s.replace('using ByteAether.Ulid;\n','')
put('src/Hexalith.EventStore.Server/Events/SourceProofCodec.cs',s)
for f,prop in [('StreamReadRequest','''    /// <summary>Requires native source-v1 metadata and raw-envelope digests on the authenticated workload route.</summary>
    [System.Text.Json.Serialization.JsonIgnore(Condition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingDefault)]
    public bool RequireNativeProof { get; init; }
'''),('StreamReadMetadata','''    /// <summary>Gets the exact stable actor-owned source evidence, only for an explicitly requested native workload read.</summary>
    [System.Text.Json.Serialization.JsonIgnore(Condition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull)]
    public NativeSourceProof? NativeProof { get; init; }
'''),('StreamReadEvent','''    /// <summary>Gets the existing source-v1 raw-envelope digest supplied by the authenticated native workload route.</summary>
    [System.Text.Json.Serialization.JsonIgnore(Condition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull)]
    public string? NativeEventDigest { get; init; }
'''),('AuthoritativeEventStream','''    /// <summary>Gets the native prefix that was verified from the exact returned ordered event digests.</summary>
    [System.Text.Json.Serialization.JsonIgnore(Condition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull)]
    public NativeSourceProof? NativeProof { get; init; }
''')]:
 p=root/f'src/Hexalith.EventStore.Contracts/Streams/{f}.cs'; t=p.read_text()
 if t.rstrip().endswith(';'): t=t.rstrip()[:-1]+'\n{\n'+prop+'}\n'
 else: t=t.replace('\n{\n','\n{\n'+prop,1)
 p.write_text(t)
# native gateway reads never call recovery metadata. Inspection occurs before raw page and after decoding.
f='src/Hexalith.EventStore/Controllers/StreamsController.cs'
replace(f,'            AggregateStreamMetadata streamMetadata = await actor.GetStreamMetadataAsync().ConfigureAwait(false);','''            SourceProofInspection? native = null;
            AggregateStreamMetadata streamMetadata;
            if (request.RequireNativeProof)
            {
                if (!workloadOnly) return Forbid();
                native = await actor.InspectSourceProofAsync().WaitAsync(cancellationToken).ConfigureAwait(false);
                if (native is not { Status: SourceProofInspectionStatus.Available, Erased: false, Proof: { Erased: false } proof }
                    || !SourceProofCodec.IsValid(proof, identity, native.CurrentSequence, proof.RetainedFloor))
                    return StatusCode(StatusCodes.Status503ServiceUnavailable);
                streamMetadata = new(native.Exists, native.CurrentSequence);
            }
            else streamMetadata = await actor.GetStreamMetadataAsync().ConfigureAwait(false);''')
replace(f,'            return Ok(new StreamReadPage(','            if (native is not null && await actor.InspectSourceProofAsync().WaitAsync(cancellationToken).ConfigureAwait(false) != native)\n                return StatusCode(StatusCodes.Status503ServiceUnavailable);\n\n            return Ok(new StreamReadPage(')
replace(f,'[.. readableEvents.Select(ToStreamReadEvent)],','''[.. readableEvents.Select((item, index) => ToStreamReadEvent(item) with
                { NativeEventDigest = native is null ? null : SourceProofCodec.ComputeEventHash(orderedEvents[index]) })],''')
replace(f,'                    NextContinuationToken: null)));','''                    NextContinuationToken: null)
                { NativeProof = native?.Proof is { } nativeProof ? SourceProofCodec.ToNative(nativeProof) : null }));''')
# Reader opt-in; no legacy evidence upgraded.
f='src/Hexalith.EventStore.Client/Streams/AuthoritativeEventStreamReader.cs'
replace(f,'TimeSpan? readTimeout = null)','TimeSpan? readTimeout = null, bool requireNativeProof = false)')
replace(f,'            long head = await ReadHeadAsync(identity, deadline).ConfigureAwait(false);','''            StreamReadPage first = await ReadHeadAsync(identity, deadline).ConfigureAwait(false);
            long head = first.Metadata.LatestSequence;
            NativeSourceProof? native = first.Metadata.NativeProof;
            if (requireNativeProof && (native is null || native.Erased || native.RetainedFloor != 1
                || !NativeSourceProofCodec.IsValid(native, identity, head, 1))) return new(null, "source-native-proof-unavailable");
            NativeSourceProof? chain = native is null ? null : NativeSourceProofCodec.CreateSeed(identity, native.SourceIncarnation);''')
replace(f,'                    cursor, head, PageSize: PageSize);','                    cursor, head, PageSize: PageSize) { RequireNativeProof = requireNativeProof };')
replace(f,'                if (page.Metadata.LatestSequence != head)','                if (page.Metadata.LatestSequence != head || requireNativeProof && page.Metadata.NativeProof != native)')
replace(f,'                    events.Add(item);','''                    if (requireNativeProof)
                    {
                        chain = NativeSourceProofCodec.ExtendDigest(chain!, identity, item.SequenceNumber,
                            item.MessageId, item.NativeEventDigest!);
                    }
                    events.Add(item);''')
replace(f,'            if (!changed && await ReadHeadAsync(identity, deadline).ConfigureAwait(false) == head)','''            StreamReadPage final = await ReadHeadAsync(identity, deadline).ConfigureAwait(false);
            if (!changed && final.Metadata.LatestSequence == head
                && (!requireNativeProof || final.Metadata.NativeProof == native && chain == native))''')
replace(f,'events.AsReadOnly(), Convert.ToHexString(System.Security.Cryptography.RandomNumberGenerator.GetBytes(16))), null);','events.AsReadOnly(), Convert.ToHexString(System.Security.Cryptography.RandomNumberGenerator.GetBytes(16))) { NativeProof = requireNativeProof ? native : null }, null);')
replace(f,'private async Task<long> ReadHeadAsync','private async Task<StreamReadPage> ReadHeadAsync')
replace(f,'            ToSequence: 0, PageSize: 1);','            ToSequence: 0, PageSize: 1) { RequireNativeProof = requireNativeProof };')
replace(f,'            return Task.FromResult(page.Metadata.LatestSequence);','            return Task.FromResult(page);')
