using Hexalith.EventStore.Client.Gateway;
using Hexalith.EventStore.Contracts.Identity;
using Hexalith.EventStore.Contracts.Security;
using Hexalith.EventStore.Contracts.Streams;

namespace Hexalith.EventStore.Client.Streams;

/// <summary>Verifies an authorized contiguous prefix between two equal sampled heads.</summary>
/// <param name="gateway">The authenticated gateway client; each page is independently authorized.</param>
/// <param name="timeProvider">The observation clock.</param>
/// <param name="requireNativeProof">Requires exact native prefix validation; legacy pages never satisfy this opt-in lane.</param>
/// <param name="readTimeout">Optional positive whole-read deadline of at most thirty seconds; invalid bounds fail closed.</param>
public sealed class AuthoritativeEventStreamReader(IEventStoreGatewayClient gateway, TimeProvider timeProvider, TimeSpan? readTimeout, bool requireNativeProof)
    : IAuthoritativeEventStreamReader
{
    /// <summary>Preserves the original legacy reader constructor for existing compiled consumers.</summary>
    /// <param name="gateway">Authenticated gateway client.</param>
    /// <param name="timeProvider">Observation clock.</param>
    /// <param name="readTimeout">Optional whole-read deadline.</param>
    public AuthoritativeEventStreamReader(IEventStoreGatewayClient gateway, TimeProvider timeProvider, TimeSpan? readTimeout = null)
        : this(gateway, timeProvider, readTimeout, requireNativeProof: false) { }

    /// <summary>Creates a reader with explicit native proof requirements and the default deadline.</summary>
    /// <param name="gateway">Authenticated gateway client.</param>
    /// <param name="timeProvider">Observation clock.</param>
    /// <param name="requireNativeProof">Requires the native source codec on every page.</param>
    public AuthoritativeEventStreamReader(IEventStoreGatewayClient gateway, TimeProvider timeProvider, bool requireNativeProof)
        : this(gateway, timeProvider, null, requireNativeProof) { }

    private const int PageSize = 100;
    private const int MaxEvents = 10_000;
    private const int MaxAttempts = 3;
    private const long MaxPayloadBytes = 16 * 1024 * 1024;

    /// <inheritdoc/>
    public async Task<AuthoritativeStreamReadResult> ReadAsync(AggregateIdentity identity, CancellationToken cancellationToken = default)
    {
        try
        {
            cancellationToken.ThrowIfCancellationRequested();
            long startedAt = timeProvider.GetTimestamp();
            ArgumentNullException.ThrowIfNull(identity);
            TimeSpan bound = readTimeout ?? TimeSpan.FromSeconds(30);
            if (bound <= TimeSpan.Zero || bound > TimeSpan.FromSeconds(30))
            {
                cancellationToken.ThrowIfCancellationRequested();
                return new(null, "source-invalid-time-bound");
            }

            using var deadline = new AuthoritativeStreamReadDeadline(bound, timeProvider, cancellationToken, startedAt);
            try
            {
                AuthoritativeStreamReadResult result;
                try
                {
                    result = await ReadCoreAsync(identity, deadline).ConfigureAwait(false);
                }
                catch (Exception exception) when (exception is HttpRequestException or InvalidOperationException or ArgumentException or System.Text.Json.JsonException)
                {
                    result = new(null, "source-unavailable");
                }

                deadline.ThrowIfCancellationRequested();
                return result;
            }
            catch (OperationCanceledException)
            {
                cancellationToken.ThrowIfCancellationRequested();
                return new(null, deadline.IsExpired ? "source-time-bound-exceeded" : "source-unavailable");
            }
        }
        catch (Exception)
        {
            // Even unexpected provider/clock/snapshot faults preserve caller-first cancellation.
            // Without caller cancellation, unexpected faults keep their original type and identity.
            cancellationToken.ThrowIfCancellationRequested();
            throw;
        }
    }

    private async Task<AuthoritativeStreamReadResult> ReadCoreAsync(AggregateIdentity identity, AuthoritativeStreamReadDeadline deadline)
    {
        for (int attempt = 0; attempt < MaxAttempts; attempt++)
        {
            deadline.ThrowIfCancellationRequested();
            StreamReadPage first = await ReadHeadAsync(identity, deadline).ConfigureAwait(false);
            long head = first.Metadata.LatestSequence;
            NativeSourceProof? native = first.Metadata.NativeProof;
            if (requireNativeProof && (native is null || native.Erased || native.RetainedFloor != 1
                || !NativeSourceProofCodec.IsValid(native, identity, head, 1))) return new(null, "source-native-proof-unavailable");
            NativeSourceProof? chain = native is null ? null : NativeSourceProofCodec.CreateSeed(identity, native.SourceIncarnation);
            if (head > MaxEvents)
            {
                return new(null, "source-bound-exceeded");
            }

            var events = new List<StreamReadEvent>();
            long cursor = 0;
            long bytes = 0;
            bool changed = false;
            while (cursor < head)
            {
                var request = new StreamReadRequest(identity.TenantId, identity.Domain, identity.AggregateId,
                    cursor, head, PageSize: PageSize) { RequireNativeProof = requireNativeProof };
                StreamReadPage supplied = await deadline.ReadAsync(token => gateway.ReadStreamAsync(request, token)).ConfigureAwait(false);
                long priorBytes = bytes;
                (StreamReadPage page, long capturedBytes, long next) = await deadline.ReadAsync(_ =>
                {
                    long ownedBytes = priorBytes;
                    StreamReadPage ownedPage = CapturePage(supplied, request.PageSize, deadline, ref ownedBytes);
                    long ownedNext = StreamReadPageValidator.ValidateAndGetNextSequence(request, ownedPage);
                    return Task.FromResult((ownedPage, ownedBytes, ownedNext));
                }).ConfigureAwait(false);
                bytes = capturedBytes;
                if (page.Metadata.LatestSequence != head || requireNativeProof && page.Metadata.NativeProof != native)
                {
                    changed = true;
                    break;
                }

                if (page.Events.Count == 0)
                {
                    return new(null, "source-gap");
                }

                foreach (StreamReadEvent item in page.Events)
                {
                    deadline.ThrowIfCancellationRequested();
                    if (item.SequenceNumber != ++cursor)
                    {
                        return new(null, "source-gap-or-unreadable");
                    }

                    if (requireNativeProof)
                    {
                        chain = NativeSourceProofCodec.ExtendDigest(chain!, identity, item.SequenceNumber,
                            item.MessageId, item.NativeEventDigest!);
                    }
                    events.Add(item);
                }

                if (next != cursor || (!page.Metadata.IsTruncated && cursor != head))
                {
                    return new(null, "source-incomplete");
                }
            }

            StreamReadPage final = await ReadHeadAsync(identity, deadline).ConfigureAwait(false);
            if (!changed && final.Metadata.LatestSequence == head
                && (!requireNativeProof || final.Metadata.NativeProof == native && chain == native))
            {
                deadline.ThrowIfCancellationRequested();
                return new(new AuthoritativeEventStream(identity, head, timeProvider.GetUtcNow(),
                    events.AsReadOnly(), Convert.ToHexString(System.Security.Cryptography.RandomNumberGenerator.GetBytes(16))) { NativeProof = requireNativeProof ? native : null }, null);
            }
        }

        return new(null, "source-head-changed");
    }

    private async Task<StreamReadPage> ReadHeadAsync(AggregateIdentity identity, AuthoritativeStreamReadDeadline deadline)
    {
        var request = new StreamReadRequest(identity.TenantId, identity.Domain, identity.AggregateId,
            ToSequence: 0, PageSize: 1) { RequireNativeProof = requireNativeProof };
        StreamReadPage supplied = await deadline.ReadAsync(token => gateway.ReadStreamAsync(request, token)).ConfigureAwait(false);
        return await deadline.ReadAsync(_ =>
        {
            long bytes = 0;
            StreamReadPage page = CapturePage(supplied, request.PageSize, deadline, ref bytes);
            StreamReadPageValidator.ValidateAndGetNextSequence(request, page);
            if (page.Events.Count != 0 || page.Metadata.IsTruncated)
            {
                throw new InvalidOperationException("Invalid head observation.");
            }

            return Task.FromResult(page);
        }).ConfigureAwait(false);
    }

    private static StreamReadPage CapturePage(StreamReadPage supplied, int limit, AuthoritativeStreamReadDeadline deadline, ref long bytes)
    {
        deadline.ThrowIfCancellationRequested();
        ArgumentNullException.ThrowIfNull(supplied);
        var metadata = supplied.Metadata ?? throw new InvalidOperationException("Missing page metadata.");
        var providerEvents = supplied.Events ?? throw new InvalidOperationException("Missing page events.");
        if (providerEvents.Count < 0 || providerEvents.Count > limit || metadata.EventCount < 0 || metadata.EventCount > limit)
        {
            throw new InvalidOperationException("Page event bound exceeded.");
        }

        var owned = new List<StreamReadEvent>();
        foreach (StreamReadEvent item in providerEvents)
        {
            deadline.ThrowIfCancellationRequested();
            if (owned.Count >= limit || item is null || item.Payload is null || item.Payload.Length > MaxPayloadBytes - bytes)
            {
                throw new InvalidOperationException("Page payload or event bound exceeded.");
            }

            byte[] payload = item.Payload.ToArray();
            bytes += payload.Length;
            var protection = CaptureProtection(item.ProtectionMetadata, deadline);
            deadline.ThrowIfCancellationRequested();
            owned.Add(item with { Payload = payload, ProtectionMetadata = protection });
        }

        deadline.ThrowIfCancellationRequested();
        return supplied with { Metadata = metadata with { }, Events = owned.AsReadOnly() };
    }

    private static EventStorePayloadProtectionMetadata? CaptureProtection(EventStorePayloadProtectionMetadata? metadata,
        AuthoritativeStreamReadDeadline deadline)
    {
        if (metadata is null) { return null; }
        deadline.ThrowIfCancellationRequested();
        if (metadata.Scheme?.Length > EventStorePayloadProtectionMetadata.MaxSchemeLength
            || metadata.KeyAlias?.Length > EventStorePayloadProtectionMetadata.MaxKeyAliasLength
            || metadata.ContentHint?.Length > EventStorePayloadProtectionMetadata.MaxContentHintLength)
        {
            throw new InvalidOperationException("Protection metadata field bound exceeded.");
        }

        IReadOnlyDictionary<string, string>? flags = null;
        if (metadata.CompatibilityFlags is { } supplied)
        {
            if (supplied.Count < 0 || supplied.Count > EventStorePayloadProtectionMetadata.MaxCompatibilityFlagCount)
            {
                throw new InvalidOperationException("Protection metadata flag bound exceeded.");
            }

            var captured = new Dictionary<string, string>(StringComparer.Ordinal);
            foreach (var pair in supplied)
            {
                deadline.ThrowIfCancellationRequested();
                if (captured.Count >= EventStorePayloadProtectionMetadata.MaxCompatibilityFlagCount
                    || pair.Key is null || pair.Key.Length > EventStorePayloadProtectionMetadata.MaxCompatibilityFlagKeyLength
                    || pair.Value is null || pair.Value.Length > EventStorePayloadProtectionMetadata.MaxCompatibilityFlagValueLength
                    || !captured.TryAdd(pair.Key, pair.Value))
                {
                    throw new InvalidOperationException("Protection metadata flag is invalid.");
                }
            }

            flags = new System.Collections.ObjectModel.ReadOnlyDictionary<string, string>(captured);
        }

        var owned = metadata with { CompatibilityFlags = flags };
        if (owned.State is not (PayloadProtectionState.Unprotected or PayloadProtectionState.Protected)
            || !EventStorePayloadProtectionMetadataCarrier.TryValidate(owned, out _))
        {
            throw new InvalidOperationException("Protection metadata is unreadable or malformed.");
        }

        deadline.ThrowIfCancellationRequested();
        return owned;
    }

}
