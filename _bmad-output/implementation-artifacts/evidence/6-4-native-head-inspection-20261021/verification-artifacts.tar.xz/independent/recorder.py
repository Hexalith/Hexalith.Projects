import datetime, hashlib, json, pathlib, subprocess, sys, time
root=pathlib.Path('/home/administrator/projects/hexalith/projects/references/Hexalith.EventStore')
output=pathlib.Path('/tmp/story64-native-inspection-independent'); output.mkdir(exist_ok=True)
label=sys.argv[1]; command=sys.argv[2:]
changed=subprocess.check_output(['git','diff','--name-only','-z'],cwd=root).decode().split('\0')
changed+=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=root).decode().split('\0')
paths=[root/f for f in sorted(set(changed)) if f and f.endswith('.cs')]
def hashes(): return {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths if p.exists()}
before=hashes();start=datetime.datetime.now(datetime.timezone.utc).isoformat(); t=time.monotonic()
with (output/(label+'.log')).open('w') as log: result=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
record={'label':label,'command':command,'cwd':str(root),'started_utc':start,'elapsed_seconds':round(time.monotonic()-t,3),'exit_code':result.returncode,'source_before':before,'source_after':hashes()}
record['source_unchanged']=record['source_before']==record['source_after']; (output/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ['label','exit_code','elapsed_seconds','source_unchanged']}))
print('\n'.join((output/(label+'.log')).read_text(errors='replace').splitlines()[-12:]))
sys.exit(result.returncode)
